extern int getfd(void);
