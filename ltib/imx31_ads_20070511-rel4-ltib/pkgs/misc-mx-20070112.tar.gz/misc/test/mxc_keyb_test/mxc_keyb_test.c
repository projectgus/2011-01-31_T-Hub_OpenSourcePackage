/*
 * Copyright 2006 Freescale Semiconductor, Inc. All rights reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*
 * This tests the freescale MXC keypad driver for the basic operation.
 * The following tests are done.
 * - Open
 * - Read of the keypad data
 *
 * To compile this file: 
 *  $ /usr/local/arm/gnu/release-3.4.0/arm-linux/bin/gcc -o mxc_keyb_test 
 * mxc_keyb_test.c 
 *
 */
#include <linux/config.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <linux/input.h>


#if   defined(CONFIG_MACH_MX21ADS) || defined(CONFIG_MACH_MX27ADS)

char *keyarray[]=
{"0", "0", "1","2", "3","4","5", "6","7","8",
 "9","0","0","0","bs","Tab","q","w","e","r",
 "t","y","u","i","o","p","0","0","action","0",
 "a","s","d","f","g","h","j","k","l","0",
 "0", "0","shift","0","z","x","c","v","b","n",
 "m","0", ".","0","0","*","0","space","Caps","key1",
 "key2","#","send","0","on/off","symb","0","0", "0","0",
 "0","extra3","extra4","extra5","0","app4","extra1","extra2", "+","app1",
 "app2","app3","0","0","0","0","0","0", "0","0",
 "0","0","0","0","0","0","0","0", "0","0",
 "0","0","Home","UP","0","LEFT","RIGTH", "END","DOWN","0",
 "0","0","0","0","VOL_DOWN", "VOL_UP","POWER","0","0","0",
 "0","0","0","0","0", "0","0","0","0","0",
 "0","0","0","0","0","0", "0","0","0","0",
 "0","0","0","0","0","Send","0", "0","0","0",
 "0","0","0","0","0","0","0","0","Back", "0",
 "0","SEL","0","0","0","0","0","Record",
};

#else
char *keyarray[]=
{"0", "0", "1","2", "3","4","5", "6","7","8",
 "9","0","0","0","bs","Tab","q","w","e","r",
 "t","y","u","i","o","p","0","0","Enter","0",
 "a","s","d","f","g","h","j","k","l","0","0",
 "0","shift","0","z","x","c","v","b","n","m","0",
 ".","0","0","*","0","space","Caps","Key1",
 "on/off","0","0","0","app1","symb","app2","app3",
 "app4","0","0","0","0","0","0","0","0","0",
 "+","0","0","0","0","0","0","0","0","#",
 "key2","0","0","0","0","0","0","0","0","0",
 "0","0","0","0","Home","UP","0","LEFT","RIGTH",
 "END","DOWN","0","0","0","0","0","VOL_DOWN",
 "VOL_UP","0","0","0","0","0","0","0","0","0",
 "0","0","0","0","0","0","0","0","0","0","0",
 "0","0","0","0","0","0","0","0","0","Send","0",
 "0","0","0","0","0","0","0","0","0","0","0","Back",
 "0","0","SEL","0","0","0","0","0","Record",
};
#endif

int main(int ac, char **av)
{
        int fd, bytes, flush;
        unsigned char buf[20];
        int gfinished;
        int i;
        char *defdev="/dev/input/event0";
	struct input_event *ev;

        gfinished = 0;
        printf("========> Testing MXC Keypad driver <========\n");
        printf("====> Opening %s\n", defdev);
        fd = open(defdev, O_RDONLY);
        if(fd < 0){
                printf("Open failed with err %d\n", fd);
                perror("Open");
                return 1;
        }
        printf("Open succes: %d\n", fd);
        printf("KPP TEST APP: To test Please press keys on the keypad \n"
                 "else press 'END' to terminate the keypad testing.\n");        
        while(gfinished == 0) {
                memset(buf, 0, sizeof(buf));
                bytes = read(fd, buf, 20);
		ev = (struct input_event *)buf;

                if (ev->code == 107) {
                        gfinished = 1;
                        printf("'END'  key Pressed, Keypad "\
                                "testing is terminated \n");
                } else {
                        i = ev->code;
			if (ev->type == EV_KEY) {
				if (ev->value) {
					if (i == KEY_SELECT) {
						printf("Key press is SELECT\n");
					}
					else {
						printf("Key Press is   %s\n", 
							keyarray[i]);
					}
				}
				else {
					if (i == KEY_SELECT) {
						printf("Key Release is SELECT\n");
					}
					else {
						printf("Key Release is %s\n", 
							keyarray[i]);
					}
				}
                	}
        	}
	}

        printf("KPP TEST APP: ====> Closing the Keypad device ...\n"); 
        flush = close(fd);
        if(flush < 0)  {
                printf("KPP TEST APP: Close failed with err %d\n", flush);
                perror("Close");
                return -1;
        }
        printf("KPP TEST APP: Close succes: %d\n", flush);
        printf("========> Testing MXC Keypad driver complete <========\n");
        return 0;
}

