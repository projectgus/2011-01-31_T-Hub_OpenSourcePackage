int get_label_uuid(const char *device, char **label, char *uuid);
