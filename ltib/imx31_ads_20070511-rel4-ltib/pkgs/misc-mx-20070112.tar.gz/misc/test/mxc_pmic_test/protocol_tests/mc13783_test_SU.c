/*============================================================================*/
/**
    @file   mc13783_test_SU.c

    @brief  Test scenario C source MC13783.
*/
/*==============================================================================

  Copyright (C) 2004, Freescale Semiconductor, Inc. All Rights Reserved
  THIS SOURCE CODE IS CONFIDENTIAL AND PROPRIETARY AND MAY NOT
  BE USED OR DISTRIBUTED WITHOUT THE WRITTEN PERMISSION OF
  Freescale Semiconductor, Inc.
     
================================================================================
Revision History:
                            Modification     Tracking
Author                          Date          Number    Description of Changes
-------------------------   ------------    ----------  -----------------------
Developer CHEVERNEUIL/RB878C  05/18/2004     TLSbo39480   Initial version 
LUDOVIC DELASPRE/RC149C       05/28/2004     TLSbo39713   VTE 1.2 integration
Alexandr GENIATOV             07/15/2004     TLSbo40262   Code improvement
CHEVERNEUIL/FCHE01            09/16/2004     TLSbo42608   use MC13783 include 
        						  files

================================================================================
Portability: Indicate if this module is portable to other compilers or 
             platforms. 
             If not, indicate specific reasons why is it not portable.

==============================================================================*/

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================
                                        INCLUDE FILES
==============================================================================*/
/* Standard Include Files */
#include <errno.h>

/* Harness Specific Include Files. */
#include "../include/test.h"

/* Verification Test Environment Include Files */
#include "mc13783_test_common.h"
#include "mc13783_test_SU.h"

/*==============================================================================
                                        LOCAL MACROS
==============================================================================*/

/*==============================================================================
                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==============================================================================*/

/*==============================================================================
                                       LOCAL CONSTANTS
==============================================================================*/

/*==============================================================================
                                       LOCAL VARIABLES
==============================================================================*/

/*==============================================================================
                                       GLOBAL CONSTANTS
==============================================================================*/

/*==============================================================================
                                       GLOBAL VARIABLES
==============================================================================*/

/*==============================================================================
                                   LOCAL FUNCTION PROTOTYPES
==============================================================================*/

/*==============================================================================
                                       LOCAL FUNCTIONS
==============================================================================*/

/*============================================================================*/
/*===== VT_mc13783_SU_setup =====*/
/**
@brief  assumes the initial condition of the test case execution

@param  None
  
@return On success - return TPASS
        On failure - return the error code
*/
/*============================================================================*/
	int VT_mc13783_SU_setup(void) {
		int rv = TFAIL;

		 rv = TPASS;

		 return rv;
	}
/*============================================================================*//*===== VT_mc13783_SU_cleanup =====*//**
@brief  assumes the post-condition of the test case execution

@param  None
  
@return On success - return TPASS
        On failure - return the error code
*//*============================================================================*/ int VT_mc13783_SU_cleanup(void) {
		int rv = TFAIL;

		rv = TPASS;

		return rv;
	}

/*============================================================================*/
/*===== VT_mc13783_test_SU =====*/
/**
@brief  MC13783 test scenario SU function

@param  None
  
@return On success - return TPASS
        On failure - return the error code
*/
/*============================================================================*/
	int VT_mc13783_test_SU(void) {
		int rv = TPASS, fd;
		int event = EVENT_TSI;

		fd = open(MC13783_DEVICE, O_RDWR);
		if (fd < 0) {
			pthread_mutex_lock(&mutex);
			tst_resm(TFAIL, "Unable to open %s", MC13783_DEVICE);
			pthread_mutex_unlock(&mutex);
			return TFAIL;
		}

		pthread_mutex_lock(&mutex);
		/* printf("Test subscribe/un-subscribe event = %d\n", event); */
		pthread_mutex_unlock(&mutex);

		if (VT_mc13783_subscribe(fd, event) != TPASS) {
			rv = TFAIL;
		}
		if (VT_mc13783_unsubscribe(fd, event) != TPASS) {
			rv = TFAIL;
		}

		pthread_mutex_lock(&mutex);
		/* printf("Test subscribe/un-subscribe 2 event = %d\n", event); */
		pthread_mutex_unlock(&mutex);
		if (VT_mc13783_subscribe(fd, event) != TPASS) {
			rv = TFAIL;
		}
		if (VT_mc13783_subscribe(fd, event) != TPASS) {
			rv = TFAIL;
		}
		if (VT_mc13783_unsubscribe(fd, event) != TPASS) {
			rv = TFAIL;
		}
		if (VT_mc13783_unsubscribe(fd, event) != TPASS) {
			rv = TFAIL;
		}

		if (close(fd) < 0) {
			pthread_mutex_lock(&mutex);
			tst_resm(TFAIL, "Unable to close file descriptor %d",
				 fd);
			pthread_mutex_unlock(&mutex);
			return TFAIL;
		}

		return rv;
	}

#ifdef __cplusplus
}
#endif
