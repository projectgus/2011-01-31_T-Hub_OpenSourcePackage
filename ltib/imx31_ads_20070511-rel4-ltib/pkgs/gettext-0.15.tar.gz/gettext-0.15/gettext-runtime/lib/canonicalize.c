#include "../../gettext-tools/lib/canonicalize.c"
