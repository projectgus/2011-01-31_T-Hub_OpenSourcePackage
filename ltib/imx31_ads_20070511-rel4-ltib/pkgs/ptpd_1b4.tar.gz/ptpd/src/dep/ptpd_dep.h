/* ptpd_dep.h */

#ifndef PTPD_DEP_H
#define PTPD_DEP_H

#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<signal.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<time.h>
#include<sys/time.h>
#include<sys/timex.h>
#include<sys/socket.h>
#include<sys/poll.h>
#include<sys/ioctl.h>
#include<arpa/inet.h>


/* system messages */
#define ERROR(x...) printf("!ptpd: " x)
#define PERROR(x...) perror("!ptpd: " x)
#define NOTIFY(x...) printf("ptpd: " x)

/* debug messages */
#ifdef PTPD_DBGV
#define PTPD_DBG
#define DBGV(x...) printf("(debug) " x)
#else
#define DBGV(x...)
#endif

#ifdef PTPD_DBG
#define DBG(x...) printf("(debug) " x)
#define DBGFLUSH() fflush(stdout)
#else
#define DBG(x...)
#define DBGFLUSH()
#endif

/* endian corrections */
#if defined(PTPD_MSBF)
#define shift8(x,y)       ( (x) << ((3-y)<<3) )
#define shift16(x,y)      ( (x) << ((1-y)<<4) )
#elif defined(PTPD_LSBF)
#define shift8(x,y)       ( (x) << ((y)<<3) )
#define shift16(x,y)      ( (x) << ((y)<<4) )
#endif

#define flip16(x)         htons(x)
#define flip32(x)         htonl(x)
/* i don't know any target platforms that do not have htons and htonl,
   but here is an agnostic form just in case */
/*
#if defined(PTPD_MSBF)
#define flip16(x)         (x)
#define flip32(x)         (x)
#elif defined(PTPD_LSBF)
#define flip16(x)         ((((x) >> 8) & 0x00ff) | \
                           (((x) << 8) & 0xff00))
#define flip32(x)         ((((x) >> 24) & 0x000000ff) | \
                           (((x) >> 8 ) & 0x0000ff00) | \
                           (((x) << 8 ) & 0x00ff0000) | \
                           (((x) << 24) & 0xff000000) )

#endif
*/

/* bit array manipulation */
#define getFlag(x,y)      !!(*(UInteger8*)((x)+((y)<8?1:0)) & ( 1<<((y)<8?(y):(y)-8) ))
#define setFlag(x,y)      (*(UInteger8*)((x)+((y)<8?1:0)) |= 1<<((y)<8?(y):(y)-8) )
#define clearFlag(x,y)    (*(UInteger8*)((x)+((y)<8?1:0)) &= ~(1<<((y)<8?(y):(y)-8)) )


/* msg.c */
Boolean msgPeek(void*);
void msgUnpackHeader(void*,MsgHeader*);
void msgUnpackSync(void*,MsgSync*);
void msgUnpackDelayReq(void*,MsgDelayReq*);
void msgUnpackFollowUp(void*,MsgFollowUp*);
void msgUnpackDelayResp(void*,MsgDelayResp*);
void msgUnpackManagement(void*,MsgManagement*);
UInteger8 msgUnloadManagement(void*,MsgManagement*,PtpClock*,RunTimeOpts*);
void msgUnpackManagementPayload(void *buf, MsgManagement *manage);
void msgPackHeader(void*,PtpClock*);
void msgPackSync(void*,Boolean,PtpClock*);
void msgPackDelayReq(void*,Boolean,PtpClock*);
void msgPackFollowUp(void*,UInteger16,TimeRepresentation*,PtpClock*);
void msgPackDelayResp(void*,MsgHeader*,TimeRepresentation*,PtpClock*);
UInteger16 msgPackManagement(void*,MsgManagement*,PtpClock*);
UInteger16 msgPackManagementResponse(void*,MsgHeader*,MsgManagement*,PtpClock*);

/* net.c */
/* linux API dependent */
Boolean netInit(NetPath*,RunTimeOpts*,PtpClock*);
Boolean netShutdown(NetPath*);
Boolean netSelect(Integer32,NetPath*);
Boolean netRecvEvent(Octet*,Octet*,TimeRepresentation*,NetPath*);
Boolean netRecvGeneral(Octet*,Octet*,NetPath*);
Boolean netSendEvent(Octet*,Octet*,UInteger16,TimeRepresentation*,NetPath*);
Boolean netSendGeneral(Octet*,Octet*,UInteger16,NetPath*);

/* servo.c */
void initClock(RunTimeOpts*,PtpClock*);
void updateDelay(TimeRepresentation*,TimeRepresentation*,
  one_way_delay_filter*,RunTimeOpts*,PtpClock*);
void updateOffset(TimeRepresentation*,TimeRepresentation*,
  offset_from_master_filter*,PtpClock*);
void updateClock(RunTimeOpts*,PtpClock*);

/* startup.c */
/* unix API dependent */
PtpClock * ptpdStartup(int,char**,Integer16*,RunTimeOpts*);
void ptpdShutdown(void);

/* sys.c */
/* unix API dependent */
void displayStats(PtpClock*);
Boolean nanoSleep(TimeRepresentation*);
void getTime(UInteger32*,Integer32*);
void setTime(UInteger32,Integer32);
UInteger16 getRand(UInteger32*);
Boolean adjFreq(Integer32);

/* timer.c */
void initTimer(Integer32);
void timerUpdate(IntervalTimer*);
void timerStop(UInteger16,IntervalTimer*);
void timerStart(UInteger16,UInteger16,IntervalTimer*);
Boolean timerExpired(UInteger16,IntervalTimer*);


#endif

