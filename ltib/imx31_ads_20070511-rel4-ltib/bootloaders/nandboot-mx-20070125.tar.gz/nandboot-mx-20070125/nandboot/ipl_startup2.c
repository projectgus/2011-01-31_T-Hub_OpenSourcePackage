/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#include <string.h>

void *memcpy(void *dest, const void *src, size_t n);
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned char u8;

/* These variable come from linker */

extern u32 __end_ipl_startup;
extern u32 __start_ipl_main;
extern u32 __end_ipl_main;

extern u32 main(void);

#ifdef IPL_DEBUG
/* Debug before serial is available */
/* Debug message buffer */
#ifdef IMX27ADS
u32 *dbg = (u32 *) 0xA0010000;
#else
u32 *dbg = (u32 *) 0x80010000;
#endif
#define DBG(_msg, _param)       \
        *dbg++ = (u32)_msg;     \
        *dbg++ = (u32)_param;
#else
#define DBG(_msg, _param)  do {} while(0)
#endif

u32 copy_jump_main()
{
	volatile u16 *src;
	volatile u16 *dst;
	u32 len;
/*	u32(*fptr) (void);
	u32 ret;
	volatile int tmp;
*/
	src = (u16 *) & __end_ipl_startup;
	dst = (u16 *) & __start_ipl_main;
	len = (&__end_ipl_main - &__start_ipl_main) * 2;

	DBG(1, src);
	DBG(2, dst);
	DBG(3, &__end_ipl_main);
	DBG(4, len);

	while (len-- > 0) {
		*dst++ = *src++;
	}

	asm("ldr r1, =main");
	asm("blx r1");
	/* Should never return here! */
}
