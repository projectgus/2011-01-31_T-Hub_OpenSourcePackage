/*============================================================================*/
/**
    @file   pmic_adc_test.h

    @brief  Test scenario C header PMIC.
*/
/*==============================================================================

  Copyright (C) 2004, Freescale Semiconductor, Inc. All Rights Reserved
  THIS SOURCE CODE IS CONFIDENTIAL AND PROPRIETARY AND MAY NOT
  BE USED OR DISTRIBUTED WITHOUT THE WRITTEN PERMISSION OF
  Freescale Semiconductor, Inc.
     
================================================================================
Revision History:
                            Modification     Tracking
Author (core ID)                Date          Number    Description of Changes
-------------------------   ------------    ----------  ------------------------
Developer QUINTERO/JQUI1C     27/09/2005     DSPhl26599   Initial version

==============================================================================*/

#ifndef PMIC_ADC_TEST_H
#define PMIC_ADC_TEST_H

#ifdef __cplusplus
extern "C"{
#endif

/*==============================================================================
                                         INCLUDE FILES
==============================================================================*/
#ifndef bool
#define bool    int
#endif

#ifndef true
#define true    1
#endif 

#ifndef false
#define false    1
#endif 

#include <sys/types.h>	/* open() */
#include <sys/stat.h>	/* open() */
#include <fcntl.h>	/* open() */
#include <sys/ioctl.h>	/* ioctl() */
#include <unistd.h>	/* close() */
#include <stdio.h>	/* sscanf() & perror() */
#include <stdlib.h>	/* atoi() */

#include <asm/arch/pmic_external.h>   
#include <asm/arch/pmic_adc.h>

/*==============================================================================
                                           CONSTANTS
==============================================================================*/

/*==============================================================================
                                       DEFINES AND MACROS
==============================================================================*/

#define    TEST_CASE_TS	        "TS"
#define    TEST_CASE_R		"read"
#define    TEST_CASE_CC	        "CC"
#define    TEST_CASE_IT		"IT"
#define    TEST_CASE_MON        "MON"
#define    TEST_CASE_CONV	"CONV"

#define PMIC_DEVICE_ADC	"/dev/pmic_adc"

/*==============================================================================
                                             ENUMS
==============================================================================*/

/*==============================================================================
                                 STRUCTURES AND OTHER TYPEDEFS
==============================================================================*/

/*==============================================================================
                                 GLOBAL VARIABLE DECLARATIONS
==============================================================================*/

/*==============================================================================
                                     FUNCTION PROTOTYPES
==============================================================================*/
#ifdef __cplusplus
}
#endif

#endif  // PMIC_ADC_TEST_H //
