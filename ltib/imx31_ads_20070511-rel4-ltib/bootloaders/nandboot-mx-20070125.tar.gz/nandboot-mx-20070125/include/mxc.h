#ifndef _MXC_H
#define _MXC_H
/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @defgroup Miniboot Bootloader for NOR Flash
 */

/*!
 * @defgroup NANDboot Bootloader for NAND Flash
 */

/*!
 * @file mxc.h
 * 
 * @brief This file contains the Miniboot and NANDboot chip configuration and 
 * source configurations. 
 *
 * @ingroup Miniboot and NANDboot
 */

#if defined(IMX27ADS)
#include "mx27/hal_platform_setup.h"

#elif defined(IMX31ADS)
#include "mx31/hal_platform_setup.h"

#elif defined(IMX21ADS)
#ifdef nandboot
#include "mx21/hal_platform_setup.h"
#endif
#else
#error PLATFORM should be defined to be one of {IMX31ADS|IMX21ADS|IMX27ADS}
#endif

/*!
 * @name Miniboot data types
 */

/*! @{ */

//#include "mxc.h"

/*! 
 * 32 bit data type 
 */
#if !defined(__ASSEMBLER__) /* ADDED FOR COMPILATION  */
typedef unsigned int    U32;  

/*! 
 * 16 bit data type
 */
typedef unsigned short  U16;  

/*! 
 * 8 bit data type
 */
typedef unsigned char   U8;   
#endif

/*! @} */

#define KERNEL_START_BLOCK_2k   1
#define KERNEL_START_BLOCK_512B 8
/*!
 * This defines the enabling or disabling of the Watchdog Timer feature 
 * in Miniboot
 */
#define WDOG_EN         0 

/*!
 * This defines the enabling or disabling of the 'Addition CRC' feature 
 * in Miniboot
 */
#ifdef miniboot
#define INT_UART	2
#define EXT_UART	1
#define CRC_EN         0
#endif
/*!
 * This defines the UART port in Miniboot
 */
#ifdef nandboot
#define INT_UART        0
#define EXT_UART        1
#endif
/*!
 * This defines the either internal (INT_UART) or external (EXT_UART) UART to
 * be used for output
 */

/* Use Internal Uart because redboot and linux kernel use same UART */
#define UART_OUTPUT    INT_UART

/*!
 * This defines the UART port in NANDboot
 * If EXT_UART is defined UART_PORT 1 is PORT_A and 2 is PORT_B
 */
#define UART_PORT       1

/*!
 * This defines the Baud rate for UART
 */
#define UART_BAUD_RATE        115200

/*!
 * Set this parameter to non-zero to enable unit test code in NANDBoot. 
 */
#define UNIT_TEST       0
/*!
 * This defines the enabling or disabling of the Boot from flash option 
 * in Miniboot
 */
#define BOOT_FROM_FLASH                       0
 
/*!
 * This defines the enabling or disabling of the change of command line option 
 * in Miniboot
 */
#define CHANGE_COMMAND_LINE_OPTION            1

/*!
 * This defines the enabling or disabling of the change of command line 
 * addresss option  in Miniboot
 */
#define CHANGE_COMMAND_LINE_ADDRESS           1

/*!
 * This defines the enabling or disabling of the change of kernel source 
 * addresss option  in Miniboot
 */
#define CHANGE_KERNEL_SOURCE_ADDRESS          1

/*!
 * This defines the enabling or disabling of the change of kernel loading
 * addresss option  in Miniboot
 */
#define CHANGE_KERNEL_LOADING_ADDRESS         1     

/*
 * These defines are used for Unit Test
 */
#if UNIT_TEST
#define DEBUG_BASE      0x80001000
#define DEBUG_ADDR3     (U32 *)(DEBUG_BASE+0x300) /* for debug */
#endif

/*!
 * Maximum size for command line option
 */
#define CMDLINE_LEN     150

/*!
 * Base address for Watchdog Timer
 */
#define WDOG_BASE       WDOG1_BASE_ADDR

/*!
 * Timeout value for Watchdog Timer
 */
#define WDOG_TIMEOUT        0x4000
 
/*!
 * Timeout value for Watchdog Timer
 */
#define MENU_TIMEOUT       TIMEOUT
 
/*!
 * AIPS1 register base address
 */
#define AIPS1_REG_BASE  AIPS1_BASE_ADDR
/*!
 * AIPS2 register base address
 */
#define AIPS2_REG_BASE  AIPS2_BASE_ADDR

/*!
 * This defines the 16 bit NAND Flash
 */
#define NAND_WIDTH_16      0

/*!
 * This defines the 8 bit NAND Flash
 */
#define NAND_WIDTH_8      1

#endif /* MXC_MB_H */
