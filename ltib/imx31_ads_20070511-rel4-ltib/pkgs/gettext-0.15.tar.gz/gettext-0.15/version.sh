# Version number and release date.
VERSION_NUMBER=0.15
RELEASE_DATE=2006-07-21      # in "date +%Y-%m-%d" format
