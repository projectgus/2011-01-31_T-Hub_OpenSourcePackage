#define LM_DATE "20040611"
#define LM_VERSION "2.8.7"
