/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
  @file mxc_extuart.c
 *
 * @brief External UART code required for NANDboot and Miniboot to send and
 * receive data to 
 * terminal for user interaction.
 *
 * @ingroup Miniboot and NANDboot
*/
#include "mxc.h"
#include "mxc_uart.h"

/*!
 * This function configures EXT UART 
 */
void ext_uart_init(void)
{
	U8 lcr;

	_reg_LCR = (SIO_LCR_WLS0 | SIO_LCR_WLS1);
	lcr = (U8) _reg_LCR;
	lcr |= SIO_LCR_DLAB;
	_reg_LCR = lcr;
	_reg_DLL = EXT_SERIAL_BAUD_LSB;
	_reg_DLM = EXT_SERIAL_BAUD_MSB;
	lcr &= ~SIO_LCR_DLAB;
	_reg_LCR = lcr;
	_reg_FCR = 0x07;	/*  Enable & clear FIFO */
}

/*!
 * This function sends data to UART. It waits for the transmit buffer to be
 * empty by checking  bit in UART Line status register . If buffer is empty it
 * writes the character data into it. If carriage return character is found it
 * will append line-feed character.
 *
 * @param       c           character data to send to UART
 *
 */
void ext_uart_putc(U8 c)
{

	/* Wait till the tranmitter register is empty */
	while (!(_reg_LSR & SIO_LSR_THRE)) ;

	/* write the data to the TX register */
	_reg_THR = c;

	/* Hang around until the character has been safely sent. */
	if (c == '\n') {

		/* Wait till tranmitter register is empty */
		while (!(_reg_LSR & SIO_LSR_THRE)) ;
		_reg_THR = '\r';
	}
}

/*!
 * This functions checks the Receive Data Ready bit in the UART Line Status
 * Register LSR. Bit is set when data is received.
 *
 * @return      This function returns the DR bit from the LSR register
 * of UART
 *
 */
U8 ext_uart_dataready(void)
{
	U8 lsr;
	mxc_wd_reset();
	return (_reg_LSR & SIO_LSR_DR);	/* Read the Data ready bit in LSR */
}

/*!
 * This function gets data from UART. It is used to read character by
 * character of the options and data received by the UART
 *
 * @result      It returns the character received by the UART
 *
 */
U8 ext_uart_getc(void)
{

	/* Wait till the DR bit is set */
	while (!ext_uart_dataready()) {
	}

	return (_reg_RHR & 0xFF);
}

/*!
 * This function sends a line of characters to UART. It calls
 * \b mxcnb_uart_putdata() function to send each character of the line till it
 * encounters the null character as the end of line.
 *
 * @param      __buf            pointer to string to be send to UART
 *
 */
void ext_uart_write(const U8 * __buf)
{
	while (*__buf) {
		ext_uart_putc(*__buf++);
	}
}

/*!
 * This function gets a string data from UART. It reads character by character
 * using \b mxcnb_uart_getdata() function. It takes char pointer as a parameter
 * where the characters of the string are copied
 *
 * @param       __buf     pointer to string data received by UART
 *
 * @return      This function returns the size of the string read from
 * UART.
 */
U32 ext_uart_read(U8 * __buf)
{
	U8 ch;
	int i = 0;

	/*
	 * loop until carriage return is pressed or MAX_STRLEN has
	 * reached
	 */

	do {
		/* read the character received by UART */
		ch = ext_uart_getc();

		/* check if not carriage return */
		if (ch != '\r') {

			/* check if back space */
			if (ch == '\b') {
				if (i > 0) {

					/* erase the character */
					ext_uart_putc('\b');
					ext_uart_putc(' ');
					ext_uart_putc('\b');
					__buf--;
					*__buf = 0;
					i--;
				}
			} else {
				ext_uart_putc(ch);
				*(__buf++) = ch;
				i++;
			}
		}
	} while ((ch != '\r') && (i < MAX_STRLEN - 1));

	/* if and character is typed */
	if (i > 0) {
		*(__buf++) = 0;
	}
	return i;
}

/*!
 * This function sends hex data to UART. It takes 32 bit integer data, 
 * converts it into ascii characters and sends it to UART.
 *
 * @param       hex_data                hex data to send to UART
 *
 */
void ext_uart_puthex(U32 hex_data)
{
	U32 data;
	int i;
	for (i = 7; i >= 0; i--) {

		/* 
		 * Shift nibble at i+1 position to last position and 
		 * AND it with 0xF 
		 */
		data = (hex_data >> 4 * i) & 0xF;
		if (data > 9) {
			data += 55;	/* hex a to f to ascii 'A' to 'F' */
		} else {
			data += '0';	/* hex 0 to 9 to ascii '0' to '9' */
		}
		ext_uart_putc(data);
	}
}

/*!
 * This function reads hex data from UART and stores at the char pointer 
 * passed as a parameter.
 *
 * @param       str             pointer which points to ascii hex data
 *
 * @return  This function returns -1 if incorrect hex data is entered or the 
 * correct hex value entered.
 * 
 */
int ext_uart_gethex(U8 * str)
{
	int size, i = 0;
	U32 addr = 0;
	U8 tmp;

	/* get the ascii hex string from UART */
	size = ext_uart_read(str) - 1;

	/* hex value cannot be greater than 4 bytes or 8 nibbles */
	if (size <= 7) {
		do {
			tmp = 0;
			if (str[size - i] >= '0' && str[size - i] <= '9') {
				tmp = str[size - i] - '0';
			} else {
				if (str[size - i] >= (int)'a'
				    && str[size - i] <= (int)'f') {
					tmp = (str[size - i] - 'a') + 0xa;
				} else {
					if (str[size - i] >= (int)'A'
					    && str[size - i] <= (int)'F') {
						tmp =
						    (str[size - i] - 'A') + 0xa;
					} else {
						/* error if not ascii hex */
						return -1;
					}
				}
			}
			addr |= (tmp << (4 * i));
			i++;
		}
		while ((size - i) >= 0);
	} else {
		return -1;	/* error if more than 8 ascii hex */
	}
	return addr;
}
