
Here is the method to execute the SSI/DAM test applications.
The applications deal with the low level SSI API and low level DAM API.

It configures a data path and play sample.

As a kernel module is needed to execute tests, you will need to compile the module. The module
is compiled as part of all unit tests in misc directory, the only difference being that, when
compiling unit tests you will need to pass an extra parameter on make command-line:

make ARCH=arm CROSS_COMPILE=/opt/montavista/mobilinux/devkit/arm/v6_vfp_le/bin/arm_v6_vfp_le- KBUILD_OUTPUT=$KBUILD_OUTPUT

Where KBUILD_OUTPUT points to directory containing the output of your kernel's compilation. Make sure your toolchain is the
same you used to compile your kernel.

Once module and applications are generated, you can load the module using the insmod command 
(e.g., "insmod /tmp/testmod_ssi.ko") Once the module is loaded, you can use the application.

The test application supports the following options:
	-  ssi_nb_device:  0 for SSI1-STEREODAC
			1 for SSI1-CODEC
			2 for SSI2-STEREODAC
			3 for SSI2-CODEC

	- wavfile: The name of the wav file to be played.

For example:

	$> mxc_ssi_test1.out  0  my_stereo_wav_file.wav
	
Enjoy.

