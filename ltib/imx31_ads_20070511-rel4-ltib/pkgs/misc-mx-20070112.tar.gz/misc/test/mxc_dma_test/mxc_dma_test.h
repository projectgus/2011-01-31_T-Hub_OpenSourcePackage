/*
 * Copyright 2006 Freescale Semiconductor, Inc. All rights reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#ifndef DMA_H
#define DMA_H

#include <linux/ioctl.h>

// ioctl number
#define	DMA_IOC_MAGIC		'v' // stand for: Virtual dma driver

#define	DMA_IOC_SET_SOURCE_ADDR			_IO(DMA_IOC_MAGIC, 0)
#define	DMA_IOC_SET_DEST_ADDR			_IO(DMA_IOC_MAGIC, 1)
#define	DMA_IOC_SET_COUNT				_IO(DMA_IOC_MAGIC, 2)
#define	DMA_IOC_SET_BURST_LENGTH		_IO(DMA_IOC_MAGIC, 3)
#define	DMA_IOC_SET_REQUEST_TMOUT		_IO(DMA_IOC_MAGIC, 4)
#define DMA_IOC_SET_BUS_UTILZ			_IO(DMA_IOC_MAGIC, 5)

#define DMA_IOC_SET_SOURCE_MODE			_IO(DMA_IOC_MAGIC, 6)
#define DMA_IOC_SET_DEST_MODE			_IO(DMA_IOC_MAGIC, 7)
#define DMA_IOC_SET_MEMORY_DIRECTION	_IO(DMA_IOC_MAGIC, 8)
#define DMA_IOC_SET_SOURCE_SIZE			_IO(DMA_IOC_MAGIC, 9)
#define DMA_IOC_SET_DEST_SIZE			_IO(DMA_IOC_MAGIC, 10)

#define DMA_IOC_REQUEST_2D_REG			_IO(DMA_IOC_MAGIC, 11)
#define DMA_IOC_FREE_2D_REG				_IO(DMA_IOC_MAGIC, 12)
#define DMA_IOC_SET_2D_REG_W_SIZE		_IO(DMA_IOC_MAGIC, 13)
#define DMA_IOC_SET_2D_REG_X_SIZE		_IO(DMA_IOC_MAGIC, 14)
#define DMA_IOC_SET_2D_REG_Y_SIZE		_IO(DMA_IOC_MAGIC, 15)
#define DMA_IOC_GET_2D_REG_SET_NR		_IO(DMA_IOC_MAGIC, 16)

#define DMA_IOC_COPY_FROM_DMA_MEMORY	_IO(DMA_IOC_MAGIC, 17)
#define DMA_IOC_COPY_TO_DMA_MEMORY		_IO(DMA_IOC_MAGIC, 18)
#define DMA_IOC_RESIZE_DMA_MEMORY		_IO(DMA_IOC_MAGIC, 19)

#define  DMA_IOC_SET_VERIFY                             _IO(DMA_IOC_MAGIC, 21)
#define  DMA_IOC_QUERY_REPEAT                        _IO(DMA_IOC_MAGIC, 22)
#define  DMA_IOC_SET_REPEAT                            _IO(DMA_IOC_MAGIC, 23)
#define  DMA_IOC_SET_ACRPT                              _IO(DMA_IOC_MAGIC, 24)
#define  DMA_IOC_SET_CONFIG                            _IO(DMA_IOC_MAGIC, 25)
#define  DMA_IOC_QUERY_TRANSFER                   _IO(DMA_IOC_MAGIC, 26)
#define DMA_IOC_SET_TRANSFER_AGAIN           _IO(DMA_IOC_MAGIC, 27)
#define DMA_IOC_TEST_CHAINBUFFER                _IO(DMA_IOC_MAGIC, 28)
//#define DMA_IOC_KMALLOC				_IO(DMA_IOC_MAGIC, 20)


#define MX2_DMA_CHANNELS 16			
#define MAX_DMA_CHANNELS MX2_DMA_CHANNELS
	
#define MX_DMA_CHANNELS		MX2_DMA_CHANNELS		 

#define DMA_MEM_SIZE_8	  0x1
#define DMA_MEM_SIZE_16	0x2
#define DMA_MEM_SIZE_32	0x0

#define DMA_TYPE_LINEAR	0x0
#define DMA_TYPE_2D		0x01
#define DMA_TYPE_FIFO	0x2
#define DMA_TYPE_EBE	0x3

#define DMA_DONE		0x1000
#define DMA_BURST_TIMEOUT 	0x1
#define DMA_REQUEST_TIMEOUT 	0x2
#define DMA_TRANSFER_ERROR	0x4
#define DMA_BUFFER_OVERFLOW	0x8



//Transfer mode
#define LINEAR_MEMORY_MODE	0
#define _2D_MEMORY_MODE		1

//Memory direction
#define ADDR_INC			0
#define ADDR_DEC			1

//Size of data transfer
#define _32_BIT				0
#define _16_BIT				1
#define _8_BIT				2

#endif

