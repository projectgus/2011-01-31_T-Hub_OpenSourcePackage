#ifndef MX27ADS_H_
#define MX27ADS_H_
/*
 *         File : mx27ads.h
 *
 *        Board specific code for MX27 platform.
 */
/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#include "mx27.h"

/*!
 * This defines processor id for the respective processor.
 * This id is passed to the Linux kernel before booting.
 */
#define PROC_ID         	 0x34E 

#define PBC_BASE                 SOC_CS4_BASE    /* Peripheral Bus Controller */
#define PBC_VERSION              0x0
#define PBC_BSTAT2               0x2
#define PBC_BCTRL1               0x4
#define PBC_BCTRL1_CLR           0x6
#define PBC_BCTRL2               0x8
#define PBC_BCTRL2_CLR           0xA
#define PBC_BCTRL3               0xC
#define PBC_BCTRL3_CLR           0xE
#define PBC_BCTRL4               0x10
#define PBC_BCTRL4_CLR           0x12
#define PBC_BSTAT1               0x14
#define BOARD_CS_LAN_BASE        (SOC_CS4_BASE + 0x00040000 + 0x300)
#define BOARD_CS_UART_BASE       (SOC_CS4_BASE + 0x00010000)

#define BOARD_FLASH_START        SOC_CS0_BASE
#define REDBOOT_IMAGE_SIZE       0x40000

#define RAM_BANK0_BASE           SOC_CSD0_BASE

#define SDRAM_BASE_ADDR          SOC_CSD0_BASE
#define SDRAM_SIZE               0x08000000

/*!
 * Command line option address for Linux kernel
 */
#define CMDLINE_ADDR    (U8 *)(SDRAM_BASE_ADDR + 0x100)
/*!
 * Source address where Linux kernel image is stored
 */
#define SOURCE_ADDR     (U32 *)0xC0100000
/*!
 * Destination address where Linux kernel will be copied for execution
 */
#define DESTN_ADDR       (U32 *)(SDRAM_BASE_ADDR + 0x8000)


#define TEXT_START      0xC0000000 /* Text segment start address */

#define SPL_TEXT_START   0xA1000000 /* spl Text segment start address */
#define IPL1_TEXT_START  0xD8000000 /* ipl1 Text segment start address */
#define IPL2_TEXT_START  0xA0000200 /* ipl2 Text segment start address */

/*!
 * Stack start address for C environment
 */

#define STACK_ADDR      0xA0008000

#endif /*End of MX27ADS_H_*/
