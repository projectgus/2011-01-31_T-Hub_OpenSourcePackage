This file contains the information to use the nandboot code

nandboot consists of the following parts:
        - Initial Program Loader (IPL),
        - Secondary Program Loader (SPL)
        - Tools to create NAND flash image

Building and Installing nandboot:
---------------------------------
1) Compile the Linux 2.6 kernel for your MX platform. This generates the Linux
   kernel in arch/arm/boot/zImage. Copy zImage file into image/Image.

2) Build Instructions:
   -------------------
   1. To compile nand bootloader for different platforms, you can modify the
      PLATFORM variable in the Makefile appropriately.

   2. To use a different cross compiler, you can modify the CROSS_COMPILE variable
      to point to a different ARM gcc compiler.

   3. You can use the 'make clean' command to clean any previous object files.
      Note: this will delete your image/Image file.

   4. Run the make command in the nandboot directory. This generates the ipl
      (ipl1 and ipl2), spl, iplspl and tools. This also creates the
      Image_nb_crc file, which is the Linux kernel image with length and CRC
      information added as two 4-byte words at the beginning.

3) Boot Linux (with the NAND MTD driver enabled) using RedBoot.

   Write the bin/MX31ADS_iplspl.bin file into the first NAND partition (for
   example, /dev/mtd/5. Examine /proc/mtd to determine the correct mtd
   partitions to use.).

   Write the image Image_nb_crc into the second NAND partition (for example,
   /dev/mtd/6).

   Write the root filesystem image into third NAND partition (for example,
   /dev/mtd/7). Please note that the Linux kernel should be configured to
   get the rootfs from the correct partition (for example, /dev/mtd/7).

   Reboot the board from NAND (refer to board documentation for switch
   settings). Nandboot should boot up the Linux kernel image from
   /dev/mtd/6.

4) Generate nandboot documentation by executing the command 'make doxygen'.

Configuration of nandboot:
-------------------------

The following parameters are configured in the header file include/mxc.h:

1) UART_OUTPUT : Selects between External or Internal MXC UART
   This value is set to EXT_UART by default.
   Valid values:
        INT_UART - Use Internal MXC UART
        EXT_UART - Use External UART

2) UART_PORT : Selects the UART port number
   if UART_OUTPUT is set to EXT_UART
   Valid values:
        1 - Use  EXT_UART_A
        2 - Use  EXT_UART_B

   if UART_OUTPUT is set to INT_UART
    Valid values
        2 - Use MXC_UART_C

3) WDOG_EN: Enable/Disable Watchdog timer (MMCU_WDOG_1)
   Valid values:
        1 - Enable
        0 - Disable

4) UNIT_TEST: Enable/Disable unit testing of nandboot
   Enabling unit testing will make nandboot to perform unit test before going
   to the main menu.
   Valid values:
        Non-zero  - Enable Unit testing
        0         - Disable unit testing

5)  CRC_EN : Enable/Diable 'Addition CRC' feature in Miniboot
      Valid values
          1 - Enable
          0 - Diable

6)  CHANGE_COMMAND_LINE_OPTION : Enable/Disble change of command line
                                        option in nandboot
         Valid Values
              1 - Enable
              0 - Disable
7) CHANGE_COMMAND_LINE_ADDRESS :  Enable/Disble change of command line
                                  addresss option in nandboot
        Valid Values
              1 - Enable
              0 - Disable

8)  UART_BAUD_RATE : Change UART Baud rate
        Valid values
                9600, 19200, 38400, 57600, 115200

For details of the other configuration parameters, refer to Doxygen generated
documentation for nandboot in full_output directory.

--
