/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mxc_crcgen.c
 * 
 * @brief This is an utility program to write crc and image size in Linux kernel
 * image.
 *
 * This program reads Linux kernel image and generates 'Addition CRC'. It 
 * writes the 4 bytes of size and generated crc value at the beginning of the 
 * Linux kernel image.
 *
 * @ingroup Miniboot and Nandboot
 */
#include<stdio.h>

typedef unsigned int U32;
typedef unsigned char U8;

int main(void)
{
	U32 crc = 0;
	U32 i = 0;
	U8 ch;
	FILE *frd, *fwt;
	fpos_t *pos;
#ifdef miniboot
	char *imgcrc = "../bin/Image_mb_crc";
#elif defined (nandboot)
	char *imgcrc = "../bin/Image_nb_crc";
#endif
	char *img = "../image/Image";
	/* create new image 'Image_crc' with the size and crc written on it */
	fwt = fopen(imgcrc, "wb");
	if (!fwt) {
		printf("Failed to create %s\n", imgcrc);
		return 1;
	}

	/* open to read the Linux kernel image from image folder */
	frd = fopen(img, "rb");

	if (frd) {
		while (fread(&ch, 1, 1, frd)) {
			/* 
			 * generate crc by adding each byte from the Linux
			 * kernel image file. The CRC is addition checksum.
			 */
			crc += ch;
			i++;
		}

		printf("Image size %d crc %d\n", i, crc);
		/* write 4 bytes of size at the beginning of new image */
		fwrite(&i, 4, 1, fwt);
		/* write 4 bytes of crc after size at the beginning of image */
		fwrite(&crc, 4, 1, fwt);

		/* set the file pointer at start of the file */
		rewind(frd);

		/* copy the Linux kernel image byte by byte to image */
		while (fread(&ch, 1, 1, frd)) {
			fwrite(&ch, 1, 1, fwt);
		}

		fclose(frd);	/* close file */
	} else {
		printf("Failed to open %s\n", img);
		return 1;
	}

	fclose(fwt);		/* close file */

	return 0;
}
