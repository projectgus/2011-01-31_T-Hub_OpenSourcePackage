#ifndef MX21ADS_H_
#define MX21ADS_H_
/*
 *        File : mx21ads.h
 *
 *        Platform specific code for MX31 platform.
*/
/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#include "mx21.h"
 
/*!
 * This defines processor id for the respective processor.
 * This id is passed to the Linux kernel before booting.
 */

#define 	PROC_ID         	 0x2C7

#define         PBC_BASE                 CS4_BASE_ADDR    /* Peripheral Bus Controller */
#define         MX21_CS_LAN_BASE         (CS4_BASE_ADDR + 0x00020000 + 0x300)
#define         MX21_CS_UART_BASE        (CS4_BASE_ADDR + 0x00010000)

#define         SDRAM_WORKAROUND_FULL_PAGE
#define         SDRAM_X32

#define         SPL_DEST_ADDR            (U16 *)0xc1000000  /* RAM address where SPL code will be copied*/
#define         SDRAM_BASE_ADDR          0xc0000000  /* MX21 EVB SDRAM is from 0x80000000, 64M */

#ifdef  SDRAM_X32
#define          SDRAM_SIZE              0x04000000
#else
#define          SDRAM_SIZE              0x02000000
#endif /* SDRAM_X32 */

#define         FLASH_BURST_MODE_ENABLE  1
#define         SDRAM_COMPARE_CONST1     0x55555555
#define         SDRAM_COMPARE_CONST2     0xAAAAAAAA

#define MX2ADS_EMI_IOBASE                0xDF000000
/*!
 * Command line option address for Linux kernel
 */
#define CMDLINE_ADDR    (U8 *)0x80000100
/*!
 * Source address where Linux kernel image is stored
 */
#define SOURCE_ADDR     (U32 *)0xA0100000
/*!
 * Destination address where Linux kernel will be copied for execution
 */
#define DESTN_ADDR      (U32 *)0x80008000

#define SPL_TEXT_START   0xC1000000 /* spl Text segment start address */
#define IPL1_TEXT_START  0xDF003000 /* ipl1 Text segment start address */
#define IPL2_TEXT_START  0xC0003200 /* ipl2 Text segment start address */

/*!
 * Stack start address for C environment
 */

#define STACK_ADDR      0xC0008000

#endif /*End of MX21ADS_H_*/
