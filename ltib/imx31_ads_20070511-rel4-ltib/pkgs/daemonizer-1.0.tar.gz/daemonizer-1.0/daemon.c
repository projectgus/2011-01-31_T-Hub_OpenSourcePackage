#include <stdio.h>
#include <unistd.h>

int main(int argc, char* argv[]) {
  if(argc<2) {
	printf("usage: daemon <executable> [<arguments>]\n");
	_exit(0);
  };
  daemon(0,0);
  execve(argv[1],argv+1,0);
  return 0;
};
