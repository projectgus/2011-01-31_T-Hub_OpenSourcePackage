/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file boot.c
 * 
 * @brief Main source file for Nandboot and Miniboot
 *
 * Miniboot is for NOR flash booting. It is simple and essentially does 
 * initial hardware configuration before loading the kernel image. Miniboot 
 * can be used only when the Linux kernel is already in the flash since it 
 * doesn't support image downloading. 
 * 
 * @ingroup NANDboot and Miniboot
 */

#include "mxc.h"
#include "mxc_uart.h"

/*!
 * This function initially calls the system initialization function 
 * It displays menu at the terminal which provides 
 * different options for the kernel loading and then waits for user inputs. 
 * For executing the Linux kernel it calls the \b jump_to_kernel 
 * assembly routine.
 *
 */

void mxc_main(void)
{
	U32 *pmem = DESTN_ADDR;
	U8 *pcmdline = CMDLINE_ADDR;
	U8 hexstr[20];
	int addr, i = 0, timeout = MENU_TIMEOUT;
	U8 boot_option, ch;
#ifdef miniboot
	U32 *pflash = SOURCE_ADDR;
	U32 size = 0;		/* Image size. Don't care if CRC_EN */
#endif

#ifdef nandboot
	U32 kernel_start_block = KERNEL_START_BLOCK_512B;
	U32 g_is_2kpage;
#endif

#if defined(IMX21ADS) || defined(IMX27ADS)
	mx2_init();
#ifdef nandboot
	_reg_CRM_PCDR0 = (_reg_CRM_PCDR0 & 0xffff0fff) | 0x00007000;
#endif
#endif
	/* Initialize Watchdog Timer */
	mxc_wd_init();
	/* Initialize UART */
#if (UART_OUTPUT==INT_UART)
	mxc_uart_init();
#else
	ext_uart_init();
#endif
	/* service WDOG Timer */
	mxc_wd_reset();

#if UNIT_TEST
	mxc_uart_unit_test();
#endif
#ifdef nandboot
	g_is_2kpage = mxcnb_scan_badblocks(kernel_start_block);
	if(g_is_2kpage)
		kernel_start_block = KERNEL_START_BLOCK_2k;
#endif
	/* Display message */
	mxc_outstring("\n\nLinux 2.6 Freescale MXC processor \n");
      menu:
	mxc_outstring("\n\nChoose an option from below:\n\n");
	mxc_outstring("1. Load kernel to RAM and then boot from [0x");
	mxc_puthex(pmem);
	mxc_outstring("]\n");
	mxc_wd_reset();
#if (CHANGE_KERNEL_LOADING_ADDRESS == 1)
	mxc_outstring
	    ("2. Change the Linux kernel destination loading address [0x");
	mxc_puthex(pmem);
	mxc_outstring("]\n");
#endif
#if (CHANGE_COMMAND_LINE_OPTION == 1)
	mxc_outstring("3. Enter command line option for kernel\n");
#endif

#if (CHANGE_COMMAND_LINE_ADDRESS == 1)
	mxc_outstring("4. Change command line option address [0x");
	mxc_puthex(pcmdline);
	mxc_outstring("]\n");
#endif
#ifdef miniboot
#if (CHANGE_KERNEL_SOURCE_ADDRESS==1)
	mxc_outstring("5. Change the Linux kernel source location address [0x");
	mxc_puthex(pflash);
	mxc_outstring("]\n");
#endif
#endif
	mxc_outstring("\n   Please enter selection ->  ");

	mxc_wd_reset();
	/* Loop to receive input from user */
	do {
		mxc_outstring("\b ");
		if (!mxc_timeout(timeout)) {
			boot_option = mxc_getdata();
			mxc_putdata(boot_option);
			if (boot_option >= 0x20) {
				mxc_putdata('\b');
				mxc_putdata(boot_option);
			}

		} else {
			boot_option = '1';
			mxc_outstring("Timeout occured \n\n");
		}
	}
#ifdef nandboot
	while ((boot_option < '1') || (boot_option > '4'));
#endif
#ifdef miniboot
	while ((boot_option < '1') || (boot_option > '5')) ;
#endif
	mxc_wd_reset();

	mxc_outstring("\n\n");

	switch (boot_option) {
		/* Case to copy kernel to RAM from NAND flash and boot */
	case '1':
		mxc_outstring("-->Booting from RAM...\n");

#ifdef nandboot
		if (!mxc_nfb_copykernel((U16 *) pmem, kernel_start_block))
#endif

#ifdef miniboot
#if (CRC_EN == 0)
		mxc_outstring("-->Enter kernel size (4 bytes hex): 0x");
		mxc_wd_reset();
		size = mxc_gethex(hexstr);
		if (size == -1) {
			mxc_outstring("\n-Invalid kernel size ");
			goto menu;
		}
		mxc_puthex(size);
#endif
		if (mxcmb_copy_kernel(pflash, pmem, size) != 0)
#endif
		{
			mxc_outstring("Bad kernel exiting......\n");
			goto menu;
		}
		mxc_wd_reset();

#if defined(IMX21ADS) || defined(IMX27ADS)
		mx2_module_init();
#endif
		mxc_outstring("-->Starting kernel...\n");
		jump_to_kernel(0, PROC_ID, pcmdline, pmem);
		break;

#if (CHANGE_KERNEL_LOADING_ADDRESS ==1)
		/* Case for providing Linux kernel destination address */
	case '2':
		mxc_outstring("-->Address (4 bytes hex): 0x");
		mxc_wd_reset();
		addr = mxc_gethex(hexstr);
		if (addr == -1) {
			mxc_outstring
			    ("\n-Invalid Linux kernel destination address");
			goto menu;
		}
		pmem = (U32 *) addr;
		mxc_puthex(addr);
		mxc_wd_reset();
		goto menu;
		break;
#endif

#if (CHANGE_COMMAND_LINE_OPTION == 1)
		/* Case to enter new command line option */
	case '3':
		mxc_setup_taglist();
		goto menu;
		break;
#endif

		/* Case to change the address location for command line argument */
#if (CHANGE_COMMAND_LINE_ADDRESS == 1)
	case '4':
		mxc_outstring("-->New command line address (4 bytes hex): 0x");
		mxc_wd_reset();
		addr = (int)mxc_gethex(hexstr);

		if (addr == -1) {
			mxc_outstring
			    ("\n-Invalid Linux kernel location address");
			goto menu;
		}
		pcmdline = (U8 *) addr;
		mxc_puthex(addr);
		mxc_wd_reset();
		goto menu;
		break;
#endif
#ifdef miniboot
#if (CHANGE_KERNEL_SOURCE_ADDRESS == 1)
		/* Case for providing Linux kernel source address */
	case '5':
		mxc_outstring("-->Address (4 bytes hex): 0x");
		mxc_wd_reset();
		addr = mxc_gethex(hexstr);
		if (addr == -1) {
			mxc_outstring("\n-Invalid Linux kernel source address");
			goto menu;
		}
		pflash = (U32 *) addr;
		mxc_puthex(addr);
		mxc_wd_reset();
		goto menu;
		break;
#endif
#endif
		/* default case */
	default:
		mxc_outstring("Invalid Entry");
		goto menu;
		break;

	}
}
