/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 *
 * Copyright (c) 2006, Chips & Media.  All rights reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file vpu_codec.h
 *
 * @brief This file implement codec application.
 *
 * @ingroup VPU
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <sys/time.h>
#include <linux/videodev.h>

#include "vpu_voip_test.h"
#include "vpu_display.h"
#include "vpu_capture.h"

extern struct codec_file multi_yuv[MAX_NUM_INSTANCE];
/******  Timing Stuff Begin******/
typedef enum evType_t {
	DEC_READ = 1,
	DEC_RD_OVER,
	DEC_START,
	DEC_STOP,
	DEC_OUT,
	DEC_OUT_OVER,
	ENC_READ,
	ENC_RD_OVER,
	ENC_START,
	ENC_STOP,
	ENC_OUT,
	ENC_OUT_OVER,
	TEST_BEGIN,
	TEST_END,

} evType;

#define MEASURE_COUNT 6000

typedef struct time_rec {
	evType tag;
	struct timeval tval;
} time_rec_t;

time_rec_t time_rec_vector[MEASURE_COUNT + 1];

static unsigned long iter;

unsigned int enc_core_time;
unsigned int enc_core_time_max;
unsigned int enc_core_time_min = 100000;
unsigned int enc_idle_time;
unsigned int enc_idle_time_max;
unsigned int enc_idle_time_min = 100000;

unsigned int dec_core_time;
unsigned int dec_core_time_max;
unsigned int dec_core_time_min = 100000;
unsigned int dec_idle_time;
unsigned int dec_idle_time_max;
unsigned int dec_idle_time_min = 100000;

unsigned int ttl_time = 0;

#define	DIFF_TIME_TV_SEC(i, j)	\
	(time_rec_vector[i].tval.tv_sec - time_rec_vector[j].tval.tv_sec)
#define	DIFF_TIME_TV_USEC(i, j)	\
	(time_rec_vector[i].tval.tv_usec - time_rec_vector[j].tval.tv_usec)
#define DIFF_TIME_US(i, j) (DIFF_TIME_TV_SEC(i, j) * 1000000 + DIFF_TIME_TV_USEC(i, j))

void timer(evType tag)
{
	if (iter >= MEASURE_COUNT)
		return;

	struct timeval tval;
	gettimeofday(&tval, NULL);
	time_rec_vector[iter].tag = tag;
	time_rec_vector[iter].tval = tval;
	iter++;
}

void PrintTimingData(void)
{
#ifdef DEBUG
	unsigned int i = 0;
	unsigned int j = 0, k = 0, m = 0, n = 0;
	unsigned int s1 = 0;
	unsigned int first_enc_start, last_enc_start;
	unsigned int first_dec_start, last_dec_start;
	unsigned int num_enc = 0, num_dec = 0;
	FILE *fp;

//      printf("iter=%d\n", iter);
	if ((fp = fopen("/tmp/vpu.txt", "w")) == NULL)
		printf("Unable to open log file\n");

	while (i < iter) {
		switch (time_rec_vector[i].tag) {
		case ENC_START:
			j = i;
			if (k > 0) {
				enc_idle_time += DIFF_TIME_US(i, k);
				if (enc_idle_time_max < DIFF_TIME_US(i, k))
					enc_idle_time_max = DIFF_TIME_US(i, k);
				if (enc_idle_time_min > DIFF_TIME_US(i, k))
					enc_idle_time_min = DIFF_TIME_US(i, k);

				printf("%8u\n", DIFF_TIME_US(i, k));
				fprintf(fp, "%8u\n", DIFF_TIME_US(i, k));
			} else {
				first_enc_start = i;
			}
			last_enc_start = i;

			printf("Encoding %4u : ", num_enc);
			fprintf(fp, "Encoding %4u : ", num_enc);

			break;
		case ENC_STOP:
			enc_core_time += DIFF_TIME_US(i, j);
			if (enc_core_time_max < DIFF_TIME_US(i, j))
				enc_core_time_max = DIFF_TIME_US(i, j);
			if (enc_core_time_min > DIFF_TIME_US(i, j))
				enc_core_time_min = DIFF_TIME_US(i, j);
			printf("%8u  ", DIFF_TIME_US(i, j));
			fprintf(fp, "%8u  ", DIFF_TIME_US(i, j));
			k = i;
			ttl_time = DIFF_TIME_US(i, 0);
			num_enc++;
			break;
		case DEC_START:
			m = i;
			if (n > 0) {
				dec_idle_time += DIFF_TIME_US(i, n);
				if (dec_idle_time_max < DIFF_TIME_US(i, n))
					dec_idle_time_max = DIFF_TIME_US(i, n);
				if (dec_idle_time_min > DIFF_TIME_US(i, n))
					dec_idle_time_min = DIFF_TIME_US(i, n);

				printf("%8u\n", DIFF_TIME_US(i, n));
				fprintf(fp, "%8u\n", DIFF_TIME_US(i, n));
			} else {
				first_dec_start = i;
			}
			last_dec_start = i;

			printf("Decoding %4u : ", num_dec);
			fprintf(fp, "Decoding %4u : ", num_dec);

			break;
		case DEC_STOP:
			dec_core_time += DIFF_TIME_US(i, m);
			if (dec_core_time_max < DIFF_TIME_US(i, m))
				dec_core_time_max = DIFF_TIME_US(i, m);
			if (dec_core_time_min > DIFF_TIME_US(i, m))
				dec_core_time_min = DIFF_TIME_US(i, m);
			printf("%8u  ", DIFF_TIME_US(i, m));
			fprintf(fp, "%8u  ", DIFF_TIME_US(i, m));
			n = i;
			ttl_time = DIFF_TIME_US(i, 0);
			num_dec++;
			break;
		case TEST_BEGIN:
			s1 = i;

			printf("<Test %4u :", num_dec);
			fprintf(fp, "<Test %4u :", num_dec);

			break;
		case TEST_END:
			printf("%5u >", DIFF_TIME_US(i, s1));
			fprintf(fp, "%5u >", DIFF_TIME_US(i, s1));
			break;
		}

		i++;
	}

	printf
	    ("\n\nSummary of Testing Result(also can see \"/tmp/vpu.txt\"): \n");
	fprintf(fp, "\n\nSummary of Testing Result: \n");
	if (num_enc > 0) {
		printf("Max Encoding time %6u %9u\n", enc_core_time_max,
		       enc_idle_time_max);
		fprintf(fp, "Max Encoding time %6u %9u\n", enc_core_time_max,
			enc_idle_time_max);
		printf("Min Encoding time %6u %9u\n", enc_core_time_min,
		       enc_idle_time_min);
		fprintf(fp, "Min Encoding time %6u %9u\n", enc_core_time_min,
			enc_idle_time_min);
		printf("Enc average time  %6u %9u\n", enc_core_time / num_enc,
		       enc_idle_time / num_enc);
		fprintf(fp, "Enc average time  %6u %9u\n",
			enc_core_time / num_enc, enc_idle_time / num_enc);
		printf("Enc fps = %.1f\n",
		       (float)num_enc * 1000000 / DIFF_TIME_US(last_enc_start,
							       first_enc_start));
		fprintf(fp, "Enc fps = %.1f\n",
			(float)num_enc * 1000000 / DIFF_TIME_US(last_enc_start,
								first_enc_start));
	}
	if (num_dec > 0) {
		printf("Max Decoding time %6u %9u\n", dec_core_time_max,
		       dec_idle_time_max);
		fprintf(fp, "Max Decoding time %6u %9u\n", dec_core_time_max,
			dec_idle_time_max);
		printf("Min Decoding time %6u %9u\n", dec_core_time_min,
		       dec_idle_time_min);
		fprintf(fp, "Min Decoding time %6u %9u\n", dec_core_time_min,
			dec_idle_time_min);
		printf("Dec average time  %6u %9u\n", dec_core_time / num_dec,
		       dec_idle_time / num_dec);
		fprintf(fp, "Dec average time  %6u %9u\n",
			dec_core_time / num_dec, dec_idle_time / num_dec);
		printf("Dec fps = %.1f\n",
		       (float)num_dec * 1000000 / DIFF_TIME_US(last_dec_start,
							       first_dec_start));
		fprintf(fp, "Dec fps = %.1f\n",
			(float)num_dec * 1000000 / DIFF_TIME_US(last_dec_start,
								first_dec_start));
	}

	if (num_enc > 0 && num_dec > 0) {
		printf("Average Frame Rate: %.1f\n",
		       (float)(num_enc + num_dec) * 1000 * 1000 / ttl_time / 2);
		fprintf(fp, "Average Frame Rate: %.1f\n",
			(float)(num_enc +
				num_dec) * 1000 * 1000 / ttl_time / 2);
	}

	printf("\n");
	fprintf(fp, "\n");

	fclose(fp);
#endif
	return;
}

/******  Timing Stuff End******/
extern struct codec_file multi_bitstream[MAX_NUM_INSTANCE];
#define EOSCHECK_APISCHEME

int quitflag = 0;

typedef struct codec_info {
	union {
		CodecInst encHandle;
		CodecInst decHandle;
	};
	FRAME_BUF *FbPool;
	int FbNumber;
	vpu_mem_desc bitstream_buf;
} codec_info;

static struct codec_info enc_info;
static struct codec_info dec_info;

static pthread_mutex_t codec_mutex;
#ifdef INT_CALLBACK
static pthread_mutex_t vpu_busy_mutex;
static pthread_cond_t current_job_cond;
#endif

extern sigset_t mask;

/* FrameBuffer is a round-robin buffer for Current buffer and reference */
int FrameBufferInit(int strideY, int height,
		    FRAME_BUF * FrameBuf, int FrameNumber)
{
	int i;

	for (i = 0; i < FrameNumber; i++) {
		memset(&(FrameBuf[i].CurrImage), 0, sizeof(vpu_mem_desc));
		FrameBuf[i].CurrImage.size = (strideY * height * 3 / 2);
		IOGetPhyMem(&(FrameBuf[i].CurrImage));
		if (FrameBuf[i].CurrImage.phy_addr == 0) {
			printf("No enough mem for framebuffer!\n");
			return -1;
		}
		FrameBuf[i].Index = i;
		FrameBuf[i].AddrY = FrameBuf[i].CurrImage.phy_addr;
		FrameBuf[i].AddrCb = FrameBuf[i].AddrY + strideY * height;
		FrameBuf[i].AddrCr =
		    FrameBuf[i].AddrCb + strideY / 2 * height / 2;
		FrameBuf[i].StrideY = strideY;
		FrameBuf[i].StrideC = strideY / 2;
		FrameBuf[i].DispY = FrameBuf[i].AddrY;
		FrameBuf[i].DispCb = FrameBuf[i].AddrCb;
		FrameBuf[i].DispCr = FrameBuf[i].AddrCr;
		FrameBuf[i].CurrImage.virt_uaddr =
		    IOGetVirtMem(&(FrameBuf[i].CurrImage));
	}
	return 0;
}

void FrameBufferFree(FRAME_BUF * FrameBuf, int FrameNumber)
{
	int i;
	for (i = 0; i < FrameNumber; i++) {
		IOFreeVirtMem(&(FrameBuf[i].CurrImage));
		IOFreePhyMem(&(FrameBuf[i].CurrImage));
	}
	return;
}

int vpu_BitstreamPad(DecHandle handle, char *wrPtr, int size)
{
	CodecInst *pCodecInst;
	DecInfo *pDecInfo;
	int i;

	pCodecInst = handle;
	pDecInfo = &pCodecInst->CodecInfo.decInfo;

	if (pDecInfo->openParam.bitstreamFormat == STD_AVC) {
		((unsigned int *)wrPtr)[i] = 0x0;
		i += 4;
		((unsigned int *)wrPtr)[i] = STD_AVC_ENDBUFDATA;
		i += 4;
		while (i < size) {
			((unsigned int *)wrPtr)[i] = 0x0;
			i += 4;
		}
	} else {
		if (pDecInfo->initialInfo.mp4_shortVideoHeader == 1) {
			((unsigned int *)wrPtr)[i] = 0x0;
			i += 4;
			((unsigned int *)wrPtr)[i] = STD_H263_ENDBUFDATA;
			i += 4;
			while (i < size) {
				((unsigned int *)wrPtr)[i] = 0x0;
				i += 4;
			}
		} else {
			((unsigned int *)wrPtr)[i] = 0x0;
			i += 4;
			((unsigned int *)wrPtr)[i] = STD_MP4_ENDBUFDATA;
			i += 4;
			while (i < size) {
				((unsigned int *)wrPtr)[i] = 0x0;
				i += 4;
			}
		}
	}

	return size;
}

FRAME_BUF *GetFrameBuffer(int index, FRAME_BUF * FrameBuf)
{
	return &FrameBuf[index];
}

int GetFrameBufIndex(FRAME_BUF ** bufPool, int poolSize, FrameBuffer * frame)
{
	int i;

	for (i = 0; i < poolSize; ++i) {
		if ((*bufPool)->AddrY == frame->bufY) {
			return i;
		}
		bufPool++;
	}
	return i;
}

#ifdef INT_CALLBACK
void vpu_test_callback(int status)
{
#if 1
	if (status & IRQ_PIC_RUN) {
#else
	if ((status & IRQ_PIC_RUN) || (status & IRQ_DEC_BUF_EMPTY)) {
#endif
		pthread_mutex_lock(&vpu_busy_mutex);
		pthread_cond_signal(&current_job_cond);
		pthread_mutex_unlock(&vpu_busy_mutex);
	}

	return;
}
#endif

int vpu_SystemInit(void)
{
	int ret = -1;
	pthread_mutex_init(&codec_mutex, NULL);
#ifdef INT_CALLBACK
	pthread_mutex_init(&vpu_busy_mutex, NULL);
	pthread_cond_init(&current_job_cond, NULL);

	ret = IOSystemInit((void *)(vpu_test_callback));
#else
	ret = IOSystemInit(NULL);
#endif

	if (ret < 0) {
		printf("IO system init failed!\n");
		return -1;
	}
	return ret;
}

int vpu_SystemShutdown(void)
{
	if (enc_info.FbNumber) {
		vpu_EncClose(&(enc_info.encHandle));
		FrameBufferFree(enc_info.FbPool, enc_info.FbNumber);
		IOFreeVirtMem(&(enc_info.bitstream_buf));
		IOFreePhyMem(&(enc_info.bitstream_buf));
		memset(&enc_info, 0, sizeof(struct codec_info));
	}
	if (dec_info.FbNumber) {
		vpu_DecClose(&(dec_info.decHandle));
		FrameBufferFree(dec_info.FbPool, dec_info.FbNumber);
		IOFreeVirtMem(&(dec_info.bitstream_buf));
		IOFreePhyMem(&(dec_info.bitstream_buf));
		memset(&dec_info, 0, sizeof(struct codec_info));
	}
	IOSystemShutdown();
	PrintTimingData();
	DPRINTF("file close end\n");

	return 0;
}

int FillBsBuffer(DecHandle handle, int bsBufStartAddr, int phy_decoder, 
			char * bsBuf0, int size0)
{
	RetCode ret;
	Uint32 size;
	int room;
	unsigned char* pBuf;
	PhysicalAddress paWrPtr;	
	PhysicalAddress paRdPtr;

	ret = vpu_DecGetBitstreamBuffer(handle, &paRdPtr, &paWrPtr, &size);
	if( ret != RETCODE_SUCCESS ){
		printf("vpu_DecGetBitstreamBuffer failed Error code is 0x%x \n",  ret);
		return 0;
	}
	if (size >= size0) {
		pBuf = (unsigned char *)(bsBufStartAddr +(paWrPtr - phy_decoder));
		room = (phy_decoder + STREAM_BUF_SIZE) - paWrPtr;
		if((paWrPtr + size0) > (phy_decoder + STREAM_BUF_SIZE)){
			memcpy((unsigned char*)pBuf, bsBuf0, room);
			memcpy((unsigned char*)bsBufStartAddr, bsBuf0+room, size0-room);
		}
		else
			memcpy((unsigned char*)pBuf, bsBuf0, size0);

		ret = vpu_DecUpdateBitstreamBuffer(handle, size0);
		if( ret != RETCODE_SUCCESS ){
			printf("vpu_DecUpdateBitstreamBuffer failed Error code is 0x%x \n",  ret);
		}
		
		return size0;
	}

	return 0;
}

/* 
 * Encode/Decode Duplex Test.
 * Encode 2 Frames first. Then Encode 1 Frame and Decode 1 Frame, back and forth.
 */
int loopback_opt(void *enc_param, void *dec_param)
{
	/****************************************************************/
	/*	Encoder Initialization					*/
	/****************************************************************/
	EncHandle encHandle = { 0 };
	EncOpenParam encOP = { 0 };
	EncParam encParam = { 0 };
	EncInitialInfo encInitialInfo = { 0 };
	EncOutputInfo encOutputInfo = { 0 };
	SearchRamParam searchPa = { 0 };
	RetCode ret;
	PhysicalAddress bsBuf0;
	Uint32 size0;
	int srcFrameIdx;
	int extra_fb_enc = 1;

	/* FMO(Flexible macroblock ordering) support */ 
	int fmoEnable = 0; 
	int fmoSliceNum = 2; 
	int fmoType = 0;	/* 0 - interleaved, or 1 - dispersed */

	struct codec_config *enc_usr_config = (struct codec_config *)enc_param;
	int mode = enc_usr_config->mode;
	int picWidth = enc_usr_config->width;
	int picHeight = enc_usr_config->height;
	int bitRate;
	bitRate = enc_usr_config->bps;
	DPRINTF("Enc mode264 %d, width %d, height %d, bitrate %d\n",
		mode, picWidth, picHeight, bitRate);

	memset(&enc_info, 0, sizeof(struct codec_info));
	FRAME_BUF *pEncFrame[NUM_FRAME_BUF];
	FrameBuffer encFrameBuf[NUM_FRAME_BUF];
	FRAME_BUF encFrameBufPool[MAX_FRAME];
	int i;
	int encFrameIdx;
	int enc_rot_en = 0;
	int enc_output_ratio = 4;
	struct v4l2_buffer prp_buffer;
	int enc_image_size;
	/* allocate the bit stream buffer */
	vpu_mem_desc enc_bit_stream_buf;
	memset(&enc_bit_stream_buf, 0, sizeof(vpu_mem_desc));
	enc_bit_stream_buf.size = STREAM_BUF_SIZE;
//	pthread_mutex_lock(&codec_mutex);
	IOGetPhyMem(&enc_bit_stream_buf);
	int enc_virt_bit_stream_buf = IOGetVirtMem(&enc_bit_stream_buf);
	//pthread_mutex_unlock(&codec_mutex);
	encOP.bitstreamBuffer = enc_bit_stream_buf.phy_addr;
	encOP.bitstreamBufferSize = STREAM_BUF_SIZE;
	encOP.bitstreamFormat = mode;
	encOP.picWidth = picWidth;
	encOP.picHeight = picHeight;
	encOP.frameRateInfo = 30;
	encOP.bitRate = bitRate;
	encOP.initialDelay = 0;
	encOP.vbvBufferSize = 0;	/* 0 = ignore 8 */
	encOP.enableAutoSkip = 0;
	encOP.gopSize = 0;	/* only first picture is I */
	encOP.sliceMode = 0;	/* 1 slice per picture */
	encOP.sliceSizeMode = 0;
	encOP.sliceSize = 4000;	/* not used if sliceMode is 0 */
	encOP.intraRefresh = 0;
	encOP.sliceReport = 0;
	encOP.mbReport = 0;
	encOP.mbQpReport = 0;

	if (mode == STD_MPEG4) {
		encOP.EncStdParam.mp4Param.mp4_dataPartitionEnable = 0;
		encOP.EncStdParam.mp4Param.mp4_reversibleVlcEnable = 0;
		encOP.EncStdParam.mp4Param.mp4_intraDcVlcThr = 0;
	} else if (mode == STD_H263) {
		encOP.EncStdParam.h263Param.h263_annexJEnable = 0;
		encOP.EncStdParam.h263Param.h263_annexKEnable = 0;
		encOP.EncStdParam.h263Param.h263_annexTEnable = 0;
		if (encOP.EncStdParam.h263Param.h263_annexJEnable == 0 &&
		    encOP.EncStdParam.h263Param.h263_annexKEnable == 0 &&
			encOP.EncStdParam.h263Param.h263_annexTEnable == 0 ) {
			encOP.frameRateInfo = 0x3E87530;
		}
	} else {
		encOP.EncStdParam.avcParam.avc_constrainedIntraPredFlag = 0;
		encOP.EncStdParam.avcParam.avc_disableDeblk = 0;
		encOP.EncStdParam.avcParam.avc_deblkFilterOffsetAlpha = 0;
		encOP.EncStdParam.avcParam.avc_deblkFilterOffsetBeta = 0;
		encOP.EncStdParam.avcParam.avc_chromaQpOffset = 0;
		encOP.EncStdParam.avcParam.avc_audEnable = 0;
		encOP.EncStdParam.avcParam.avc_fmoEnable = fmoEnable;
		encOP.EncStdParam.avcParam.avc_fmoType = fmoType;
		encOP.EncStdParam.avcParam.avc_fmoSliceNum = fmoSliceNum;
	}

//	pthread_mutex_lock(&codec_mutex);
	ret = vpu_EncOpen(&encHandle, &encOP);
	if (ret != RETCODE_SUCCESS) {
		printf("vpu_EncOpen failed. Error code is %d \n", ret);
		goto ERR_ENC_INIT;
	}

	searchPa.searchRamAddr = DEFAULT_SEARCHRAM_ADDR;
	ret = vpu_EncGiveCommand(encHandle, SET_ENC_SEARCHRAM_PARAM, &searchPa);
	if (ret != RETCODE_SUCCESS) {
		printf
		    ("vpu_EncGiveCommand ( SET_ENC_SEARCHRAM_PARAM ) failed. Error code is %d \n",
		     ret);
		goto ERR_ENC_OPEN;
	}

	ret = vpu_EncGetInitialInfo(encHandle, &encInitialInfo);
	if (ret != RETCODE_SUCCESS) {
		printf("vpu_EncGetInitialInfo failed. Error code is %d \n",
		       ret);
		goto ERR_ENC_OPEN;
	}

	DPRINTF("ENC min buffer count= %d\n", encInitialInfo.minFrameBufferCount);

	/* allocate the image buffer, rec buffer/ref buffer plus src buffer */
	FrameBufferInit(picWidth, picHeight,
			encFrameBufPool,
			encInitialInfo.minFrameBufferCount + extra_fb_enc);


	enc_info.FbPool = encFrameBufPool;
	enc_info.FbNumber = encInitialInfo.minFrameBufferCount + extra_fb_enc;
	memcpy(&(enc_info.bitstream_buf), &enc_bit_stream_buf,
	       sizeof(struct vpu_mem_desc));
	memcpy(&(enc_info.encHandle), &encHandle, sizeof(DecHandle));

	srcFrameIdx = encInitialInfo.minFrameBufferCount;

	for (i = 0; i < encInitialInfo.minFrameBufferCount + extra_fb_enc; ++i) {
		pEncFrame[i] = GetFrameBuffer(i, encFrameBufPool);
		encFrameBuf[i].bufY = pEncFrame[i]->AddrY;
		encFrameBuf[i].bufCb = pEncFrame[i]->AddrCb;
		encFrameBuf[i].bufCr = pEncFrame[i]->AddrCr;
	}
	ret = vpu_EncRegisterFrameBuffer(encHandle, encFrameBuf,
					 encInitialInfo.minFrameBufferCount,
					 picWidth);
	if (ret != RETCODE_SUCCESS) {
		printf("vpu_EncRegisterFrameBuffer failed.Error code is %d \n",
		       ret);
		goto ERR_ENC_OPEN;
	}

	//pthread_mutex_unlock(&codec_mutex);

	DPRINTF("Disp %x, %x, %x\n, Store buf %x, %x, %x\n",
		pEncFrame[srcFrameIdx]->DispY,
		pEncFrame[srcFrameIdx]->DispCb,
		pEncFrame[srcFrameIdx]->DispCr,
		(unsigned int)encFrameBuf[srcFrameIdx].bufY,
		(unsigned int)encFrameBuf[srcFrameIdx].bufCb,
		(unsigned int)encFrameBuf[srcFrameIdx].bufCr);
	encFrameIdx = 0;
	encParam.sourceFrame = &encFrameBuf[srcFrameIdx];
	encParam.quantParam = 30;
	enc_image_size = picWidth * picHeight;
	memset(&prp_buffer, 0, sizeof(struct v4l2_buffer));

	/****************************************************************/
	/*	Decoder Initialization					*/
	/****************************************************************/
	const int dec_extra_fb = 1;
	struct codec_config *dec_usr_config = (struct codec_config *)dec_param;
	DecHandle decHandle = { 0 };
	DecOpenParam decOP = { 0 };
	DecInitialInfo decInitialInfo = { 0 };
	DecOutputInfo decOutputInfo = { 0 };
	DecParam decParam = { 0 };
	//RetCode ret;
	PhysicalAddress paWrPtr;
	PhysicalAddress paRdPtr;
	PhysicalAddress paBsBufStart;
	PhysicalAddress paBsBufEnd;
	int decFrameIdx = 0, totalNumofErrMbs = 0, fillendBs = 0, decodefinish = 0;
	int streameof = 0;
	int checkeof = 0;
	Uint32 size = 0;
	Uint32 fRateInfo = 0;
	FRAME_BUF decFrameBufPool[MAX_FRAME];

	FRAME_BUF *pDecFrame[NUM_FRAME_BUF];
	FrameBuffer decFrameBuf[NUM_FRAME_BUF];

	checkeof = 1;

	memset(&dec_info, 0, sizeof(struct codec_info));
	//int i;
	struct v4l2_buffer pp_buffer;
	int dec_output_ratio;
	int dec_image_size;
	int dec_rot_en = 0;
	int dec_rot_angle;
	int dec_mirror_dir;
	int rotStride;
	int storeImage;
	int pad_count;

	switch (dec_usr_config->mode) {
	case 0:
		decOP.bitstreamFormat = STD_MPEG4;
		DPRINTF("Dec mode: MPEG4\n");
		break;
	case 1:
		decOP.bitstreamFormat = STD_H263;
		DPRINTF("Dec mode: H.263\n");
		break;
	case 2:
		decOP.bitstreamFormat = STD_AVC;
		DPRINTF("Dec mode: H.264\n");
		break;
	}

//	pthread_mutex_lock(&codec_mutex);

	vpu_mem_desc dec_bit_stream_buf;
	memset(&dec_bit_stream_buf, 0, sizeof(vpu_mem_desc));
	dec_bit_stream_buf.size = STREAM_BUF_SIZE;
	IOGetPhyMem(&dec_bit_stream_buf);
	int dec_virt_bit_stream_buf = IOGetVirtMem(&dec_bit_stream_buf);
	decOP.bitstreamBuffer = dec_bit_stream_buf.phy_addr;
	decOP.bitstreamBufferSize = STREAM_BUF_SIZE;
	paBsBufStart = dec_virt_bit_stream_buf;
	paBsBufEnd = paBsBufStart + decOP.bitstreamBufferSize;
	decOP.qpReport = 0;

	decOP.reorderEnable = 0;

	/* Get buffer position and Fill Buffer */
	ret = vpu_DecOpen(&decHandle, &decOP);
	if (ret != RETCODE_SUCCESS) {
		printf("vpu_DecOpen failed. Error code is %d \n", ret);
		goto ERR_DEC_INIT;
	}

	/****************************************************************/
	/*	Fill 2 Frames Begin					*/
	/****************************************************************/
	while (encFrameIdx < 2) {
		if (encFrameIdx % 100 == 0)
			DPRINTF(" Inst %d, No. %d\n",
				((EncInst *) encHandle)->instIndex, encFrameIdx);
		ret =
		    FillYuvImageMulti(enc_usr_config->src, enc_usr_config->src_name,
				      encFrameBuf[srcFrameIdx].bufY +
				      encFrameBufPool[srcFrameIdx].CurrImage.
				      virt_uaddr -
				      encFrameBufPool[srcFrameIdx].CurrImage.
				      phy_addr, (void *)&prp_buffer, picWidth,
				      picHeight,
				      ((EncInst *) encHandle)->instIndex,
				      CODEC_READING, enc_rot_en, enc_output_ratio, 0);
		if (enc_usr_config->src == PATH_EMMA) {
			encFrameBuf[srcFrameIdx].bufY =
			    cap_buffers[prp_buffer.index].offset;
			encFrameBuf[srcFrameIdx].bufCb =
			    encFrameBuf[srcFrameIdx].bufY + enc_image_size;
			encFrameBuf[srcFrameIdx].bufCr =
			    encFrameBuf[srcFrameIdx].bufCb + (enc_image_size >> 2);
		}
		if (ret < 0) {
			printf("Encoder finished\n");
			break;
		}
//		pthread_mutex_lock(&codec_mutex);
		ret = vpu_EncStartOneFrame(encHandle, &encParam);
		if (ret != RETCODE_SUCCESS) {
			printf
			    ("vpu_EncStartOneFrame failed. Error code is %d \n",
			     ret);
//			pthread_mutex_unlock(&codec_mutex);
			goto ERR_ENC_OPEN;
		}
//		timer(ENC_START);
#ifdef INT_CALLBACK
		pthread_mutex_lock(&vpu_busy_mutex);
		pthread_cond_wait(&current_job_cond, &vpu_busy_mutex);
		pthread_mutex_unlock(&vpu_busy_mutex);
#else
		vpu_WaitForInt(200);
#endif
//		timer(ENC_STOP);

		ret = vpu_EncGetOutputInfo(encHandle, &encOutputInfo);
		if (ret != RETCODE_SUCCESS) {
			printf
			    ("vpu_EncGetOutputInfo failed. Error code is %d \n",
			     ret);
			goto ERR_ENC_OPEN;
		}

		//pthread_mutex_unlock(&codec_mutex);

		if (quitflag)
			break;

		bsBuf0 = encOutputInfo.bitstreamBuffer;
		size0 = encOutputInfo.bitstreamSize;
#if 0 // use FillBsBuffer instead.
		ret = FillBsBufMulti(enc_usr_config->dst, enc_usr_config->dst_name,
				     enc_virt_bit_stream_buf + bsBuf0 -
				     enc_bit_stream_buf.phy_addr, 0,
				     0, size0,
				     ((EncInst *) encHandle)->instIndex,
				     0, 0, CODEC_WRITING);
#endif
		ret = FillBsBuffer(decHandle, dec_virt_bit_stream_buf, dec_bit_stream_buf.phy_addr, 
					(unsigned char*)(enc_virt_bit_stream_buf + bsBuf0 -
                                     enc_bit_stream_buf.phy_addr), size0); 

		if (encOP.mbQpReport == 1) {
			SaveQpReport(encOutputInfo.mbQpInfo, encOP.picWidth,
				encOP.picHeight, encFrameIdx, "encqpreport.dat" );
		}

		encFrameIdx++;
	}
	/****************************************************************/
	/*	Fill 2 Frames end					*/
	/****************************************************************/

#if 0 // use FillBsBuffer instead.
	ret = vpu_DecGetBitstreamBuffer(decHandle, &paRdPtr, &paWrPtr, &size);
	if (ret != RETCODE_SUCCESS) {
		printf("vpu_DecGetBitstreamBuffer failed. Error code is %d \n",
		       ret);
		goto ERR_DEC_OPEN;
	}

	pthread_mutex_unlock(&codec_mutex);
	ret = FillBsBufMulti(dec_usr_config->src, dec_usr_config->src_name,
			     dec_virt_bit_stream_buf + paWrPtr -
			     dec_bit_stream_buf.phy_addr, paBsBufStart,
			     paBsBufEnd, STREAM_FILL_SIZE,
			     ((DecInst *) decHandle)->instIndex, checkeof,
			     &streameof, CODEC_READING);
	if (ret < 0) {
		printf("FillBsBufMulti failed. Error code is %d\n", ret);
		vpu_SystemShutdown();
		return &codec_thread[dec_usr_config->index];
	}
	pthread_mutex_lock(&codec_mutex);
	ret = vpu_DecUpdateBitstreamBuffer(decHandle, STREAM_FILL_SIZE);
	if (ret != RETCODE_SUCCESS) {
		printf
		    ("vpu_DecUpdateBitstreamBuffer failed. Error code is %d \n",
		     ret);
		goto ERR_DEC_OPEN;
	}
#endif

	vpu_DecSetEscSeqInit(decHandle, 1);

	/* Parse bitstream and get width/height/framerate/h264/mp4 info etc. */
	ret = vpu_DecGetInitialInfo(decHandle, &decInitialInfo);
	if (ret != RETCODE_SUCCESS) {
		printf
		    ("vpu_DecUpdateBitstreamBuffer failed. Error code is %d \n",
		     ret);
		goto ERR_DEC_OPEN;
	}

	vpu_DecSetEscSeqInit(decHandle, 0);

	DPRINTF("DEC min buffer count= %d\n", decInitialInfo.minFrameBufferCount);
	fRateInfo = decInitialInfo.frameRateInfo;
	DPRINTF
	    ("Dec InitialInfo =>\npicWidth: %u, picHeight: %u, frameRate: %u\n",
	     decInitialInfo.picWidth, decInitialInfo.picHeight,
	     (unsigned int)decInitialInfo.frameRateInfo);

	/* If use PP, then donot need to allocate this Framebuffer, use PP buffer directly. */
	if (dec_usr_config->dst != PATH_EMMA) {
		/* Frame Buffer Pool needed is the minFrameBufferCount +1 loopfilter, 
		   if rotation yes, should also add 1 */
		ret = FrameBufferInit(decInitialInfo.picWidth, decInitialInfo.picHeight,
				      decFrameBufPool,
				      decInitialInfo.minFrameBufferCount + dec_extra_fb);
		if (ret < 0) {
			printf("Mem system allocation failed!\n");
		}
	}

	dec_info.FbPool = decFrameBufPool;
	dec_info.FbNumber = decInitialInfo.minFrameBufferCount + dec_extra_fb;
	memcpy(&(dec_info.bitstream_buf), &dec_bit_stream_buf,
	       sizeof(vpu_mem_desc));
	memcpy(&(dec_info.decHandle), &decHandle, sizeof(DecHandle));

	/* If use PP, then donot need to allocate this Framebuffer, use PP buffer directly. */
	if (dec_usr_config->dst != PATH_EMMA) {
		/* Get the image buffer */
		for (i = 0; i < decInitialInfo.minFrameBufferCount + dec_extra_fb; ++i) {
			pDecFrame[i] = GetFrameBuffer(i, decFrameBufPool);
			decFrameBuf[i].bufY = pDecFrame[i]->AddrY;
			decFrameBuf[i].bufCb = pDecFrame[i]->AddrCb;
			decFrameBuf[i].bufCr = pDecFrame[i]->AddrCr;
		}
	}

	memset(&pp_buffer, 0, sizeof(struct v4l2_buffer));
	dec_image_size = decInitialInfo.picWidth * decInitialInfo.picHeight;

	dec_output_ratio = dec_usr_config->out_ratio;

	if (dec_usr_config->dst == PATH_EMMA) {
		if (!multi_yuv[((DecInst *) decHandle)->instIndex].fd) {
			multi_yuv[((DecInst *) decHandle)->instIndex].fd = (FILE *)	
			    emma_dev_open(decInitialInfo.picWidth, decInitialInfo.picHeight, CODEC_WRITING,
					  dec_output_ratio, decInitialInfo.minFrameBufferCount);

		}
	
		for (i = 0; i < decInitialInfo.minFrameBufferCount; ++i) {
			decFrameBuf[i].bufY = buffers[i].offset;
			decFrameBuf[i].bufCb = decFrameBuf[i].bufY + dec_image_size;
			decFrameBuf[i].bufCr =
			    decFrameBuf[i].bufCb + (dec_image_size >> 2);
		}
	}

	/* Set the frame buffer array to the structure */
	ret = vpu_DecRegisterFrameBuffer(decHandle, decFrameBuf,
					 decInitialInfo.minFrameBufferCount,
					 decInitialInfo.picWidth);
	if (ret != RETCODE_SUCCESS) {
		printf("vpu_DecRegisterFrameBuffer failed. Error code is %d \n",
		       ret);
		goto ERR_DEC_OPEN;
	}
#ifdef EOSCHECK_APISCHEME
	decParam.dispReorderBuf = 0;
	decParam.prescanEnable = 1;
	decParam.prescanMode = 0;
#else
	decParam.dispReorderBuf = 0;
	decParam.prescanEnable = 0;
	decParam.prescanMode = 0;
#endif
	decParam.skipframeMode = 0;
	decParam.skipframeNum = 0;
	decParam.iframeSearchEnable = 0;

//	pthread_mutex_unlock(&codec_mutex);

	FRAME_BUF *pDispFrame;
	FrameBuffer *emma_buffer;
	dec_rot_angle = dec_usr_config->rot_angle;
	dec_mirror_dir = dec_usr_config->mirror_angle;

//	emma_buffer = &decFrameBuf[decInitialInfo.minFrameBufferCount + 1];
	dec_rot_en = (dec_rot_angle == 90 || dec_rot_angle == 270) ? 1 : 0;
#if 0
	vpu_DecGiveCommand(decHandle, SET_ROTATION_ANGLE, &dec_rot_angle);
#endif
	//vpu_DecGiveCommand(decHandle, SET_MIRROR_DIRECTION, &dec_mirror_dir);
	storeImage = 1;
	rotStride = (dec_rot_angle == 90 || dec_rot_angle == 270) ?
	    decInitialInfo.picHeight : decInitialInfo.picWidth;
	rotStride = storeImage ? rotStride : STRIDE;
#if 0
	vpu_DecGiveCommand(decHandle, SET_ROTATOR_STRIDE, &rotStride);
#endif

	/****************************************************************/
	/* 	End of Docoder Initialization 				*/
	/****************************************************************/

	/****************************************************************/
	/*	Encoder One Frame, and then Decode One Frame		*/
	/****************************************************************/
	while (1) {
		if (encFrameIdx % 100 == 0)
			DPRINTF(" Inst %d, No. %d\n",
				((EncInst *) encHandle)->instIndex, encFrameIdx);
		ret =
		    FillYuvImageMulti(enc_usr_config->src, enc_usr_config->src_name,
				      encFrameBuf[srcFrameIdx].bufY +
				      encFrameBufPool[srcFrameIdx].CurrImage.
				      virt_uaddr -
				      encFrameBufPool[srcFrameIdx].CurrImage.
				      phy_addr, (void *)&prp_buffer, picWidth,
				      picHeight,
				      ((EncInst *) encHandle)->instIndex,
				      CODEC_READING, enc_rot_en, enc_output_ratio, 0);
		if (enc_usr_config->src == PATH_EMMA) {
			encFrameBuf[srcFrameIdx].bufY =
			    cap_buffers[prp_buffer.index].offset;
			encFrameBuf[srcFrameIdx].bufCb =
			    encFrameBuf[srcFrameIdx].bufY + enc_image_size;
			encFrameBuf[srcFrameIdx].bufCr =
			    encFrameBuf[srcFrameIdx].bufCb + (enc_image_size >> 2);
		}
		if (ret < 0) {
			printf("Encoder finished\n");
			break;
		}
//		pthread_mutex_lock(&codec_mutex);
		ret = vpu_EncStartOneFrame(encHandle, &encParam);
		if (ret != RETCODE_SUCCESS) {
			printf
			    ("vpu_EncStartOneFrame failed. Error code is %d \n",
			     ret);
//			pthread_mutex_unlock(&codec_mutex);
			goto ERR_ENC_OPEN;
		}
		timer(ENC_START);
#ifdef INT_CALLBACK
		pthread_mutex_lock(&vpu_busy_mutex);
		pthread_cond_wait(&current_job_cond, &vpu_busy_mutex);
		pthread_mutex_unlock(&vpu_busy_mutex);
#else
		vpu_WaitForInt(200);
#endif
		timer(ENC_STOP);

		ret = vpu_EncGetOutputInfo(encHandle, &encOutputInfo);
		if (ret != RETCODE_SUCCESS) {
			printf
			    ("vpu_EncGetOutputInfo failed. Error code is %d \n",
			     ret);
			goto ERR_ENC_OPEN;
		}

//		pthread_mutex_unlock(&codec_mutex);

		if (quitflag) {
			break;
		}

		bsBuf0 = encOutputInfo.bitstreamBuffer;
		size0 = encOutputInfo.bitstreamSize;
#if 0
		ret = FillBsBufMulti(enc_usr_config->dst, enc_usr_config->dst_name,
				     enc_virt_bit_stream_buf + bsBuf0 -
				     enc_bit_stream_buf.phy_addr, 0,
				     0, size0,
				     ((EncInst *) encHandle)->instIndex,
				     0, 0, CODEC_WRITING);
#endif
		ret = FillBsBuffer(decHandle, dec_virt_bit_stream_buf, dec_bit_stream_buf.phy_addr, 
					(unsigned char*)(enc_virt_bit_stream_buf + bsBuf0 -
                                     enc_bit_stream_buf.phy_addr), size0); 

		if (encOP.mbQpReport == 1) {
			SaveQpReport(encOutputInfo.mbQpInfo, encOP.picWidth,
				encOP.picHeight, encFrameIdx, "encqpreport.dat" );
		}

		encFrameIdx++;
//	while (1) {

		if (decFrameIdx % 100 == 0)
			DPRINTF(" Inst %d, No. %d\n",
				((DecInst *) decHandle)->instIndex, decFrameIdx);

//              printf("decFrameIdx = %d\n", decFrameIdx);
#ifdef EOSCHECK_APISCHEME
		if (decOP.reorderEnable == 1 &&
		    decOP.bitstreamFormat == STD_AVC) {
			static int prescanEnable;
			if (decFrameIdx == 0) {
				prescanEnable = decParam.prescanEnable;
				decParam.prescanEnable = 0;
			} else if (decFrameIdx == 1)
				decParam.prescanEnable = prescanEnable;
		}
#endif

//		pthread_mutex_lock(&codec_mutex);

#if 0
		vpu_DecGiveCommand(decHandle, SET_ROTATOR_OUTPUT,
				   (void *)emma_buffer);
		if (decFrameIdx == 0) {
			vpu_DecGiveCommand(decHandle, ENABLE_ROTATION, 0);
			//vpu_DecGiveCommand(decHandle, ENABLE_MIRRORING, 0);
		}
#endif
		if (dec_usr_config->dst == PATH_EMMA) {
			FillYuvImageMulti(dec_usr_config->dst, dec_usr_config->dst_name,
	//				  pDispFrame->AddrY +
				//	  pDispFrame->CurrImage.virt_uaddr -
				//	  pDispFrame->CurrImage.phy_addr,
	//				  pDispFrame->CurrImage.virt_uaddr,
						0,
					  (void *)&pp_buffer, decInitialInfo.picWidth,
					  decInitialInfo.picHeight,
					  ((DecInst *) decHandle)->instIndex,
					  CODEC_WRITING, dec_rot_en, dec_output_ratio, 0);
		}

		/* Start decoding a frame. */
		ret = vpu_DecStartOneFrame(decHandle, &decParam);
		if (ret != RETCODE_SUCCESS) {
			printf
			    ("vpu_DecStartOneFrame failed. Error code is %d \n",
			     ret);
			//pthread_mutex_unlock(&codec_mutex);
			goto ERR_DEC_OPEN;
		}

		/* fill the bitstream buffer while the system is busy */
		timer(DEC_START);
#ifdef INT_CALLBACK
		pthread_mutex_lock(&vpu_busy_mutex);
		pthread_cond_wait(&current_job_cond, &vpu_busy_mutex);
		pthread_mutex_unlock(&vpu_busy_mutex);
#else
		vpu_WaitForInt(200);
#endif
		timer(DEC_STOP);

		if (quitflag) {
			//pthread_mutex_unlock(&codec_mutex);
			break;
		}

		/*
		 * vpu_DecGetOutputInfo() should match vpu_DecStartOneFrame() with
		 * the same handle. No other API functions can intervene between these two
		 * functions, except for vpu_IsBusy(), vpu_DecGetBistreamBuffer(),
		 * and vpu_DecUpdateBitstreamBuffer().
		 */
		ret = vpu_DecGetOutputInfo(decHandle, &decOutputInfo);
		if (ret != RETCODE_SUCCESS) {
			printf
			    ("vpu_DecGetOutputInfo failed. Error code is %d \n",
			     ret);
		}
//              printf("output index = %d\n", decOutputInfo.indexDecoded);
		if (decOutputInfo.indexDecoded == -1)
			decodefinish = 1;

		ret =
		    vpu_DecGetBitstreamBuffer(decHandle, &paRdPtr, &paWrPtr,
					      &size);
//		pthread_mutex_unlock(&codec_mutex);
#if 0 // FillBsBuffer do what FillBsBufMulti do instead.
		if (size >= STREAM_FILL_SIZE) {
			/* will the speed match with the bitprocessor? */
			ret =
			    FillBsBufMulti(dec_usr_config->src,
					   dec_usr_config->src_name,
					   dec_virt_bit_stream_buf + paWrPtr -
					   dec_bit_stream_buf.phy_addr,
					   paBsBufStart, paBsBufEnd,
					   STREAM_FILL_SIZE,
					   ((DecInst *) decHandle)->instIndex,
					   checkeof, &streameof, CODEC_READING);
			if (ret < 0) {
				if (ferror
				    (multi_bitstream
				     [((DecInst *) decHandle)->instIndex].fd)) {
					printf
					    ("FillBsBufMulti failed. Error code is %d \n",
					     ret);
					goto ERR_DEC_OPEN;
				}
			}
#ifdef EOSCHECK_APISCHEME
			if (streameof == 0) {
				ret = vpu_DecUpdateBitstreamBuffer(decHandle,
								   STREAM_FILL_SIZE);
				if (ret != RETCODE_SUCCESS) {
					printf
					    ("vpu_DecUpdateBitstreamBuffer failed. Error code is %d \n",
					     ret);
					goto ERR_DEC_OPEN;
				}

			} else {
				if (!fillendBs) {
					vpu_BitstreamPad(decHandle,
							 dec_virt_bit_stream_buf +
							 paWrPtr -
							 dec_bit_stream_buf.
							 phy_addr,
							 STREAM_END_SIZE);
					ret =
					    vpu_DecUpdateBitstreamBuffer(decHandle,
									 STREAM_END_SIZE);
					if (ret != RETCODE_SUCCESS) {
						printf
						    ("vpu_DecUpdateBitstreamBuffer failed. Error code is %d \n",
						     ret);
						goto ERR_DEC_OPEN;
					}
					fillendBs = 1;
				}
			}
#else
			if (streameof == 0) {
				ret = vpu_DecUpdateBitstreamBuffer(decHandle,
								   STREAM_FILL_SIZE);
				if (ret != RETCODE_SUCCESS) {
					printf
					    ("vpu_DecUpdateBitstreamBuffer failed. Error code is %d \n",
					     ret);
					goto ERR_DEC_OPEN;
				}
			}
#endif
		}
#endif
#ifdef EOSCHECK_APISCHEME
		if (decOutputInfo.prescanresult == 0 &&
		    decParam.dispReorderBuf == 0) {
			if (streameof) {
				if (decOP.reorderEnable == 1 &&
				    decOP.bitstreamFormat == STD_AVC &&
				    (decOutputInfo.indexDecoded != -1)) {
					decParam.dispReorderBuf = 1;
					continue;
				} else {
					decodefinish = 1;
				}
			} else {	/* not enough bitstream data */
				printf("PreScan result: Not enough bitstream data\n");
				continue;
			}
		}
#endif
		if (decodefinish)
			break;

		pDispFrame =
		    GetFrameBuffer(decOutputInfo.indexDecoded, decFrameBufPool);

		if (dec_usr_config->dst != PATH_EMMA) {
		FillYuvImageMulti(dec_usr_config->dst, dec_usr_config->dst_name,
				  pDispFrame->AddrY +
				  pDispFrame->CurrImage.virt_uaddr -
				  pDispFrame->CurrImage.phy_addr,
				  (void *)&pp_buffer, decInitialInfo.picWidth,
				  decInitialInfo.picHeight,
				  ((DecInst *) decHandle)->instIndex,
				  CODEC_WRITING, dec_rot_en, dec_output_ratio, 0);
		}
#if 0
		if (dec_usr_config->dst == PATH_EMMA) {
			emma_buffer->bufY = buffers[pp_buffer.index].offset;
			emma_buffer->bufCb = emma_buffer->bufY + dec_image_size;
			emma_buffer->bufCr =
			    emma_buffer->bufCb + (dec_image_size >> 2);
		}
#endif

		if (decOP.qpReport == 1)
			SaveQpReport(decOutputInfo.qpInfo, decInitialInfo.picWidth,
				decInitialInfo.picHeight, decFrameIdx, "decqpreport.dat" );

		if (decOutputInfo.numOfErrMBs) {
			totalNumofErrMbs += decOutputInfo.numOfErrMBs;
			printf("Num of Error Mbs : %d, in Frame : %d \n", decOutputInfo.numOfErrMBs, decFrameIdx);
		}

		decFrameIdx++;
	//}

	}

	if (totalNumofErrMbs) {
		printf("Total Num of Error MBs : %d\n", totalNumofErrMbs);
	}

      ERR_DEC_OPEN:
//	pthread_mutex_lock(&codec_mutex);
	vpu_DecClose(decHandle);
	if (ret == RETCODE_FRAME_NOT_COMPLETE) {
		vpu_DecGetOutputInfo(decHandle, &decOutputInfo);
		vpu_DecClose(decHandle);
	}
//	pthread_mutex_unlock(&codec_mutex);

      ERR_DEC_INIT:
	FrameBufferFree(decFrameBufPool,
			decInitialInfo.minFrameBufferCount + dec_extra_fb);
	IOFreeVirtMem(&dec_bit_stream_buf);
	IOFreePhyMem(&dec_bit_stream_buf);
	memset(&dec_info, 0, sizeof(struct codec_info));
	DPRINTF("Dec closed\n");

      ERR_ENC_OPEN:
//	pthread_mutex_lock(&codec_mutex);
	ret = vpu_EncClose(encHandle);
	if (ret == RETCODE_FRAME_NOT_COMPLETE) {
		vpu_EncGetOutputInfo(encHandle, &encOutputInfo);
		vpu_EncClose(encHandle);
	}
//	pthread_mutex_unlock(&codec_mutex);

      ERR_ENC_INIT:
	FrameBufferFree(encFrameBufPool,
			encInitialInfo.minFrameBufferCount + extra_fb_enc);
	IOFreeVirtMem(&enc_bit_stream_buf);
	IOFreePhyMem(&enc_bit_stream_buf);
	DPRINTF("Enc closed\n");
	memset(&enc_info, 0, sizeof(struct codec_info));

}

void *sig_thread(void *arg)
{
	DPRINTF("Enter signal monitor thread.\n");
	int signo;

	if (sigwait(&mask, &signo) != 0) {
		printf("sigwait error\n");
	}

	switch (signo) {
	case SIGINT:
		DPRINTF("interrupt: SIGINT.\n");
		quitflag = 1;
#ifdef INT_CALLBACK
		pthread_cond_broadcast(&current_job_cond);
#endif
		break;
	default:
		printf("unexpected signal %d\n", signo);
	}

	return;
}
