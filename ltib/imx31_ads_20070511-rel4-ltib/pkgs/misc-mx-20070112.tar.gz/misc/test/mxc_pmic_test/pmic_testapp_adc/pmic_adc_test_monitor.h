/*============================================================================*/
/**
    @file   pmic_adc_test_monitor.h

    @brief  Test scenario C header PMIC.
*/
/*==============================================================================

  Copyright (C) 2004, Freescale Semiconductor, Inc. All Rights Reserved
  THIS SOURCE CODE IS CONFIDENTIAL AND PROPRIETARY AND MAY NOT
  BE USED OR DISTRIBUTED WITHOUT THE WRITTEN PERMISSION OF
  Freescale Semiconductor, Inc.
     
================================================================================

Revision History:
                            Modification     Tracking
Author (core ID)                Date          Number    Description of Changes
-------------------------   ------------    ----------  -----------------------
Developer QUINTERO/JQUI1C     27/09/2005     DSPhl26599   Initial version

==============================================================================*/

#ifndef PMIC_ADC_TEST_MONITOR_H
#define PMIC_ADC_TEST_MONITOR_H

#ifdef __cplusplus
extern "C"{
#endif

/*==============================================================================
                                     FUNCTION PROTOTYPES
==============================================================================*/
int VT_pmic_adc_monitor_setup();
int VT_pmic_adc_monitor_cleanup();
int VT_pmic_adc_test_monitor(void);

#ifdef __cplusplus
}
#endif

#endif  // PMIC_ADC_TEST_MONITOR_H //
