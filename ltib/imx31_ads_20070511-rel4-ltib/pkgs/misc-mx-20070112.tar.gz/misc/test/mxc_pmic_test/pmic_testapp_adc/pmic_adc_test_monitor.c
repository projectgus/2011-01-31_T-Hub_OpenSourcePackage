/*============================================================================*/
/**
    @file   pmic_adc_test_monitor.c

    @brief  Test scenario C source PMIC.
*/
/*==============================================================================

  Copyright (C) 2004, Freescale Semiconductor, Inc. All Rights Reserved
  THIS SOURCE CODE IS CONFIDENTIAL AND PROPRIETARY AND MAY NOT
  BE USED OR DISTRIBUTED WITHOUT THE WRITTEN PERMISSION OF
  Freescale Semiconductor, Inc.
     
================================================================================
Revision History:
                            Modification     Tracking
Author                          Date          Number    Description of Changes
-------------------------   ------------    ----------  -----------------------
Developer QUINTERO/JQUI1C     27/09/2005     DSPhl26599   Initial version

================================================================================
Portability: Indicate if this module is portable to other compilers or 
             platforms. 
             If not, indicate specific reasons why is it not portable.

==============================================================================*/

#ifdef __cplusplus
extern "C"{
#endif

/*==============================================================================
                                        INCLUDE FILES
==============================================================================*/
/* Standard Include Files */
#include <errno.h>
    
/* Harness Specific Include Files. */
#include "test.h"

/* Verification Test Environment Include Files */
#include "pmic_adc_test.h"
#include "pmic_adc_test_monitor.h"
#include "pmic_adc_test_read.h"

extern int fd_adc;

/*==============================================================================
                                       LOCAL FUNCTIONS
==============================================================================*/

/*============================================================================*/
/*===== VT_pmic_adc_monitor_setup =====*/
/**
@brief  assumes the initial condition of the test case execution

@param  None
  
@return On success - return TPASS
        On failure - return the error code
*/
/*============================================================================*/
int VT_pmic_adc_monitor_setup(void)
{
    int rv = TFAIL;
    rv=TPASS;
    return rv;
}

/*============================================================================*/
/*===== VT_pmic_adc_monitor_cleanup =====*/
/**
@brief  assumes the post-condition of the test case execution

@param  None
  
@return On success - return TPASS
        On failure - return the error code
*/
/*============================================================================*/
int VT_pmic_adc_monitor_cleanup(void)
{
    int rv = TFAIL;
    rv=TPASS;
    return rv;
}

/*============================================================================*/
static void callback_wcomp(void)
{
        printf(("\tADC Monitoring test event"));
}

/*============================================================================*/
/*===== VT_pmic_adc_test_monitor =====*/
/**
@brief  PMIC test scenario monitor functionG

@param  None
  
@return On success - return TPASS
        On failure - return the error code
*/
/*============================================================================*/
int VT_pmic_adc_test_monitor(void)
{
        t_adc_comp_param mon_param;
        
        mon_param.wlow = 3;
        mon_param.whigh = 60;
        mon_param.channel = BATTERY_CURRENT; 
        mon_param.callback = (t_comparator_cb*)callback_wcomp;

        printf(("Test monitoring ADC functions\n"));
        if (ioctl(fd_adc, PMIC_ADC_ACTIVATE_COMPARATOR, & mon_param) != 0) {
                printf(("Error in ADC monitoring test\n"));
                return TFAIL;
        }
        if (ioctl(fd_adc, PMIC_ADC_DEACTIVE_COMPARATOR, 0) != 0) {
                printf(("Error in ADC monitoring test\n"));
                return TFAIL;
        }
        return TPASS;
}

#ifdef __cplusplus
}
#endif
