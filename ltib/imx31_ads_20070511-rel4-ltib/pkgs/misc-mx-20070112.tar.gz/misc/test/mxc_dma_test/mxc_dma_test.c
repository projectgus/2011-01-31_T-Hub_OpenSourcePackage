/*
 * Copyright 2006 Freescale Semiconductor, Inc. All rights reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/************************************/
//DMA Test Driver
/************************************/
#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<malloc.h>
#include <unistd.h>
//#include<asm/memory.h>
#include<asm/page.h>
#include<sys/ioctl.h>


#ifdef CONFIG_ARCH_MX2ADS
#include <asm/dma.h>
#include <asm/arch/dma.h>
#endif

#include "mxc_dma_test.h"

#define DMA_BURST_LENGTH_4 4
#define DMA_BURST_LENGTH_8 8
#define DMA_BURST_LENGTH_16 16
#define DMA_BURST_LENGTH_32 32
#define DMA_BURST_LENGTH_64 0


int Test_1D_to_1D(void)
{


	int iCount = 0x1000;
	int iBurstLength =4;
	unsigned long arg;
	int fd;
       fd = open("/tmp/dma", O_RDWR);
       if(fd < 0)
	{
		printf("can not open file dma.\n");
		return -1;
	}
	/*make sure that count set before the source mode*/
	arg = 0;
	ioctl(fd,DMA_IOC_SET_SOURCE_ADDR,arg);
	ioctl(fd,DMA_IOC_SET_DEST_ADDR,arg);
	
	arg = iCount;
	ioctl(fd,DMA_IOC_SET_COUNT,arg);
	
	arg = DMA_MEM_SIZE_32;
	ioctl(fd,DMA_IOC_SET_SOURCE_SIZE,arg);

	arg = DMA_MEM_SIZE_32;
	ioctl(fd,DMA_IOC_SET_DEST_SIZE,arg);

	arg = DMA_TYPE_LINEAR;
	ioctl(fd,DMA_IOC_SET_SOURCE_MODE,arg);
	
	arg = DMA_TYPE_LINEAR;
	ioctl(fd,DMA_IOC_SET_DEST_MODE,arg);


       /*when 8 bit transfer , burstlength is needed*/
	arg = iBurstLength;
	ioctl(fd,DMA_IOC_SET_BURST_LENGTH,arg);

	arg = ADDR_INC;
	ioctl(fd,DMA_IOC_SET_MEMORY_DIRECTION,arg);
       printf("begin set config.\n");	
       ioctl(fd,DMA_IOC_SET_CONFIG,NULL);
       printf("Set 1D to 1D para.\n");

	/*Begin DMA*/
	read(fd,NULL,0);
	
	printf("get verify.\n");
	ioctl(fd,DMA_IOC_SET_VERIFY,NULL);

	close(fd);
	return 0;
}


int Test_2D_to_2D(void)
{
	unsigned long arg;
       int ix = 0x40;
	int iy = 0x10;
	int iw = 0x80;
	int iCount = ix*iy;
       int iBurstLength = DMA_BURST_LENGTH_64;
       int fd;
       fd = open("/tmp/dma", O_RDWR);
       if(fd < 0)
	{
		printf("can not open file dma.\n");
		return -1;
	}
	/*make sure that count set before the source mode and after x/y/w*/
	arg = 0;
	ioctl(fd,DMA_IOC_SET_SOURCE_ADDR,arg);
	ioctl(fd,DMA_IOC_SET_DEST_ADDR,arg);
	
       arg = ix;
	ioctl(fd,DMA_IOC_SET_2D_REG_X_SIZE,arg);
	
       arg = iy;
	ioctl(fd,DMA_IOC_SET_2D_REG_Y_SIZE,arg);

	arg = iw;
	ioctl(fd,DMA_IOC_SET_2D_REG_W_SIZE,arg);
	
	arg = iCount;
	ioctl(fd,DMA_IOC_SET_COUNT,arg);
	
	arg = DMA_MEM_SIZE_32;
	ioctl(fd,DMA_IOC_SET_SOURCE_SIZE,arg);

	arg = DMA_MEM_SIZE_32;
	ioctl(fd,DMA_IOC_SET_DEST_SIZE,arg);

	arg = DMA_TYPE_2D;
	ioctl(fd,DMA_IOC_SET_SOURCE_MODE,arg);
	
	arg = DMA_TYPE_2D;
	ioctl(fd,DMA_IOC_SET_DEST_MODE,arg);

	arg = iBurstLength;
	ioctl(fd,DMA_IOC_SET_BURST_LENGTH,arg);

	arg = ADDR_INC;
	ioctl(fd,DMA_IOC_SET_MEMORY_DIRECTION,arg);
      
       ioctl(fd,DMA_IOC_SET_CONFIG,NULL);
       printf("Set 2D to 2D para. \n");

	/*Begin DMA*/
	read(fd,NULL,0);
	printf("get verify.\n");
	ioctl(fd,DMA_IOC_SET_VERIFY,NULL);
	close(fd);
	return 0;
}




int Test_1D_to_2D(void)
{
	unsigned long arg;
       int ix = 0x80;
	int iy = 0x10;
	int iw = 0x100;
	int iCount = ix*iy;
       int iBurstLength = 4;
	int fd;
       fd = open("/tmp/dma", O_RDWR);
       if(fd < 0)
	{
		printf("can not open file dma.\n");
		return -1;
	}
	/*make sure that count set before the source mode and after x/y/w*/
	arg = 0;
	ioctl(fd,DMA_IOC_SET_SOURCE_ADDR,arg);
	ioctl(fd,DMA_IOC_SET_DEST_ADDR,arg);
	
       arg = ix;
	ioctl(fd,DMA_IOC_SET_2D_REG_X_SIZE,arg);
	
       arg = iy;
	ioctl(fd,DMA_IOC_SET_2D_REG_Y_SIZE,arg);

	arg = iw;
	ioctl(fd,DMA_IOC_SET_2D_REG_W_SIZE,arg);
	
	arg = iCount;
	ioctl(fd,DMA_IOC_SET_COUNT,arg);
	
	arg = DMA_MEM_SIZE_32;
	ioctl(fd,DMA_IOC_SET_SOURCE_SIZE,arg);

	arg = DMA_MEM_SIZE_32;
	ioctl(fd,DMA_IOC_SET_DEST_SIZE,arg);

	arg = DMA_TYPE_LINEAR;
	ioctl(fd,DMA_IOC_SET_SOURCE_MODE,arg);
	
	arg = DMA_TYPE_2D;
	ioctl(fd,DMA_IOC_SET_DEST_MODE,arg);

	arg = iBurstLength;
	ioctl(fd,DMA_IOC_SET_BURST_LENGTH,arg);

       arg = ADDR_DEC;
	ioctl(fd,DMA_IOC_SET_MEMORY_DIRECTION,arg);

       ioctl(fd,DMA_IOC_SET_CONFIG,NULL);
       printf("Set 1D to 2D para. \n");

	/*Begin DMA*/
	read(fd,NULL,0);
	printf("get verify.\n");
	ioctl(fd,DMA_IOC_SET_VERIFY,NULL);
	close(fd);
	return 0;
}




int Test_2D_to_1D(void)
{
	unsigned long arg;
       int ix = 0x100;
	int iy = 0x10;
	int iw = 0x100;
	int iCount = ix*iy;
       int iBurstLength = 4;
	int fd;
       fd = open("/tmp/dma", O_RDWR);
       if(fd < 0)
	{
		printf("can not open file dma.\n");
		return -1;
	}
	/*make sure that count set before the source mode and after x/y/w*/
	arg = 0;
	ioctl(fd,DMA_IOC_SET_SOURCE_ADDR,arg);
	ioctl(fd,DMA_IOC_SET_DEST_ADDR,arg);
	
       arg = ix;
	ioctl(fd,DMA_IOC_SET_2D_REG_X_SIZE,arg);
	
       arg = iy;
	ioctl(fd,DMA_IOC_SET_2D_REG_Y_SIZE,arg);

	arg = iw;
	ioctl(fd,DMA_IOC_SET_2D_REG_W_SIZE,arg);
	
	arg = iCount;
	ioctl(fd,DMA_IOC_SET_COUNT,arg);
	
	arg = DMA_MEM_SIZE_32;
	ioctl(fd,DMA_IOC_SET_SOURCE_SIZE,arg);

	arg = DMA_MEM_SIZE_32;
	ioctl(fd,DMA_IOC_SET_DEST_SIZE,arg);

	arg = DMA_TYPE_2D;
	ioctl(fd,DMA_IOC_SET_SOURCE_MODE,arg);
	
	arg = DMA_TYPE_LINEAR;
	ioctl(fd,DMA_IOC_SET_DEST_MODE,arg);

	arg = iBurstLength;
	ioctl(fd,DMA_IOC_SET_BURST_LENGTH,arg);

       arg = ADDR_INC;
	ioctl(fd,DMA_IOC_SET_MEMORY_DIRECTION,arg);

       ioctl(fd,DMA_IOC_SET_CONFIG,NULL);
	printf("Set 2D to 1D para. \n");

	/*Begin DMA*/
	read(fd,NULL,0);

	printf("get verify.\n");
	ioctl(fd,DMA_IOC_SET_VERIFY,NULL);
	close(fd);
	return 0;
}




int Test_By_Input(char* argv[])
{
	unsigned long arg;
	unsigned long ulSourceMode,ulDestMode;
       unsigned long ulSourcePort, ulDestPort;
       unsigned long X, Y, W;
       unsigned long ulCount;
       unsigned long ulDirection, ulBurstLength;
       unsigned long ulRepeat;
	
	int fd;
      	ulSourceMode = atoi(argv[2]);
	ulDestMode = atoi(argv[3]);
       ulSourcePort = atoi(argv[4]);
	ulDestPort = atoi(argv[5]);
       X = atoi(argv[6]);
	Y = atoi(argv[7]);
	W = atoi(argv[8]);
       ulCount = atoi(argv[9]);
       ulDirection = atoi(argv[10]);
	ulBurstLength = atoi(argv[11]);
       ulRepeat = atoi(argv[12]);

     	/*make sure the rationality of the para*/
       if(X>W)
	{
             printf("W should be no less than X. \n");          
		return -1;
       }
	if(ulSourceMode>3||ulDestMode>3)
	{
              printf("SourceMode and DestMode should be no greater than 3. \n");      
       	return -1;
	}
	if(ulSourcePort>2||ulDestPort>2)
	{
              printf("SourcePort and DestPort should be no greater than 2. \n");      
       	return -1;
	}
	if(ulBurstLength>63)
	{
             printf("BurstLength should be no greater than 64. \n");      
		return -1;
	}
	if((ulDirection>1)|(ulRepeat>1))
	 {
              printf("Direction and Repeat should be no greater than 1. \n");      
		return -1;
	}

       if(ulSourceMode==DMA_TYPE_2D||ulDestMode==DMA_TYPE_2D)
              ulCount = X*Y;
	if(ulCount>0x1000)
	{
              printf("Count should be less than one page size. \n");      
		return -1;
	}
       fd = open("/tmp/dma", O_RDWR);
       if(fd < 0)
	{
		printf("can not open file dma.\n");
		return -1;
	}
	/*make sure the rationality of the para*/
       arg = 0;
	ioctl(fd,DMA_IOC_SET_SOURCE_ADDR,arg);
	ioctl(fd,DMA_IOC_SET_DEST_ADDR,arg);
	
	arg = X;
	ioctl(fd,DMA_IOC_SET_2D_REG_X_SIZE,arg);
	
       arg = Y;
	ioctl(fd,DMA_IOC_SET_2D_REG_Y_SIZE,arg);

	arg = W;
	ioctl(fd,DMA_IOC_SET_2D_REG_W_SIZE,arg);

       arg = ulCount;
	ioctl(fd,DMA_IOC_SET_COUNT,arg);
	
	arg = ulSourcePort;
	ioctl(fd,DMA_IOC_SET_SOURCE_SIZE,arg);

	arg = ulDestPort;
	ioctl(fd,DMA_IOC_SET_DEST_SIZE,arg);

	/*set direction before the sourc emode*/
       arg = ulDirection;
	ioctl(fd,DMA_IOC_SET_MEMORY_DIRECTION,arg);

	arg = ulSourceMode;
	ioctl(fd,DMA_IOC_SET_SOURCE_MODE,arg);
	
	arg = ulDestMode;
	ioctl(fd,DMA_IOC_SET_DEST_MODE,arg);

	arg = ulBurstLength;
	ioctl(fd,DMA_IOC_SET_BURST_LENGTH,arg);

       ioctl(fd,DMA_IOC_SET_CONFIG,NULL);
       printf("Set by self para. \n");

	/*Begin DMA*/
	read(fd,NULL,0);

	printf("get verify.\n");
	ioctl(fd,DMA_IOC_SET_VERIFY,NULL);
	close(fd);
	return 0;
}




int Test_ChainBuffer(unsigned int iTransTime)
{
	unsigned long arg;
       int fd;
	if(iTransTime>8 || iTransTime < 3)
	{
               printf("Error transtime, it may between 3 to 8.\n");
		 return -1;
	}
       fd = open("/tmp/dma", O_RDWR);
       if(fd < 0)
	{
		printf("can not open file dma.\n");
		return -1;
	}
       /*this ioctl start testing the chainbuffer*/
	arg = iTransTime;
	ioctl(fd,DMA_IOC_TEST_CHAINBUFFER,arg);	
	close(fd);
	return 0;
}




int Test_Bus(void)
{


	int iCount = 0x1000;
	int iBurstLength =4;
	unsigned long arg;
	int fd;
       fd = open("/tmp/dma", O_RDWR);
       if(fd == 0)
	{
		printf("can not open file dma.\n");
		return -1;
	}
	/*make sure that count set before the source mode*/
	int i;
	for(i=0;i<5;i++)
	{
		arg = 0;
		ioctl(fd,DMA_IOC_SET_SOURCE_ADDR,arg);
		ioctl(fd,DMA_IOC_SET_DEST_ADDR,arg);
		
		arg = iCount;
		ioctl(fd,DMA_IOC_SET_COUNT,arg);
		
		arg = DMA_MEM_SIZE_32;
		ioctl(fd,DMA_IOC_SET_SOURCE_SIZE,arg);

		arg = DMA_MEM_SIZE_32;
		ioctl(fd,DMA_IOC_SET_DEST_SIZE,arg);

		arg = DMA_TYPE_LINEAR;
		ioctl(fd,DMA_IOC_SET_SOURCE_MODE,arg);
		
		arg = DMA_TYPE_LINEAR;
		ioctl(fd,DMA_IOC_SET_DEST_MODE,arg);


	       /*when 8 bit transfer , burstlength is needed*/
		arg = iBurstLength;
		ioctl(fd,DMA_IOC_SET_BURST_LENGTH,arg);

		arg = ADDR_INC;
		ioctl(fd,DMA_IOC_SET_MEMORY_DIRECTION,arg);
		
	       ioctl(fd,DMA_IOC_SET_CONFIG,NULL);
	       printf("Set 1D to 1D para.\n");

		/*Begin DMA*/
		read(fd,NULL,0);
	
		printf("get verify.\n");
		ioctl(fd,DMA_IOC_SET_VERIFY,NULL);
		sleep(2);
	}
	close(fd);
	return 0;
}




int Test_16_Channel(void)
{
       int iCount = 0x1000;
	int iBurstLength =4;
	unsigned long arg;
       int fd[16];
       int i;
	for(i=0;i<16;i++)
      {      
               fd[i] = open("/tmp/dma", O_RDWR);
               if(fd[i] == 0)
	       {
		printf("can not open file dma %d.\n",i);
		return -1;
	       }

              arg = 0;
	       ioctl(fd[i],DMA_IOC_SET_SOURCE_ADDR,arg);
	       ioctl(fd[i],DMA_IOC_SET_DEST_ADDR,arg);
	
	       arg = iCount;
	       ioctl(fd[i],DMA_IOC_SET_COUNT,arg);
	
	       arg = DMA_MEM_SIZE_32;
	       ioctl(fd[i],DMA_IOC_SET_SOURCE_SIZE,arg);

	      arg = DMA_MEM_SIZE_32;
	      ioctl(fd[i],DMA_IOC_SET_DEST_SIZE,arg);

	      arg = DMA_TYPE_LINEAR;
	      ioctl(fd[i],DMA_IOC_SET_SOURCE_MODE,arg);
	
	      arg = DMA_TYPE_LINEAR;
	      ioctl(fd[i],DMA_IOC_SET_DEST_MODE,arg);


             /*when 8 bit transfer , burstlength is needed*/
	      arg = iBurstLength;
	      ioctl(fd[i],DMA_IOC_SET_BURST_LENGTH,arg);

	      arg = ADDR_INC;
	      ioctl(fd[i],DMA_IOC_SET_MEMORY_DIRECTION,arg);
	            
             ioctl(fd[i],DMA_IOC_SET_CONFIG,NULL);
             printf("Set 1D to 1D para.\n");

	}            
      printf("Set 16 Channel para.\n");
      for(i=0;i<16;i++)
      {  
	     /*Begin DMA*/
	    read(fd[i],NULL,0);
	    printf("get Buffer %d verify.\n",i);
	    ioctl(fd[i],DMA_IOC_SET_VERIFY,NULL);
	    close(fd[i]);
	    
      	}
	
	return 0;
}



int main(int argc, char* argv[])
{
	int iInputChoice;
	if (argc<2)
	{
            printf("Function para needed. \n");        
            printf("0 test 1d-1d linear DMA. \n");        
            printf("1 test 2d-2d linear DMA. \n");       
	     printf("2 test 1d-2d linear DMA. \n");       
	     printf("3 test 2d-1d linear DMA. \n");       
	     printf("4 test DMA by your input. \n");      
	     printf("5 test Chain Buffer DMA. \n");       
	     printf("6 test 16 channel. \n");      
		 
	     return -1;	
       }
	else   
	{
	       iInputChoice = atoi(argv[1]); 
              switch (iInputChoice)
	       {
	              case 0:
		  	     Test_1D_to_1D();
		  	     break;
		       case 1:
                          Test_2D_to_2D();
			     break;
                     case 2:
                          Test_1D_to_2D();
			     break;
			case 3:
                          Test_2D_to_1D();
			     break;
			case 4:
                     {
			    if(argc<13)
                         {
                                printf("Specified para needed. \n");        
              	           return -1;	
                         }
			   Test_By_Input(argv);
			   break;
			}
			case 5:
                           if(argc==3)
			          Test_ChainBuffer(atoi(argv[2]));
				else		   
                             {
                                printf("Please Specify No. of buffers in para 2. \n");        
              	           return -1;	
                              }
				break;
			case 6:
				Test_16_Channel();
				break;
			case 7:
				Test_Bus();
				break;

			default:
                          printf("Please enter choice between 0 to 6.\n");
			     break;
              }
	}
	return 0;		
}

