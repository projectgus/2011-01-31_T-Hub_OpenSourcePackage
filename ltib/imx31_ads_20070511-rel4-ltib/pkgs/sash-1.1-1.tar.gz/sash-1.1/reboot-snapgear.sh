#! /bin/sh

echo "Please stand by while rebooting the system ..."
exec killall -HUP flatfsd
