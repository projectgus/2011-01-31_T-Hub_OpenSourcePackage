#include "../../gettext-tools/lib/getopt1.c"
