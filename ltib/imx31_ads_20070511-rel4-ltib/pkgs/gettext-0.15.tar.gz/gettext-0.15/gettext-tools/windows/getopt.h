/* The system doesn't have <getopt.h>.  Use our getopt.h emulation.  */
#include "getopt_.h"
