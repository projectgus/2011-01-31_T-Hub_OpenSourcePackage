/* ptpd.h */

#ifndef PTPD_H
#define PTPD_H

#include "constants.h"
#include "dep/constants_dep.h"
#include "dep/datatypes_dep.h"
#include "datatypes.h"
#include "dep/ptpd_dep.h"


/* arith.c */
UInteger32 crc_algorithm(const Octet*,Integer16);
void sub_pos_times(TimeRepresentation*,TimeRepresentation*,TimeRepresentation*);
void add_pos_times(TimeRepresentation*,TimeRepresentation*,TimeRepresentation*);
void subTime(TimeRepresentation*,TimeRepresentation*,TimeRepresentation*);
void addTime(TimeRepresentation*,TimeRepresentation*,TimeRepresentation*);
void divTime(TimeRepresentation*,TimeRepresentation*,Integer32);

/* bmc.c */
UInteger8 bmc(ForeignMasterRecord*,RunTimeOpts*,PtpClock*);
void M1(PtpClock*);
void S1(MsgHeader*,MsgSync*,PtpClock*);
void initData(RunTimeOpts*,PtpClock*);

/* probe.c */
void probe(RunTimeOpts*,PtpClock*);

/* protocol.c */
void protocol(RunTimeOpts*,PtpClock*);


#endif

