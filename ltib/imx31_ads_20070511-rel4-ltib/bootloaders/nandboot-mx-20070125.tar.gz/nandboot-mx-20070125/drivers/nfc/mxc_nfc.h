#ifndef MXC_NFC_H
#define MXC_NFC_H
/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mxc_nfc.h
 * 
 * @brief This file contains the NAND Flash Controller register information. 
 *
 * 
 * @ingroup NANDboot
 */

#include "mxc.h"

/*!
 * @name Addresses for NFC registers
 */

/*! @{ */

/*!
 * NFC buffer size register
 */
#define NFC_BUF_SIZE            (*((volatile U16 *)(NFC_BASE+0xE00)))

/*!
 * NFC RAM buffer address register
 */
#define NFC_BUFFER_ADDR         (*((volatile U16 *)(NFC_BASE+0xE04)))

/*!
 * NFC flash address register
 */
#define NFC_FLASH_ADDR          (*((volatile U16 *)(NFC_BASE+0xE06)))

/*!
 * NFC flash command register
 */
#define NFC_FLASH_CMD           (*((volatile U16 *)(NFC_BASE+0xE08)))

/*!
 * NFC configuration register 
 */
#define NFC_CONFIG              (*((volatile U16 *)(NFC_BASE+0xE0A)))

/*!
 * NFC status register
 */
#define NFC_STATUS_RESULT       (*((volatile U16 *)(NFC_BASE+0xE0C)))

/*!
 * NFC spare area result register 
 */
#define MFC_RSLTSPARE_AREA      (*((volatile U16 *)(NFC_BASE+0xE10)))

/*!
 * NFC write protect register 
 */
#define NFC_WRPROT              (*((volatile U16 *)(NFC_BASE+0xE12)))

/*!
 * NFC start block address register for unlocking buffer
 */
#define NFC_UNLOCKSTART_BLKADDR (*((volatile U16 *)(NFC_BASE+0xE14)))

/*!
 * NFC end block address register for unlocking buffer
 */
#define NFC_UNLOCKEND_BLKADDR   (*((volatile U16 *)(NFC_BASE+0xE16)))

/*!
 * NFC write protect status register 
 */
#define NFC_NF_WRPRST           (*((volatile U16 *)(NFC_BASE+0xE18)))

/*!
 * NFC configuration register 1 
 */
#define NFC_CONFIG1             (*((volatile U16 *)(NFC_BASE+0xE1A)))

/*!
 * NFC configuration register 2 
 */
#define NFC_CONFIG2             (*((volatile U16 *)(NFC_BASE+0xE1C)))

/*! @} */

/* Address to determine Bad block Information(BI) in Spare area. 
 * BI information for  8 bit NAND is stored at 6th byte in Spare area.
 */
#define BI_BASE_8               (volatile U16 *)(NFC_BASE + 0x834);

/*!
 * Address to determine Bad block Information(BI) in Spare area. 
 * BI information for  16 bit NAND is stored at 6th word in Spare area.
 */
#define BI_BASE_16              (volatile U16 *)(NFC_BASE + 0x83A);

/*!
 * @name NFC RAM buffer main area addresses 
 */
/*! @{ */
/*!
 * NFC RAM buffer main area 0 address 
 */
#define MAIN_AREA0              (volatile U16 *)(NFC_BASE+0x000)

/*!
 * NFC RAM buffer main area 1 address 
 */
#define MAIN_AREA1              (volatile U16 *)(NFC_BASE+0x200)

/*!
 * NFC RAM buffer main area 2 address 
 */
#define MAIN_AREA2              (volatile U16 *)(NFC_BASE+0x400)

/*!
 * NFC RAM buffer main area 3 address 
 */
#define MAIN_AREA3              (volatile U16 *)(NFC_BASE+0x600)

/*! @} */

/*!
 * @name NFC Spare buffer area addresses
 */
/*! @{ */

/*!
 * NFC Spare buffer area 0 address
 */
#define SPARE_AREA0             (volatile U16 *)(NFC_BASE+0x800)

/*!
 * NFC Spare buffer area 1 address
 */
#define SPARE_AREA1             (volatile U16 *)(NFC_BASE+0x810)

/*!
 * NFC Spare buffer area 2 address
 */
#define SPARE_AREA2             (volatile U16 *)(NFC_BASE+0x820)

/*!
 * NFC Spare buffer area 3 address
 */
#define SPARE_AREA3             (volatile U16 *)(NFC_BASE+0x830)
/*! @} */

/*!
 * This defines the 16 bit NAND Flash
 */
#define NAND_WIDTH_16      0

/*!
 * This defines the NAND Flash page size in bytes
 */
#define NAND_PAGE_SIZE      512

/*!
 * @name NFC CONFIG2 register values
 */
/*! @{ */
/*!
 * Set INT to 0, FCMD to 1, rest to 0 in NFC_CONFIG2 Register for Command
 * operation
 */
#define NFC_CMD            0x1

/*!
 * Set INT to 0, FADD to 1, rest to 0 in NFC_CONFIG2 Register for Address
 * operation
 */
#define NFC_ADDR           0x2

/*!
 * Set INT to 0, FDI to 1, rest to 0 in NFC_CONFIG2 Register for Input
 * operation
 */
#define NFC_INPUT          0x4

/*!
 * Set INT to 0, FDO to 001, rest to 0 in NFC_CONFIG2 Register for Data Output
 * operation
 */
#define NFC_OUTPUT         0x8

/*!
 * Set INT to 0, FD0 to 010, rest to 0 in NFC_CONFIG2 Register for Read ID
 * operation
 */
#define NFC_ID             0x10

/*!
 * Set INT to 0, FDO to 100, rest to 0 in NFC_CONFIG2 Register for Read Status
 * operation
 */
#define NFC_STATUS         0x20

/*!
 * Set INT to 1, rest to 0 in NFC_CONFIG2 Register for Read Status
 * operation
 */
#define NFC_INT            0x8000
/*! @} */

/* Other configuration register values */
#define NFC_SP_EN           (1 << 2)
#define NFC_ECC_EN          (1 << 3)
#define NFC_INT_MSK         (1 << 4)
#define NFC_BIG             (1 << 5)
#define NFC_RST             (1 << 6)
#define NFC_CE              (1 << 7)

/*
 * Define delays in msec for NAND device operations
 */
#define TWC_US_DELAY   	 50	/* tWC = 50 ns, total = 528*50 ns */
#define TRC_US_DELAY   	 50
#define TRST_US_DELAY  	 500
#define TPROG_US_DELAY 	 200
#define TBERS_US_DELAY_1 1500
#define TBERS_US_DELAY_2 1500
#define TR_US_DELAY    	 10

/*
 * Standard NAND flash commands, from nand.h
 */
#define NAND_CMD_READ0          0x0
#define NAND_CMD_READ1          0x1
#define NAND_CMD_PAGEPROG       0x10
#define NAND_CMD_READOOB        0x50
#define NAND_CMD_ERASE1         0x60
#define NAND_CMD_STATUS         0x70
#define NAND_CMD_STATUS_MULTI   0x71
#define NAND_CMD_SEQIN          0x80
#define NAND_CMD_READID         0x90
#define NAND_CMD_ERASE2         0xd0
#define NAND_CMD_RESET          0xff

/* Extended commands for large page devices */
#define NAND_CMD_READSTART      0x30
#define NAND_CMD_CACHEDPROG     0x15

/* Status bits */
#define NAND_STATUS_FAIL        0x01
#define NAND_STATUS_FAIL_N1     0x02
#define NAND_STATUS_TRUE_READY  0x20
#define NAND_STATUS_READY       0x40
#define NAND_STATUS_WP          0x80

#endif				/* MXC_NB_NFC_H */
