#ifndef HAL_PLATFORM_SETUP_H
#define HAL_PLATFORM_SETUP_H

/*
 *      File :     hal_platform_setup.h
 *
 *      Platform specific code for MX21 platform.
 */

/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#include "mx21ads.h"

#if !defined(__ASSEMBLER__) /*ADDED FOR COMPILATION */

#define SETUP_IOMUX()  setup_iomux()

static void setup_iomux(void)
{

	int temp,tmp;

	if (_reg_SYS_FMCR & 0xC0000000) {
		
		temp = _reg_CRM_CSCR; 	
		temp |= 0x60000000;		
		_reg_CRM_CSCR = temp;  	   /* set PRESC = b11 (i.e. /4) will change to /2 later//  changed for TO2 }*/ 	
		temp = _reg_CRM_CSCR;		
		temp |= 0x00000200;		
		_reg_CRM_CSCR = temp;	   /* set IPDIV = 1, HCLK divided by 2 */		
		temp = _reg_CRM_CSCR;		
		temp &= ~0x00003C00;		
		temp |= 0x00000400;	   /* set BCLKDIV = 1 (i.e. /2) */	
		
		_reg_CRM_CSCR = temp;	   /* PLL input 32.768kHz */
	
		_reg_CRM_MPCTL0 = 0x007b1C73;	/* 266M	 */
		_reg_CRM_CSCR |=0x00200000;
	
		/* wait for the MPLLRESTART bit self clear */	
		while (_reg_CRM_CSCR & 0x00200000);

		_reg_CRM_CSCR &= ~0xe0000000;    /* set back PRESC = b000 (i.e./1) */
	}else {

		temp = _reg_CRM_CSCR;
		temp &= ~0xe0000000;	
		temp |= 0x60000000;
		_reg_CRM_CSCR = temp;         /* set PRESC = b11 (i.e. /4) will change to /1 later */
		temp = _reg_CRM_CSCR;	
		temp |= 0x00000200;		
		_reg_CRM_CSCR = temp;         /* set IPDIV = 1 */
		temp = _reg_CRM_CSCR;		
		temp &= ~0x00003C00;		
		temp |= 0x00000400;	
		_reg_CRM_CSCR = temp;         /* set BCLKDIV = 1 (i.e. /2) */
		_reg_CRM_CSCR &= ~0xe0000000; /* set back PRESC = b000 (i.e./1) */
	}

	_reg_CRM_PCDR1 |= 0x5;	
	_reg_CRM_PCDR1 &= 0xFFFFFFC5;

	/* enable clock for HCLK BROM and UART_1 */
	_reg_CRM_PCCR0 |= 0x10000001;
		
    
	/* Set up GPIO/IOMUX for UART_1  */
	
	_reg_GPIO_GIUS(GPIOE) &= 0xFFFF0FFF;	/* clear bit 12-bit 15 of GIUS_E */
	_reg_GPIO_GPR(GPIOE) &= 0xFFFF0FFF;	/* clear bit 12-bit 15 of GPR_E  */

        _reg_GPIO_GIUS(GPIOE) &= ~0x00000d8;	/* port E pin 3,4,6,7 for uart2 */
        _reg_GPIO_GPR(GPIOE) &= ~0x00000d8;	/* port E pin 3,4,6,7 for primary function */
	
	if (_reg_SYS_FMCR & 0xC0000000) {

		/* connect CLKO to CLK48M */
		temp = _reg_CRM_CSCR;
		temp &= ~0xe0000000;
		/* fma temp |= 0x40000000; */
		_reg_CRM_CSCR = temp;  /* gary add it according to Frank Ma's advice */
                
		/* gary add: change for NFC clock(/12) NAND flash programming */
		temp = _reg_CRM_PCDR0;
		temp &= ~0xF000;
		temp |= 0xB000;

		_reg_CRM_PCDR0 = temp;	
	}else {
		/* PLL bypass mode (SPLL = 48MHz) 
		 * configure the Clock - usbdiv=0 (/1), clkdiv=0
		 */
		temp = _reg_CRM_CSCR;
		temp &= ~0x1C000000;
		_reg_CRM_CSCR = temp;   
	}

}   
#endif
#if defined(__ASSEMBLER__) 
#if !defined(NOHALASM)   /* Added for compilation of linker script */
/*
 * Platform setup macro
 */
#define PLATFORM_SETUP1 _platform_setup1

/* definitions from redboot\cvs\src\packages\hal\arm\mx21\evb\current\include\hal_platform_setup.h
 * This macro represents the initial startup code for the platform
*/
        .macro  _platform_setup1
MX21_SETUP_START:
   /* size is stored in location 0x0C0000FC */
	.global	_start
_start:	
	.word   0xE59FF000	
	.word   0	
	.word   ( _start2 - 4 )	
	.word	0
	.word	( _start2 - 4 )
_loop1:	b	_loop1	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop	
	nop
	
_start2:     
	ldr r1,=0x10000000     
	ldr r3,=0x00040304      
	str r3,[r1]                  
	ldr r1,=0x10020000     
	ldr r3,=0x00000000     
	str r3,[r1]       
	ldr r1,=0x10000004       
	ldr r3,=0xFFFBFCFB        
	str r3,[r1]        
	ldr r1,=0x10020004      
	ldr r3,=0xFFFFFFFF       
	str r3,[r1]  

/* Explicitly set MPLL 266MHz
 *  setmem 0x10027004 0x007b1C73 32
 */
	ldr r1,=0x10027004    
	ldr r3,=0x007b1C73        
	str r3,[r1]        
	
/* PLL 66MHz
 * setmem 0x10027000 0x1700C207 32  
 */
	ldr r1,=0x10027000   
	ldr r3,=0x77000207   
	str r3,[r1]     

/* PLL 88.67MHz
 * setmem 0x10027000 0x17000a07 32
 */
	ldr r1,=0x10027000

/* modified for NANDFlash to use 88.67MHz */    
	ldr r3,=0x17000a07      
	ldr r3,=0x17000a07       
	str r3,[r1]     

/* PLL 133MHz
 * setmem 0x10027000 0x17000607 32
 */
	/* CS0 Initialization (Async Mode)  
	 * 32-bit, ?? wait states       
	 * setmem 0xDF001000 0x00003E00 32
	 * setmem 0xDF001004 0x00000E01 32   
	*/
	ldr r1,=0xDF001000     
	ldr r3,=0x00003E00       
	str r3,[r1]   
	ldr r1,=0xDF001004   
	ldr r3,=0x00000E01    
	str r3,[r1]

/* CS3 Initialization (Async Mode)
 * 32-bit, ?? wait states
 * setmem 0xDF001018 0x00003E00 32
 * setmem 0xDF00101C 0x11110601 32     
 */
	ldr r1,=0xDF001018
	ldr r3,=0x00003E00   
	str r3,[r1]         
	ldr r1,=0xDF00101c    
	ldr r3,=0x11110601     
	str r3,[r1]

/* FMCR Register
 * Select CS3 and CSD0
 * setmem 0x10027814 0xFFFFFFC9 32         
 */
	ldr r1,=0x10027814
	ldr r3,=0xFFFFFFC9 
	str r3,[r1] 

/* Set Precharge Command
 * setmem 0xDF000000 0x92120300 32   
 */
	ldr r1,=0xDF000000        
	ldr r3,=0x92120300     
	str r3,[r1]            

/* Issue Precharge all Command
 * memory 0xC0200000 +1 32             
 */
	LDR  r3, =0xC0200000     
	LDR  r2, [r3] 

/* Set AutoRefresh Command
 * setmem 0xDF000000 0xA2120300 32   
 */
	LDR  r3, =0xA2120300     
	STR  r3, [r1]      
	
/*  Issue AutoRefresh Command  */
	LDR  r3, =0xC0000000   
	LDR  r2, [r3]      
	LDR  r2, [r3]      
	LDR  r2, [r3]     
	LDR  r2, [r3]     
	LDR  r2, [r3]      
	LDR  r2, [r3]      
	LDR  r2, [r3]     
	LDR  r2, [r3] 

/* Set Mode Register
 * setmem 0xDF000000 0xB2120300 32
*/
	LDR  r3, =0xB2120300     
	STR  r3, [r1]  
/* Issue Mode Register Command
 * Burst Length = 8
 * memory 0xC0119800 +1 32       
 */
	LDR  r3, =0xC0119800
	
/* Mode Register Value  */
 	LDR  r2, [r3] 

/* Set to Normal Mode
 *  From the spec of the SDRAM K4S56163LC-RG75000,
 *  1. tRCD = 19ns minimum  -> RCD = 3 clk (SDCLK=133MHz) -> SRCD = 11b 
 *  2. tRP  = 19ns minimum  -> RP  = 3 clk (SDCLK=133MHz) -> SRP  = 0b
 *  3. tRC  = 65ns minimum  -> RC  = 9 clk (SDCLK=133MHz) -> SRC  = 1001b 
 *  4. refresh rate = 8192rows/64ms -> SREFR = 11b
 *  setmem 0xDF000000 0x8212F339 32    
*/
	LDR  r3, =0x8212F339         
	STR  r3, [r1] 
	
/* increase the driving strength for i.MX21 after 0440	*/
	ldr	r3,=0x10027824		
	ldr r0,=0x12491249	
	ldr r2,=0x9
	
_DrivingLoop:		
	str	r0,[r3]		
	add	r3,r3,#4		
	sub	r2,r2,#1	
	teq	r2,#0		
	beq	_EndDriving		
	b	_DrivingLoop		
_EndDriving:	
 .endm

#endif  /*!defined(NOHALASM) */

#endif  /* defined(__ASSEMBLER__) */

#endif /* define HAL_PLATFORM_SETUP_H */
