#ifndef MX21_H_
#define MX21_H_

/*
 *      File :     mxc_setup_mx21.h
 *
 *      Platform specific code for MX21 platform.
 */
/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*definitions form redboot\cvs\src\packages\hal\arm\mx21\var\current\include\hal_mx21.h */
#ifdef __ASSEMBLER__

#define REG8_VAL(a)      (a)
#define REG16_VAL(a)     (a)
#define REG32_VAL(a)     (a)

#define REG8_PTR(a)      (a)
#define REG16_PTR(a)     (a)
#define REG32_PTR(a)     (a)

#else /* __ASSEMBLER__ */

#define REG8_VAL(a)      ((unsigned char)(a))
#define REG16_VAL(a)     ((unsigned short)(a))
#define REG32_VAL(a)     ((unsigned int)(a))

#define REG8_PTR(a)      ((volatile unsigned char *)(a))
#define REG16_PTR(a)     ((volatile unsigned short *)(a))
#define REG32_PTR(a)     ((volatile unsigned long *)(a))

#define REG32_SET(addr, val)    (*(volatile unsigned long*) (addr) = (val))
#define REG16_SET(addr, val)    (*(volatile unsigned short*) (addr) = (val))
#define readb(a)             (*(volatile unsigned char *)(a))
#define readw(a)             (*(volatile unsigned short *)(a))
#define readl(a)             (*(volatile unsigned int *)(a))
#define writeb(v,a)          (*(volatile unsigned char *)(a) = (v))
#define writew(v,a)          (*(volatile unsigned short *)(a) = (v))
#define writel(v,a)          (*(volatile unsigned int *)(a) = (v))

#endif /* __ASSEMBLER__ */

/*
 * MX21 Default Memory Layout Definitions
 */

#define     L2CC_BASE_ADDR          0x30000000

/*
 * AIPS 1
 */
#define     AIPS1_BASE_ADDR         0x43F00000
#define     AIPS1_CTRL_BASE_ADDR    AIPS1_BASE_ADDR
#define     EVTMON_BASE_ADDR        0x43F08000
#define     CLKCTL_BASE_ADDR        0x43F0C000
#define     ETB_SLOT4_BASE_ADDR     0x43F10000
#define     ETB_SLOT5_BASE_ADDR     0x43F14000
#define     ECT_CTIO_BASE_ADDR      0x43F18000
#define     I2C_BASE_ADDR           0x43F80000
#define     MU_BASE_ADDR            0x43F88000
#define     UART1_BASE_ADDR         0x43F90000
#define     UART2_BASE_ADDR         0x43F94000
#define     DSM_BASE_ADDR           0x43F98000
#define     OWIRE_BASE_ADDR         0x43F9C000
#define     SSI1_BASE_ADDR          0x43FA0000
#define     CSPI1_BASE_ADDR         0x43FA4000
#define     KPP_BASE_ADDR           0x43FA8000
#define     IOMUX_AP_BASE_ADDR      0x43FAC000
#define     GPIO3_BASE_ADDR         0x43FB0000
#define     CTI_AP_BASE_ADDR        0x43FB8000

/*
 * SPBA
 */
#define     SPBA_BASE_ADDR          0x50000000
#define     SDHC1_BASE_ADDR         0x50004000
#define     SDHC2_BASE_ADDR         0x50008000
#define     UART3_BASE_ADDR         0x5000C000
#define     CSPI2_BASE_ADDR         0x50010000
#define     SSI2_BASE_ADDR          0x50014000
#define     SIM_BASE_ADDR           0x50018000
#define     IIM_BASE_ADDR           0x5001C000
#define     CTI_SDMA_BASE_ADDR      0x50020000
#define     USBOTG_BASE_ADDR        0x50024000
#define     SPBA_CTRL_BASE_ADDR     0x5003C000
#define     IOMUX_COM_BASE_ADDR     0x50040000
#define     CRM_COM_BASE_ADDR       0x50044000
#define     MRCG_BASE_ADDR          0x50048000
#define     UDPLL_BASE_ADDR         0x5004C000
#define     ADPLL_BASE_ADDR         0x50050000
#define     BDPLL_BASE_ADDR         0x50054000
#define     CRM_AP_BASE_ADDR        0x50058000

/*
 * AIPS 2
 */
#define     AIPS2_BASE_ADDR         0x53F00000
#define     AIPS2_CTRL_BASE_ADDR    AIPS2_BASE_ADDR
#define     FIRI_BASE_ADDR          0x53F8C000
#define     GPT_BASE_ADDR           0x53F90000
#define     EPIT1_BASE_ADDR         0x53F94000
#define     EPIT2_BASE_ADDR         0x53F98000
#define     SCC_BASE_ADDR           0x53FAC000
#define     RNGA_BASE_ADDR          0x53FB0000
#define     IPU_CTRL_BASE_ADDR      0x53FC0000
#define     AUDMUX_BASE_ADDR        0x53FC4000
#define     EDIO_BASE_ADDR          0x53FC8000
#define     GPIO1_BASE_ADDR         0x53FCC000
#define     GPIO2_BASE_ADDR         0x53FD0000
#define     SDMA_BASE_ADDR          0x53FD4000
#define     RTC_BASE_ADDR           0x53FD8000
#define     WDOG1_BASE_ADDR         0x10002000
#define     PWM_BASE_ADDR           0x53FE0000
#define     HAC_BASE_ADDR           0x53FEC000

/*
 * ROMPATCH and AVIC
 */
#define     ROMPATCH_BASE_ADDR      0x60000000
#define     AVIC_BASE_ADDR          0x68000000

/*
 * NAND, SDRAM, WEIM, M3IF, EMI controllers
 */

#define INTERNAL_ROM_VA         0xF0000000

/* SDRAM */
#define     RAM_BANK0_BASE          SDRAM_BASE_ADDR

/*
 * IRQ Controller Register Definitions.
 */
#define     AVIC_NIMASK             REG32_PTR(AVIC_BASE_ADDR + (0x04))
#define     AVIC_INTTYPEH           REG32_PTR(AVIC_BASE_ADDR + (0x18))
#define     AVIC_INTTYPEL           REG32_PTR(AVIC_BASE_ADDR + (0x1C))

/* L210 */
#define     L2CC_BASE_ADDR                  0x30000000
#define     L2_CACHE_LINE_SIZE              32
#define     L2_CACHE_CTL_REG                0x100
#define     L2_CACHE_AUX_CTL_REG            0x104
#define     L2_CACHE_SYNC_REG               0x730
#define     L2_CACHE_INV_LINE_REG           0x770
#define     L2_CACHE_INV_WAY_REG            0x77C
#define     L2_CACHE_CLEAN_LINE_REG         0x7B0
#define     L2_CACHE_CLEAN_INV_LINE_REG     0x7F0


/* CRM_AP */
#define     CRM_AP_ASCSR            0x00
#define     CRM_AP_ACDR             0x04
#define     CRM_AP_ACDER1           0x08
#define     CRM_AP_ACDER2           0x0C
#define     CRM_AP_ACGCR            0x10
#define     CRM_AP_ACCGCR           0x14
#define     CRM_AP_AMLPMRA          0x18
#define     CRM_AP_AMLPMRB          0x1C
#define     CRM_AP_AMLPMRC          0x20
#define     CRM_AP_AMLPMRD          0x24
#define     CRM_AP_AMLPMRE1         0x28
#define     CRM_AP_AMLPMRE2         0x2C
#define     CRM_AP_AMLPMRF          0x30
#define     CRM_AP_AMLPMRG          0x34
#define     CRM_AP_APGCR            0x38
#define     CRM_AP_ACSR             0x3C
#define     CRM_AP_ADCR             0x40
#define     CRM_AP_ACR              0x44
#define     CRM_AP_AMCR             0x48
#define     CRM_AP_APCR             0x4C
#define     CRM_AP_AMORA            0x50
#define     CRM_AP_AMORB            0x54
#define     CRM_AP_AGPR             0x58
#define     CRM_AP_APRA             0x5C
#define     CRM_AP_APRB             0x60
#define     CRM_AP_APOR             0x64

/* CRM_COM */
#define     CRM_COM_CBMR            0x00
#define     CRM_COM_CRSRBP          0x04
#define     CRM_COM_CCRCR           0x08
#define     CRM_COM_CSCR            0x0C
#define     CRM_COM_CCCR            0x10
#define     CRM_COM_CRSRAP          0x14

/* DPLL */
#define     DPLL_DP_CTL             0x00
#define     DPLL_DP_CONFIG          0x04
#define     DPLL_DP_OP              0x08
#define     DPLL_DP_MFD             0x0C
#define     DPLL_DP_MFN             0x10
#define     DPLL_DP_MFNMINUS        0x14
#define     DPLL_DP_MFNPLUS         0x18
#define     DPLL_DP_HFS_OP          0x1C
#define     DPLL_DP_HFS_MFD         0x20
#define     DPLL_DP_HFS_MFN         0x24
#define     DPLL_DP_TOGC            0x28
#define     DPLL_DP_DESTAT          0x2C

/* WEIM - CS0 */
#define     CSCRU                   0x00
#define     CSCRL                   0x04
#define     CSCRA                   0x08

/* ESDCTL */
#define     ESDCTL_ESDCTL0          0x00
#define     ESDCTL_ESDCFG0          0x04
#define     ESDCTL_ESDCTL1          0x08
#define     ESDCTL_ESDCFG1          0x0C
#define     ESDCTL_ESDMISC          0x10

/* ESDRAM parameters */
/* TODO: update required based on AP's team */
#define     SDRAM_CSD0              0x00
#define     PRE_ALL_CMD             0x01
#define     AUTO_REF_CMD            0x10
#define     SET_MODE_REG_CMD        0x11
#define     MODE_REG_VAL0           0x00
#define     NORMAL_MODE             0x00

/*
 * UART Control Register 0 Bit Fields.
 */
#define         EUartUCR1_ADEN      (1 << 15)   /* Auto dectect interrupt */
#define         EUartUCR1_ADBR      (1 << 14)   /* Auto detect baud rate  */
#define         EUartUCR1_TRDYEN    (1 << 13)   /* Transmitter ready interrupt enable */
#define         EUartUCR1_IDEN      (1 << 12)   /* Idle condition interrupt    */
#define         EUartUCR1_RRDYEN    (1 << 9)    /* Recv ready interrupt enable */
#define         EUartUCR1_RDMAEN    (1 << 8)    /* Recv ready DMA enable       */
#define         EUartUCR1_IREN      (1 << 7)    /* Infrared interface enable   */
#define         EUartUCR1_TXMPTYEN  (1 << 6)    /* Transimitter empty interrupt enable */
#define         EUartUCR1_RTSDEN    (1 << 5)    /* RTS delta interrupt enable   */
#define         EUartUCR1_SNDBRK    (1 << 4)    /* Send break                   */
#define         EUartUCR1_TDMAEN    (1 << 3)    /* Transmitter ready DMA enable */
#define         EUartUCR1_DOZE      (1 << 1)    /* Doze				*/
#define         EUartUCR1_UARTEN    (1 << 0)    /* UART enabled 		*/
#define         EUartUCR2_ESCI      (1 << 15)   /* Escape seq interrupt enable  */
#define         EUartUCR2_IRTS      (1 << 14)   /* Ignore RTS pin               */ 
#define         EUartUCR2_CTSC      (1 << 13)   /* CTS pin control              */
#define         EUartUCR2_CTS       (1 << 12)   /* Clear to send                */
#define         EUartUCR2_ESCEN     (1 << 11)   /* Escape enable                */ 
#define         EUartUCR2_PREN      (1 << 8)    /* Parity enable                */
#define         EUartUCR2_PROE      (1 << 7)    /* Parity odd/even              */
#define         EUartUCR2_STPB      (1 << 6)    /* Stop				*/
#define         EUartUCR2_WS        (1 << 5)    /* Word size			*/
#define         EUartUCR2_RTSEN     (1 << 4)    /* Request to send interrupt enable */
#define         EUartUCR2_ATEN      (1 << 3)    /* Aging timer enable   */
#define         EUartUCR2_TXEN      (1 << 2)    /* Transmitter enabled  */
#define         EUartUCR2_RXEN      (1 << 1)    /* Receiver enabled	*/
#define         EUartUCR2_SRST_     (1 << 0)    /* SW reset		*/
#define         EUartUCR3_PARERREN  (1 << 12)   /* Parity enable 	*/
#define         EUartUCR3_FRAERREN  (1 << 11)   /* Frame error interrupt enable       */
#define         EUartUCR3_ADNIMP    (1 << 7)    /* Autobaud detection not improved    */
#define         EUartUCR3_RXDSEN    (1 << 6)    /* Receive status interrupt enable    */
#define         EUartUCR3_AIRINTEN  (1 << 5)    /* Async IR wake interrupt enable     */
#define         EUartUCR3_AWAKEN    (1 << 4)    /* Async wake interrupt enable        */
#define         EUartUCR3_RXDMUXSEL (1 << 2)    /* RXD muxed input selected	      */ 
#define         EUartUCR3_INVT      (1 << 1)    /* Inverted Infrared transmission     */ 	
#define         EUartUCR3_ACIEN     (1 << 0)    /* Autobaud counter interrupt enable  */
#define         EUartUCR4_CTSTL_32  (32 << 10)  /* CTS trigger level (32 chars)	      */	
#define         EUartUCR4_INVR      (1 << 9)    /* Inverted infrared reception	      */ 
#define         EUartUCR4_ENIRI     (1 << 8)    /* Serial infrared interrupt enable   */
#define         EUartUCR4_WKEN      (1 << 7)    /* Wake interrupt enable	      */
#define         EUartUCR4_IRSC      (1 << 5)    /* IR special case		      */  	
#define         EUartUCR4_LPBYP     (1 << 4)    /* Low power bypass		      */
#define         EUartUCR4_TCEN      (1 << 3)    /* Transmit complete interrupt enable */ 
#define         EUartUCR4_BKEN      (1 << 2)    /* Break condition interrupt enable   */
#define         EUartUCR4_OREN      (1 << 1)    /* Receiver overrun interrupt enable  */
#define         EUartUCR4_DREN      (1 << 0)    /* Recv data ready interrupt enable   */
#define         EUartUFCR_RXTL_SHF  0           /* Receiver trigger level shift       */
#define         EUartUFCR_RFDIV_1   (5 << 7)    /* Reference freq divider (div 1)     */
#define         EUartUFCR_RFDIV_2   (4 << 7)    /* Reference freq divider (div 2)     */
#define         EUartUFCR_TXTL_SHF  10          /* Transmitter trigger level shift    */
#define         EUartUSR1_PARITYERR (1 << 15)   /* Parity error interrupt flag        */
#define         EUartUSR1_RTSS      (1 << 14)   /* RTS pin status  		      */
#define         EUartUSR1_TRDY      (1 << 13)   /* Transmitter ready interrupt/dma flag */
#define         EUartUSR1_RTSD      (1 << 12)   /* RTS delta 			*/
#define         EUartUSR1_ESCF      (1 << 11)   /* Escape seq interrupt flag	*/
#define         EUartUSR1_FRAMERR   (1 << 10)   /* Frame error interrupt flag	*/
#define         EUartUSR1_RRDY      (1 << 9)    /* Receiver ready interrupt/dma flag */
#define         EUartUSR1_AGTIM     (1 << 8)    /* Aging timeout interrupt status */
#define         EUartUSR1_RXDS      (1 << 6)    /* Receiver idle interrupt flag   */
#define         EUartUSR1_AIRINT    (1 << 5)    /* Async IR wake interrupt flag	  */	
#define         EUartUSR1_AWAKE     (1 << 4)    /* Aysnc wake interrupt flag	  */
#define         EUartUSR2_ADET      (1 << 15)   /* Auto baud rate detect complete */
#define         EUartUSR2_TXFE      (1 << 14)   /* Transmit buffer FIFO empty	  */
#define         EUartUSR2_IDLE      (1 << 12)   /* Idle condition		  */
#define         EUartUSR2_ACST      (1 << 11)   /* Autobaud counter stopped	  */
#define         EUartUSR2_IRINT     (1 << 8)    /* Serial infrared interrupt flag */
#define         EUartUSR2_WAKE      (1 << 7)    /* Wake */  
#define         EUartUSR2_RTSF      (1 << 4)    /* RTS edge interrupt flag  */
#define         EUartUSR2_TXDC      (1 << 3)    /* Transmitter complete     */
#define         EUartUSR2_BRCD      (1 << 2)    /* Break condition	    */
#define         EUartUSR2_ORE       (1 << 1)    /* Overrun error	    */
#define         EUartUSR2_RDR       (1 << 0)    /* Recv data ready	    */
#define         EUartUTS_FRCPERR    (1 << 13)   /* Force parity error	    */  
#define         EUartUTS_LOOP       (1 << 12)   /* Loop tx and rx	    */
#define         EUartUTS_TXEMPTY    (1 << 6)    /* TxFIFO empty		    */ 
#define         EUartUTS_RXEMPTY    (1 << 5)    /* RxFIFO empty		    */	
#define         EUartUTS_TXFULL     (1 << 4)    /* TxFIFO full		    */
#define         EUartUTS_RXFULL     (1 << 3)    /* RxFIFO full		    */
#define         EUartUTS_SOFTRST    (1 << 0)    /* Software reset	    */	
#define         DelayTimerPresVal   3
#define         NFC_CLK_SWITCH      0

/* DPLL */
#define         PLL_DP_CTL          0x00
#define         PLL_DP_CONFIG       0x04
#define         PLL_DP_OP           0x08
#define         PLL_DP_MFD          0x0C
#define         PLL_DP_MFN          0x10
#define         PLL_DP_HFS_OP       0x1C
#define         PLL_DP_HFS_MFD      0x20
#define         PLL_DP_HFS_MFN      0x24
#define         L2CC_ENABLED
#define         UART_WIDTH_32       /* internal UART is 32bit access only */
#define         HAL_DELAY_US(n)     hal_delay_us(n)
#define         CKIH_CLK_FREQ       16800000
#define         DIGRF_CLK_FREQ      26000000
#define         PLL_REF_CLK         (CKIH_CLK_FREQ * 2)

/*Definitions from redboot\cvs\src\packages\hal\arm\mx21\evb\current\include\mx21.h */

#define         APCLK_399_133_66            /* AP_CLK: 399 MHz, AP_AHB_CLK = 133 MHz, AP_IP_CLK = 66.5 MHz */
#define         USB_PLL_CLK_96              /* USB_PLL_CLK: 96 MHz */
#define         UART_FIFO_CTRL          0xA01
#ifdef          APCLK_532_133_66
#define         ADPLL_PDF   (1)
#define         ADPLL_MFI   (8)
#define         ADPLL_MFN   (-140)
#define         ADPLL_MFD   (1680 - 1)
#define         ADPLL_OP    ((ADPLL_MFI << 4) | (ADPLL_PDF - 1))
#define         ARM_DIV     8   /* 8 => /1 */
#define         AHB_DIV     4
#define         IP_DIV      8
#define         CRM_AP_DIV  ((ARM_DIV << 8) | (AHB_DIV << 4) | (IP_DIV))
#define         NFC_DIV     6   /* 6 => /7 */
#endif

#ifdef          APCLK_399_133_66
#define         ADPLL_PDF   (1)
#define         ADPLL_MFI   (6)
#define         ADPLL_MFN   (-105)
#define         ADPLL_MFD   (1680 - 1)
#define         ADPLL_OP    ((ADPLL_MFI << 4) | (ADPLL_PDF - 1))
#define         ARM_DIV     8   /* 8 => /1 */
#define         AHB_DIV     3
#define         IP_DIV      6
#define         CRM_AP_DIV  ((ARM_DIV << 8) | (AHB_DIV << 4) | (IP_DIV))
#define         NFC_DIV     6   /* 6 => /7 */
#endif

#ifdef          APCLK_266_133_66
#define         ADPLL_PDF   (2)
#define         ADPLL_MFI   (8)
#define         ADPLL_MFN   (-140)
#define         ADPLL_MFD   (1680 - 1)
#define         ADPLL_OP    ((ADPLL_MFI << 4) | (ADPLL_PDF - 1))
#define         ARM_DIV     8   /* 8 => /1 */
#define         AHB_DIV     2
#define         IP_DIV      4
#define         CRM_AP_DIV  ((ARM_DIV << 8) | (AHB_DIV << 4) | (IP_DIV))
#define         NFC_DIV     6   /* 6 => /7 */
#endif

#ifdef          USB_PLL_CLK_96
#define         UDPLL_PDF   (1)
#define         UDPLL_MFI   (5)
#define         UDPLL_MFN   (7142)
#define         UDPLL_MFD   (10000 - 1)
#define         UDPLL_OP    ((UDPLL_MFI << 4) | (UDPLL_PDF - 1))
#define         USB_DIV     0       /* 0 => /2 */
#define         FIRI_DIV    1       /* 1 => /2 */
#define         CS_DIV      0x19    /* 0x19 => /12.5 */
#endif
#define         TIMEOUT     4000
#define         NFC_BASE    0xdf003000

#if !defined(__ASSEMBLER__) /*ADDED FOR COMPILATION */

/*
 * GPIO		
 * $1001_5000 to $1001_5FFF
*/

#define GPIOA	0
#define GPIOB	1
#define GPIOC	2
#define GPIOD	3
#define GPIOE	4
#define GPIOF	5

/* Use as GPIO_BASE_ADDR(GPIOA)- GPIO_BASE_ADDR(GPIOF)*/
#define GPIO_BASE_ADDR(x)	(0x10015000+x*0x100)
#define _reg_GPIO_GIUS(x)	(*((volatile unsigned long *)(GPIO_BASE_ADDR(x)+0x20)))/* 32bit gpio pta in use reg */
#define _reg_GPIO_GPR(x)	(*((volatile unsigned long *)(GPIO_BASE_ADDR(x)+0x38)))/* 32bit gpio pta general purpose reg*/

#define CRM_BASE_ADDR	0x10027000	
#define _reg_CRM_CSCR	(*((volatile unsigned long *)(CRM_BASE_ADDR+0x00)))  /*  32bit Clock Source Control Reg     */
#define _reg_CRM_MPCTL0	(*((volatile unsigned long *)(CRM_BASE_ADDR+0x04)))  /*  32bit MCU PLL Control Reg          */
#define _reg_CRM_PCDR0	(*((volatile unsigned long *)(CRM_BASE_ADDR+0x18)))  /*  32bit Serial Perpheral Clk Div Reg */
#define _reg_CRM_PCDR1	(*((volatile unsigned long *)(CRM_BASE_ADDR+0x1C))) 
#define _reg_CRM_PCCR0	(*((volatile unsigned long *)(CRM_BASE_ADDR+0x20)))  

#define SYS_BASE_ADDR	0x10027800
#define _reg_SYS_FMCR	(*((volatile unsigned long *)(SYS_BASE_ADDR+0x14)))  /*  Functional Muxing Control Reg */
#define _reg_SYS_PCSR	(*((volatile unsigned long *)(SYS_BASE_ADDR+0x50)))  /*  Priority Control/select Reg   */
#define _reg_SYS_GPCR	(*((volatile unsigned long *)(SYS_BASE_ADDR+0x18)))  /*  Global Peripheral Control Reg */

#define _reg_WEIM_CSU(x)(*((volatile unsigned long *)(MX2ADS_EMI_IOBASE+0x1000+8*x))) /* 32bit eim chip sel 0 upper ctr reg */
#define _reg_WEIM_CSL(x)(*((volatile unsigned long *)(MX2ADS_EMI_IOBASE+0x1000+0x04+8*x)))/*32bit eim chip sel 0 lower ctr reg*/
#define AIPI1_BASE_ADDR	0x10000000	
#define _reg_AIPI1_PSR0	(*((volatile unsigned long *)(AIPI1_BASE_ADDR+0x00)))	/*  32bit Peripheral Size Reg 0 */
#define _reg_AIPI1_PSR1	(*((volatile unsigned long *)(AIPI1_BASE_ADDR+0x04)))	/*  32bit Peripheral Size Reg 1 */
/*
 * AIPI2
 * $1002_0000 to $1002_0FFF
*/

#define AIPI2_BASE_ADDR	0x10020000	
#define _reg_AIPI2_PSR0 (*((volatile unsigned long *)(AIPI2_BASE_ADDR+0x00)))  /*  32bit Peripheral Size Reg 0 */
#define _reg_AIPI2_PSR1	(*((volatile unsigned long *)(AIPI2_BASE_ADDR+0x04)))  /*  32bit Peripheral Size Reg 1 */
#define MAX_BASE_ADDR	0x1003F000
#define _reg_MAX_SLV_MPR(x)(*((volatile unsigned long *)(MAX_BASE_ADDR+0x100*x+0x00))) /* 32bit max slv master priority reg */
#define _reg_MAX_SLV_SGPCR(x)(*((volatile unsigned long *)(MAX_BASE_ADDR+0x100*x+0x10)))/*  32bit max slv0 general ctrl reg */

/*!
 * NFMS bit in FMCR register for pagesize of nandflash
 */
#define NFMS (*((volatile U32 *)(SYS_BASE_ADDR+0x14)))

#define NFMS_BIT 5

#define NAND_BUSWIDTH NAND_WIDTH_8

#endif /*!defined(__ASSEMBLER__)*/

#endif /* End of MX21_H_ */
