/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mxc_nb_ipl.c
 * 
 * @brief Source file for NANDboot Initial Program Loader (IPL)
 *
 * NANDboot is for NAND flash booting. 
 * NAND Flash can be configured as a booting device. This requires an 
 * Initial Program Loader (IPL) to be written on the first block of the 
 * NAND Flash which performs the initial booting operations. Since IPL has 
 * the size limit, it loads Secondary Program Loader (SPL) which initializes 
 * the system and loads the OS. 
 * This file contains the IPL code which loads the SPL from NAND Flash to the
 * SPL_DEST_ADDR address in the RAM and starts executing from that location. 
 * 
 * @ingroup NANDboot
 */

typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned char u8;

#include "mxc_nfc.h"

/* #define NB_DEBUG */

#define NB_OP_DELAY           100
#define NB_PRESET_DELAY       10
#ifdef 	NB_DEBUG
#define NB_DEBUG_BUF_ADDR     0x80001000
#define NB_DEBUG_BUF_LEN      0x100

static char *dbg_ptr = (char *)NB_DEBUG_BUF_ADDR;
static char idx = 0;
/*
 * This function writes a one byte message number and 7 char message into the
 * debug buffer. This is used for debugging when there is no serial output yet
 * and possibly the debugger is not able to single stpe through the code!
 */
void nb_dbg1(char *msg)
{
	int i;

	/* dbg_ptr boundary check */
	if ((dbg_ptr + 8) > (char *)(NB_DEBUG_BUF_ADDR + NB_DEBUG_BUF_LEN)) {
		dbg_ptr = (char *)NB_DEBUG_BUF_ADDR;
	}

	*dbg_ptr = idx++;	/* Put the message number */

	/* put the message, until null */
	for (i = 0; i < 7; i++) {
		*(dbg_ptr + i) = *(msg + i);
	}
	/* Point to the next message to be written */
	dbg_ptr += 8;
}

void nb_dbg(char *msg)
{
	int i;

	/* dbg_ptr boundary check */
	if ((dbg_ptr + 8) > (char *)(NB_DEBUG_BUF_ADDR + NB_DEBUG_BUF_LEN)) {
		dbg_ptr = (char *)NB_DEBUG_BUF_ADDR;
	}

	*dbg_ptr++ = idx++;	/* Put the message number */
}
#else				/* !NB_DEBUG */
#define nb_dbg(_msg)
#endif

/*!
 * This is helper sleep function which loops for approximately given number
 * usecs.
 *
 * @param       count     number of usec to wait loop
 */
void udelay(int count)
{
	volatile int i;

	for (i = 0; i < count; i++) {
	}
}

/*!
 * This function polls the NANDFC to wait for an operation to complete
 * function. It sets the flags for the commands that requires different read
 * and write operations.
 *
 * @param       maxRetries     number of retry attempts (separated by 1 us)
 */
int wait_op_done(u32 maxRetries)
{
	//maxRetries *= 100;    
	while (maxRetries-- > 0) {
		if (NFC_CONFIG2 & 0x8000)
			break;
		udelay(1);
	}

	if (maxRetries <= 0) {
		nb_dbg("1-fail");
		return -1;
	}
	return 0;
}

/*!
 * The NFC has to be preset before performing any operation
 */
void mxc_nfb_preset(void)
{
	/* Preset Operation */
	/* Unlock the internal RAM buffer */
	NFC_CONFIG = 0x2;

	/* First Block to be unlocked */
	NFC_UNLOCKSTART_BLKADDR = 0x0;
	/* Last Unlock Block */
	NFC_UNLOCKEND_BLKADDR = 0x800;
	/* Unlock Block Command */
	NFC_WRPROT = 0x4;
	/* Mask Interrupt */
	NFC_CONFIG1 = 0x10;

	udelay(NB_PRESET_DELAY);
}

/*!
 * A command has to be sent to the NAND flash for every read/write operation on
 * NAND Flash.  This function sends command to the NAND Flash. It writes the
 * command to the NFC's Command Register. Configures the NFC's Configuration
 * Register to perform the Command Input Operation.
 * 
 * @param       cmd    area from where to read the page
 * 
 * @return      0 if command operation is not  complete else 1. 
 */
int mxc_nfb_command(U8 cmd)
{
	NFC_FLASH_CMD = cmd;
	/* Configure NAND Flash Config2 Register 
	 * Set INT to 0, FCMD to 1, rest to 0
	 */
	NFC_CONFIG2 = NFC_CMD;
	/* Confirm Cmd Complete */
	return wait_op_done(NB_OP_DELAY);
}

/*!
 * Reading or writing to any location in NAND Flash requires to set an 
 * address of that location in NFC. This function writes the NAND Flash Address
 * to the NFC's Address Register. Sets the Configuration Register for the 
 * Address Input Operation 
 * 
 * @param       addr    addr from where to read the page
 * 
 * @return      0 if address operation is not  complete else 1. 
 */
int mxc_nfb_address(U16 addr)
{
	NFC_FLASH_ADDR = addr;
	/* 
	 * Configure NAND Flash Config2 Register.
	 * Set INT to 0, FADD to 1, rest to 0.
	 */
	NFC_CONFIG2 = NFC_ADDR;

	/* Confirm Cmd Complete */
	return wait_op_done(NB_OP_DELAY);
}

/*!
 * There are four main area RAM buffers in NAND flash controller. This function
 * takes the main area RAM buffer number.  It configures the NFC to copy the
 * data to/from the specified main area buffer from/to the NAND flash, during
 * read/write operation.
 * 
 * @param       addr    value for the internal main area buffer.
 * 
 * @return      0 if the operation is not complete else 1. 
 */
int mxc_nfb_bufferaddr(U16 addr)
{
	NFC_BUFFER_ADDR = addr;

	/* 
	 * Configure NAND Flash Config2 Register.
	 * Set INT to 0, FDO to 1, rest to 0.
	 */
	NFC_CONFIG2 = NFC_OUTPUT;

	/* Confirm Cmd Complete */
	return wait_op_done(NB_OP_DELAY);
}

#if 0
/*!
 * The function generate the command cycle for read the nandflash id
 */
void mxc_nfb_readid(void)
{
	mxc_nfb_command(NAND_CMD_READID);
	mxc_nfb_address(0x0);
	NFC_BUFFER_ADDR = 0;

	NFC_CONFIG2 = NFC_ID;
}
#endif

typedef u32(*FPTR) (void);
/*!
 * Main routine of NANDboot Initial Program Loader. It copies all the pages 
 * after first 2k bytes offset in the 0th block which is guaranteed to be good
 * block 
 */
int main(void)
{
	unsigned short i, page;
	volatile unsigned short *pMem = SPL_DEST_ADDR;
	volatile unsigned short *membuff;
	FPTR fptr;		/* To jump to SPL */
	int startpage,endpage,pagesize,reg;
	
#ifdef IMX21ADS
	_reg_CRM_PCDR0 |= 0x7000;
#endif

	/* Wait for INT bit set for completion of boot loading */
	while (!(NFC_CONFIG2 & 0x8000)) {
		/* Do nothing */
	}

	mxc_nfb_preset();
		startpage = 0x4;
		endpage = 0x1f;
		pagesize = 512;

	reg = NFMS;	/*get the NFMS bit value from system control register, which indicate the pagesize*/
	 if((reg>>NFMS_BIT)&0x1){ 
		startpage = 0x1;
		endpage = 0x3f; 
		pagesize = 2048;
	 }
	
	/* 
	 * Copy 1st block of NAND into memory starting from 4th page, where SPL
	 * is expected to be stored
	 */
	for (page = startpage; page <= endpage; page++){ 
		nb_dbg("readcmd");
		/* Write to NAND Flash Cmd Register - Read Area 0x0 */
		if (mxc_nfb_command(NAND_CMD_READ0)) {
			return -1;
		}

		nb_dbg("address");
		/* 
		 * The NAND Flash Addr is a 3 Cycle process. Write to NAND
		 * Flash Addr Register - Start Addr in Page 0x0 
		 */
		if (mxc_nfb_address(0x0)) {
			return -1;
		}

		/*if the pagesize is 2k, 5 cycle process*/
		if(pagesize == 2048){
			  if ( mxc_nfb_address(0x0)) {
                      		 return -1;
              		 }
		}
		
		/* Write to NAND Flash Addr Register - Page Addr in Block 0x0 */
		if (mxc_nfb_address(page)) {
			return -1;
		}
		/* Write to NAND Flash Addr Register - Block Addr 0x0 */
		if (mxc_nfb_address(0x0)) {
			return -1;
		}
		
#if defined(IMX31ADS) || defined(IMX21ADS) || defined(IMX27ADS)
		/* Write to NAND Flash Addr Register - Block Addr 0x0 */
		if (mxc_nfb_address(0x0)) {
			return -1;
		}
#endif
		/*confirm to read*/
		if(pagesize ==2048){
			if ( mxc_nfb_command(NAND_CMD_READSTART)) {
				 return -1;
			}
		}

		/* 
		 * Receive Data in RAM Buffer Addr Register - Set to 1st
		 * Internal Buffer, where data will be loaded. First buffer is
		 * selected as we have already executed the code in 1st RAM
		 * buffer and it is safe to overwrite it. 
		 * (For the record: The code in this file starts at 0x320 which
		 * is beyond 1st RAM buffer end address of 0x1FF.)
		 */
		if (mxc_nfb_bufferaddr(0x0)) {
			return -1;
		}
		if(pagesize ==2048){
			  if (mxc_nfb_bufferaddr(0x1)) {
                       		 return -1;
                	}

			  if (mxc_nfb_bufferaddr(0x2)) {
                      		  return -1;
               		 }
		
			  if (mxc_nfb_bufferaddr(0x3)) {
                       		 return -1;
                	}
		} /*end of pagesize ==2048*/

		/* Read Data from RAM Buffer */
		membuff = MAIN_AREA0;

		nb_dbg("bytecopy");
		/* Read 512 Bytes of NAND Flash */
		for (i = 0; i < (pagesize / 2); i++) {
			*(pMem++) = *(membuff++);
		}
	}
	/* Jump to SPL start address */
	fptr = (FPTR) SPL_DEST_ADDR;
	fptr();
	/* Point of no return */
}
