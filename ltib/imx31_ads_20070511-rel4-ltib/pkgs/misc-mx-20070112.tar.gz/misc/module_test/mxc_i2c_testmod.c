/*
 * Copyright 2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#include <linux/config.h>	/* kmalloc_sizes.h needs CONFIG_ options */
#include <linux/gfp.h>
#include <linux/init.h>
#include <linux/types.h>
#include <asm/page.h>		/* kmalloc_sizes.h needs PAGE_SIZE */
#include <asm/cache.h>		/* kmalloc_sizes.h needs L1_CACHE_BYTES */
#include <linux/module.h>

#include <linux/types.h>
#include <linux/delay.h>

#include <asm/arch/hardware.h>
#include <asm/arch/mxc_i2c.h>
#include <asm/io.h>
#include <asm/arch/gpio.h>
#include <asm/arch/clock.h>

extern int printk(const char *fmt, ...);
void gpio_sensor_active(void);
void gpio_sensor_inactive(void);
//im8012 i2c addr
#define SENSOR_I2C_ADDR 0x48

#define CSI_CTL0 (1<<9)
#define CSI_CTL1 (1<<10)
#define CSI_CTL2 (1<<11)

/*control register bit definitions*/
#define I2CR_ENABLE	0x80
#define I2CR_INTEN	0x40
#define I2CR_MASTER	0x20
#define I2CR_TRANSMIT	0x10
#define I2CR_NOACK	0x08
#define I2CR_REPSTART	0x04

/*status register bit definitions*/
#define I2SR_DATAREADY	0x80
#define I2SR_ADDRASSLA	0x40
#define I2SR_BUSBUSY	0x20
#define I2SR_LOSTARB	0x10
#define I2SR_SLATRANS	0x04
#define I2SR_INTPEND	0x02
#define I2SR_ACKRCVD	0x01
#define MX2_I2C_TIMEOUT HZ	/*timeout for an I2C transfer */


//generate default mclk to drive sensor
static void csihw_open(void)
{
#if defined(CONFIG_ARCH_MX21) || defined (CONFIG_ARCH_MX27)
	unsigned int val;
	unsigned int mclkdiv = 4;	//default set to perclk4/4 => 22MHz
#endif	
	unsigned int perclk4div = 3;	//default set to fclk/3 => 88MHz

	//reset values
#define CSICR1_RESET_VAL	0x40000800
#define CSICR2_RESET_VAL	0x0
#define CSICR3_RESET_VAL	0x0
#define SHIFT_MCLKDIV		12

#define BIT_MCLKEN		(0x1 << 9)

#define CSI_CSICR1	0x00	/*  32bit csi control 1 reg */
#define CSI_CSICR2	0x04	/*  32bit csi control 2 reg */
#define CSI_CSICR3	0x1C	/*  32bit csi control 3 reg */

	mxc_clks_enable(CSI_BAUD);
	//set default perclk4 for mclk
	//if(g_csi_ver == 2)
	mxc_set_clocks_div(CSI_BAUD, perclk4div);
#ifdef CONFIG_ARCH_MX27
	//__raw_writelIO_ADDRESS(CSI_BASE_ADDR)CSI_CSICR1 = CSICR1_RESET_VAL;
	__raw_writel(CSICR2_RESET_VAL, IO_ADDRESS(CSI_BASE_ADDR) + CSI_CSICR2);
	__raw_writel(CSICR3_RESET_VAL, IO_ADDRESS(CSI_BASE_ADDR) + CSI_CSICR3);

	//enable default mclk clock
	val = CSICR1_RESET_VAL;
	val |= ((mclkdiv / 2) - 1) << SHIFT_MCLKDIV;
	val |= BIT_MCLKEN;
	__raw_writel(val, IO_ADDRESS(CSI_BASE_ADDR) + CSI_CSICR1);
#endif
	return;
}

//set reset pin level
static void im8012_hard_reset(void)
{
#ifdef CONFIG_ARCH_MX27
	unsigned short data;
#endif
	printk("resetting 8012!\n");
	//assert reset pulse
#ifdef CONFIG_ARCH_MX27
	data = __raw_readl(PBC_BCTRL2_SET_REG);
	data |= CSI_CTL1;
	__raw_writel(data, PBC_BCTRL2_SET_REG);
	udelay(300);

	data = __raw_readl(PBC_BCTRL2_CLEAR_REG);
	data &= ~CSI_CTL1;
	__raw_writel(data, PBC_BCTRL2_CLEAR_REG);
#endif
	udelay(100);
}

//i2c channel read/write test
static int im8012_i2c_test(void)
{
	int i;
	unsigned short temp_val;
	u8 reg = 1;
	u16 val;
	unsigned long flags;
	im8012_hard_reset();
	i = cpu_to_be16(4);
	mxc_i2c_write(0, SENSOR_I2C_ADDR, &reg, 1, (u8 *) & i, 2);

	reg = 4;

	printk("interrupt mode 1\n");
	for (i = 0; i < 3; i++) {
		val = cpu_to_be16(i);
		mxc_i2c_write(0, SENSOR_I2C_ADDR, &reg, 1, (u8 *) & val, 2);
		mxc_i2c_read(0, SENSOR_I2C_ADDR, &reg, 1, (u8 *) & temp_val, 2);
		temp_val = be16_to_cpu(temp_val);
		printk(" write value is %d,read is %d\n", i, temp_val);

	}
	printk("\n polling mode 1\n");

	local_irq_save(flags);	/* Disable interrupts */
	for (i = 0; i < 3; i++) {
		val = cpu_to_be16(i);
		mxc_i2c_polling_write(0, SENSOR_I2C_ADDR, &reg, 1, (u8 *) & val,
				      2);

		mxc_i2c_polling_read(0, SENSOR_I2C_ADDR, &reg, 1,
				     (u8 *) & temp_val, 2);
		temp_val = be16_to_cpu(temp_val);

		printk(" write value is %d,read is %d\n", i, temp_val);
	}
	local_irq_restore(flags);

	printk("interrupt mode 2\n");
	for (i = 0; i < 3; i++) {
		val = cpu_to_be16(i);
		mxc_i2c_write(0, SENSOR_I2C_ADDR, &reg, 1, (u8 *) & val, 2);

		mxc_i2c_read(0, SENSOR_I2C_ADDR, &reg, 1, (u8 *) & temp_val, 2);
		temp_val = be16_to_cpu(temp_val);
		printk(" write value is %d,read is %d\n", i, temp_val);
	}

	printk("\n polling mode 2\n");
	local_irq_save(flags);	/* Disable interrupts */
	for (i = 0; i < 3; i++) {
		val = cpu_to_be16(i);
		mxc_i2c_polling_write(0, SENSOR_I2C_ADDR, &reg, 1, (u8 *) & val,
				      2);
		mxc_i2c_polling_read(0, SENSOR_I2C_ADDR, &reg, 1,
				     (u8 *) & temp_val, 2);
		temp_val = be16_to_cpu(temp_val);
		printk(" write value is %d,read is %d\n", i, temp_val);
	}
	local_irq_restore(flags);

	im8012_hard_reset();
	return 0;
}

int init_module(void)
{
	printk("i2c test start \n");

	csihw_open();
	im8012_i2c_test();
	return 0;
}

void cleanup_module(void)
{
	printk("i2c test end\n");

}

MODULE_LICENSE("GPL");

