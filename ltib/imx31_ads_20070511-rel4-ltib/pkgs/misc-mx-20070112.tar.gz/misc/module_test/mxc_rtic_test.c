/*
 * Copyright 2005-2006 Freescale Semiconductor, Inc. All rights reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */
/* Setting the watch dog timer value */
#define wtch_timer  0x3E8

/*
 * General Include Files
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/device.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <asm/uaccess.h>
#include "../include/mxc_test.h"
/*
 * Driver specific include files
 */
#include <asm/arch/mxc_security_api.h>
#include <asm/arch/clock.h>
#include <asm/arch/gpio.h>
ulong *gtempu32ptr;
static struct class *mxc_test_class;

static int mxc_test_open(struct inode *inode, struct file *filp)
{
	return 0;
}

static ssize_t mxc_test_read(struct file *file, char *buf, size_t count,
			     loff_t * ppos)
{
	return 0;
}

static ssize_t mxc_test_write(struct file *filp, const char *buf, size_t count,
			      loff_t * ppos)
{
	return 0;
}

static int mxc_test_ioctl(struct inode *inode, struct file *file,
			  unsigned int cmd, unsigned long arg)
{
	ulong *tempu32ptr, tempu32;

	ulong rtic_length1 = 0x01, *rtic_memdata1, i = 0;
	ulong rtic_memdata2, rtic_rem;
	ulong rtic_config, rtic_run_config, rtic_config_mode, rtic_int,
	    rtic_result, wd_time_set;
	rtic_hash_rlt rtic_res;
	unchar irq_en = 0x01;
	tempu32 = (ulong) (*(ulong *) arg);
	tempu32ptr = (ulong *) arg;
	/* Initializing the RTIC clk */
	rtic_init();
	switch (cmd) {

	case MXCTEST_RTIC_ONETIME_TEST:
		printk("RTIC TEST DRV: Parameters received from user"
		       "space:\n");
		printk("RTIC TEST DRV: Parameter1 0x%08lX\n",
		       *(tempu32ptr + 0));
		printk("RTIC TEST DRV: Parameter2 0x%08lX\n",
		       *(tempu32ptr + 1));
		rtic_length1 = *(tempu32ptr + 1);
		if ((rtic_rem = ((ulong) rtic_length1 % 4)) != 0) {
			rtic_length1 = ((ulong) rtic_length1 + 4 - rtic_rem);
		}
		/* Allocating memory to copy user data to kernel memory */
		printk("RTIC TEST DRV: Allocating memory for copying the "
		       "data to be hashed.\n");
		rtic_memdata1 = (ulong *) kmalloc(sizeof(ulong) *
						  (rtic_length1 + 1),
						  GFP_KERNEL);

		RTIC_DEBUG("RTIC TEST DRV: Converting Virtual to Physical"
			   "Addr\n");
		rtic_memdata2 = virt_to_phys(rtic_memdata1);

		RTIC_DEBUG("RTIC TEST DRV: Virtual address 0x%08lX\n",
			   (ulong) rtic_memdata1);
		RTIC_DEBUG("RTIC TEST DRV: Physical address 0x%08lX\n",
			   rtic_memdata2);
		/* Physical address 64 byte alignment */
		if ((rtic_rem = ((ulong) rtic_memdata2 % 4)) != 0) {
			rtic_memdata2 = ((ulong) rtic_memdata2 + 4 - rtic_rem);
		}

		/* Copying 1st memory block from user space to kernel space */
		/* 1 block of data is 512 bytes */
		printk("RTIC TEST DRV: Copying data from user space.\n");
		i = copy_from_user(rtic_memdata1, (ulong *) * tempu32ptr,
				   rtic_length1 * 4);
		if (i != 0) {
			RTIC_DEBUG("RTIC TEST DRV: Couldn't copy %lu bytes of"
				   "data from user space\n", i);
			return -EFAULT;
		}
		printk("RTIC TEST DRV: Block lengths received from user:\n"
		       "Block Length 1: 0x%06lX\n", rtic_length1);
		printk("RTIC TEST DRV: Data received from user space:\n"
		       "Mem block 1: \n");
		tempu32 = rtic_length1;
		for (i = 0; i < tempu32; i++) {
			printk("0x%08lX ", *(rtic_memdata1 + i));
		}
		/* Configure for start address and blk length */
		RTIC_DEBUG("\nRTIC TEST DRV: Configuring address and length\n");
		rtic_config = rtic_configure_mem_blk((ulong) rtic_memdata2,
						     rtic_length1, RTIC_A1);
		if (rtic_config == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring memory block "
				   "of RTIC is success.\n");
		} else if (rtic_config == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring memory block "
				   "of RTIC is failure.\n");
			goto rtic_out;
		}
		/* DMA Throttle reg is set to 0x00 during boot time mode. */
		rtic_hash_once_dma_throttle();
		/* Configuring the ONE-TIME Hashing */
		printk("\nRTIC TEST DRV: Configuring ONE-TIME HASH.\n");
		rtic_config_mode = rtic_configure_mode(RTIC_ONE_TIME, RTIC_A1);
		if (rtic_config_mode == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring "
				   "of RTIC is success.\n");
		} else if (rtic_config_mode == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring  "
				   "of RTIC is failure.\n");
			goto rtic_out;
		}
		printk("Setting the watch dog time\n");
		rtic_wd_timer(wtch_timer);
		/* Enable Interrupt */
		printk("\nRTIC TEST DRV: Configuring interrupt.\n");
		rtic_int = rtic_configure_interrupt(irq_en);
		if (rtic_int == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring "
				   "of RTIC interrupt is success.\n");
		} else if (rtic_int == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring  "
				   "of RTIC interrupt is failure.\n");
		}
		printk("RTIC TEST DRV: Starting ONE_TIME hash the data.\n");
		rtic_start_hash(RTIC_ONE_TIME);
		printk
		    ("RTIC Control reg.After Configuring everything 0x%08lX\n",
		     rtic_get_control());
		printk("RTIC TEST DRV: Waiting for the hashing to be "
		       "finished..\n");
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());
		if ((rtic_get_status() & 0x04) == RTIC_STAT_HASH_ERR) {
			RTIC_DEBUG("RTIC TEST DRV: RTIC Status register. "
				   "0x%08lX \n ", rtic_get_status());
			printk("RTIC TEST DRV: Encountered Error while "
			       "processing\n");
			/* Bus error has occurred */
			/* Freeing all the memory allocated */
			kfree(rtic_memdata1);
			return -EACCES;
		} else if ((rtic_get_status() & 0x02) == RTIC_STAT_HASH_DONE) {
			printk("RTIC TEST DRV: Hashing done. Continuing "
			       "hash.\n");
		}
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());

		/* Hashing done successfully. Now reading the  hash data
		 * from memory.
		 */
		tempu32ptr = (ulong *) kmalloc(sizeof(ulong) * 5, GFP_KERNEL);
		rtic_result = rtic_hash_result(RTIC_A1, RTIC_ONE_TIME,
					       &rtic_res);
		if (rtic_result == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Read Hash data from "
				   "RTIC is success.\n");
		} else if (rtic_result == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Read Hash data from  "
				   "RTIC is failure.\n");
		}
		/* Displaying the hash data */
		for (i = 0; i < 5; i++) {
			printk("RTIC TEST DRV: Hash result%lu: 0x%08lX\n",
			       i + 1, rtic_res.hash_result[i]);
		}
		/* Freeing all the memory allocated */
	      rtic_out:kfree(rtic_memdata1);
		kfree(tempu32ptr);
		return 0;

	case MXCTEST_RTIC_RUNTIME_TEST:
		printk("RTIC TEST DRV: Parameters received from user"
		       "space:\n");
		printk("RTIC TEST DRV: Parameter1 0x%08lX\n",
		       *(tempu32ptr + 0));
		printk("RTIC TEST DRV: Parameter2 0x%08lX\n",
		       *(tempu32ptr + 1));
		rtic_length1 = *(tempu32ptr + 1);
		if ((rtic_rem = ((ulong) rtic_length1 % 4)) != 0) {
			rtic_length1 = ((ulong) rtic_length1 + 4 - rtic_rem);
		}
		/* Allocating memory to copy user data to kernel memory */
		printk("RTIC TEST DRV: Allocating memory for copying the "
		       "data to be hashed.\n");
		rtic_memdata1 = (ulong *) kmalloc(sizeof(ulong) *
						  (rtic_length1 + 1),
						  GFP_KERNEL);

		RTIC_DEBUG("RTIC TEST DRV: Converting Virtual to Physical"
			   "Addr\n");
		rtic_memdata2 = virt_to_phys(rtic_memdata1);

		RTIC_DEBUG("RTIC TEST DRV: Virtual address 0x%08lX\n",
			   (ulong) rtic_memdata1);
		RTIC_DEBUG("RTIC TEST DRV: Physical address 0x%08lX\n",
			   rtic_memdata2);
		/* Physical address 64 byte alignment */
		if ((rtic_rem = ((ulong) rtic_memdata2 % 4)) != 0) {
			rtic_memdata2 = ((ulong) rtic_memdata2 + 4 - rtic_rem);
		}

		/* Copying 1st memory block from user space to kernel space */
		/* 1 block of data is 512 bytes */
		printk("RTIC TEST DRV: Copying data from user space.\n");
		i = copy_from_user(rtic_memdata1, (ulong *) * tempu32ptr,
				   rtic_length1 * 4);
		if (i != 0) {
			RTIC_DEBUG("RTIC TEST DRV: Couldn't copy %lu bytes of"
				   "data from user space\n", i);
			return -EFAULT;
		}

		printk("RTIC TEST DRV: Block lengths received from user:\n"
		       "Block Length 1: 0x%06lX\n", rtic_length1);
		printk("RTIC TEST DRV: Data received from user space:\n"
		       "Mem block 1: \n");
		tempu32 = rtic_length1;
		for (i = 0; i < tempu32; i++) {
			printk("0x%08lX ", *(rtic_memdata1 + i));
		}
		printk("RTIC TEST: Pass DMA Burst read.\n");
		rtic_dma_burst_read(RTIC_DMA_16_WORD);
		/* DMA Throttle reg is set to 0x00 during boot time mode. */
		rtic_hash_once_dma_throttle();
		printk("RTIC Control reg.0x%08lX\n", rtic_get_control());
		/* Configuring the ONE-TIME Hashing */
		printk("\nRTIC TEST DRV: Configuring ONE-TIME HASH.\n");
		rtic_config_mode = rtic_configure_mode(RTIC_ONE_TIME, RTIC_A1);
		if (rtic_config_mode == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring "
				   "of RTIC is success.\n");
		} else if (rtic_config_mode == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring  "
				   "of RTIC is failure.\n");
			goto rtic_run_out;
		}
		/* Enable Interrupt */
		printk("\nRTIC TEST DRV: Configuring interrupt.\n");
		rtic_int = rtic_configure_interrupt(irq_en);
		if (rtic_int == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring "
				   "of RTIC interrupt is success.\n");
		} else if (rtic_int == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring  "
				   "of RTIC interrupt is failure.\n");
		}
		printk("RTIC TEST DRV: Starting ONE_TIME hash the data.\n");
		rtic_start_hash(RTIC_ONE_TIME);
		printk("RTIC TEST DRV: Waiting for the hashing to be "
		       "finished..\n");
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());
		printk("RTIC: Dma delay configure.\n");

		rtic_dma_delay(0x001f);
		printk("configure mem for run-time.\n");
		/* Setting the Watch Dog Timer */
		printk("RTIC TEST DRV: watchdog timer got configured\n");
		wd_time_set = rtic_wd_timer(wtch_timer);
		if (wd_time_set == RTIC_SUCCESS) {
			RTIC_DEBUG
			    ("RTIC TEST DRV : Configuring the watch dog timer"
			     "is success.\n");
		} else if (wd_time_set == RTIC_FAILURE) {
			RTIC_DEBUG
			    ("RTIC TEST DRV : Configuring the watch dog timer"
			     " is failure \n");
		}

		rtic_run_config = rtic_configure_mode(RTIC_RUN_TIME, RTIC_A1);
		printk("RTIC TEST DRV: Starting RUn_TIME hash the data.\n");
		rtic_start_hash(RTIC_RUN_TIME);

		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());
		tempu32ptr = (ulong *) kmalloc(sizeof(ulong) * 5, GFP_KERNEL);
		rtic_result = rtic_hash_result(RTIC_A1, RTIC_RUN_TIME,
					       &rtic_res);
		if (rtic_result == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Read Hash data from "
				   "RTIC is success.\n");
		} else if (rtic_result == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Read Hash data from  "
				   "RTIC is failure.\n");
		}
		/* Displaying the hash data */
		for (i = 0; i < 5; i++) {
			printk("RTIC TEST DRV: Hash result%lu: 0x%08lX\n",
			       i + 1, rtic_res.hash_result[i]);
		}

		/* Freeing all the memory allocated */
	      rtic_run_out:kfree(rtic_memdata1);
		kfree(tempu32ptr);
		return 0;

	case MXCTEST_RTIC_RUNTIME_ERROR:
		printk("RTIC TEST DRV: Parameters received from user"
		       "space:\n");
		printk("RTIC TEST DRV: Parameter1 0x%08lX\n",
		       *(tempu32ptr + 0));
		printk("RTIC TEST DRV: Parameter2 0x%08lX\n",
		       *(tempu32ptr + 1));
		rtic_length1 = *(tempu32ptr + 1);
		if ((rtic_rem = ((ulong) rtic_length1 % 4)) != 0) {
			rtic_length1 = ((ulong) rtic_length1 + 4 - rtic_rem);
		}
		/* Allocating memory to copy user data to kernel memory */
		printk("RTIC TEST DRV: Allocating memory for copying the "
		       "data to be hashed.\n");
		rtic_memdata1 = (ulong *) kmalloc(sizeof(ulong) *
						  (rtic_length1 + 1),
						  GFP_KERNEL);

		RTIC_DEBUG("RTIC TEST DRV: Converting Virtual to Physical"
			   "Addr\n");
		rtic_memdata2 = virt_to_phys(rtic_memdata1);

		RTIC_DEBUG("RTIC TEST DRV: Virtual address 0x%08lX\n",
			   (ulong) rtic_memdata1);
		RTIC_DEBUG("RTIC TEST DRV: Physical address 0x%08lX\n",
			   rtic_memdata2);
		/* Physical address 64 byte alignment */
		if ((rtic_rem = ((ulong) rtic_memdata2 % 4)) != 0) {
			rtic_memdata2 = ((ulong) rtic_memdata2 + 4 - rtic_rem);
		}

		/* Copying 1st memory block from user space to kernel space */
		/* 1 block of data is 512 bytes */
		printk("RTIC TEST DRV: Copying data from user space.\n");
		i = copy_from_user(rtic_memdata1, (ulong *) * tempu32ptr,
				   rtic_length1 * 4);
		if (i != 0) {
			RTIC_DEBUG("RTIC TEST DRV: Couldn't copy %lu bytes of"
				   "data from user space\n", i);
			return -EFAULT;
		}
		printk("RTIC TEST DRV: Block lengths received from user:\n"
		       "Block Length 1: 0x%06lX\n", rtic_length1);
		printk("RTIC TEST DRV: Physical address 0x%08lX\n",
		       rtic_memdata2);
		printk("RTIC TEST DRV: Data received from user space:\n"
		       "Mem block 1: \n");
		tempu32 = rtic_length1;
		for (i = 0; i < tempu32; i++) {
			printk("0x%08lX ", *(rtic_memdata1 + i));
		}

		/* Configure for start address and blk length */
		RTIC_DEBUG("\nRTIC TEST DRV: Configuring address and length\n");
		printk("Getting in to  for configuring the memory\n");
		rtic_config = rtic_configure_mem_blk((ulong) rtic_memdata2,
						     rtic_length1, RTIC_A1);
		if (rtic_config == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring memory block "
				   "of RTIC is success.\n");
		} else if (rtic_config == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring memory block "
				   "of RTIC is failure.\n");
			goto rtic_out;
		}

		/* Configuring the ONE-TIME Hashing */
		printk("\nRTIC TEST DRV: Configuring ONE-TIME HASH.\n");
		rtic_config_mode = rtic_configure_mode(RTIC_ONE_TIME, RTIC_A1);
		if (rtic_config_mode == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring "
				   "of RTIC is success.\n");
		} else if (rtic_config_mode == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring  "
				   "of RTIC is failure.\n");
			goto out;
		}
		/* Enable Interrupt */
		printk("\nRTIC TEST DRV: Configuring interrupt.\n");
		rtic_int = rtic_configure_interrupt(irq_en);
		if (rtic_int == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring "
				   "of RTIC interrupt is success.\n");
		} else if (rtic_int == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring  "
				   "of RTIC interrupt is failure.\n");
		}
		/* Setting the Watch Dog Timer */
		/* printk("RTIC TEST DRV: watchdog timer got configured\n");
		   wd_time_set = rtic_wd_timer(wtch_timer);
		   if(wd_time_set == RTIC_SUCCESS) {
		   RTIC_DEBUG("RTIC TEST DRV : Configuring the watch dog timer"
		   "is success.\n");
		   }else if (wd_time_set == RTIC_FAILURE) {
		   RTIC_DEBUG("RTIC TEST DRV : Configuring the watch dog timer"
		   " is failure \n");
		   } */
		printk("RTIC TEST: Pass DMA Burst read.\n");
		rtic_dma_burst_read(RTIC_DMA_16_WORD);
		printk("RTIC Control reg.0x%08lX\n", rtic_get_control());
		printk("RTIC: Dma delay configure.\n");
		rtic_dma_delay(0x001f);
		printk("RTIC TEST: WDtimer set.\n");
		rtic_wd_timer(0x001f);
		printk("RTIC TEST DRV: Starting ONE_TIME hash the data.\n");
		rtic_start_hash(RTIC_ONE_TIME);
		printk("RTIC TEST DRV: Waiting for the hashing to be "
		       "finished..\n");
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());
		printk("configure mem for run-time.\n");
		rtic_run_config = rtic_configure_mode(RTIC_RUN_TIME, RTIC_A1);
		printk("RTIC TEST DRV: Starting RUn_TIME hash the data.\n");
		printk("RTIC: Dma delay configure.\n");
		rtic_dma_delay(0x001f);
		printk("RTIC TEST: WDtimer set.\n");
		rtic_wd_timer(0x0001f);
		rtic_start_hash(RTIC_RUN_TIME);
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());
		if ((rtic_get_status() & 0x04) == RTIC_STAT_HASH_ERR) {
			RTIC_DEBUG("RTIC TEST DRV: RTIC Status register. "
				   "0x%08lX \n ", rtic_get_status());
			printk("RTIC TEST DRV: Encountered Error while "
			       "processing\n");
			/* Bus error has occurred */
			/* Freeing all the memory allocated */
			kfree(rtic_memdata1);
			return -EACCES;
		} else if ((rtic_get_status() & 0x02) == RTIC_STAT_HASH_DONE) {
			printk("RTIC TEST DRV: Hashing done. Continuing "
			       "hash.\n");
		}
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());
		/* Hashing done successfully. Now reading the  hash data
		 * from memory.
		 */
		/*tempu32ptr = (ulong *) kmalloc(sizeof(ulong) * 5, GFP_KERNEL);
		   rtic_result = rtic_hash_result(RTIC_A1, &rtic_res);
		   if (rtic_result == RTIC_SUCCESS) {
		   RTIC_DEBUG("RTIC TEST DRV: Read Hash data from "\
		   "RTIC is success.\n");
		   } else if (rtic_result == RTIC_FAILURE) {
		   RTIC_DEBUG("RTIC TEST DRV: Read Hash data from  "\
		   "RTIC is failure.\n");
		   } */
		/*rtic_run_config = rtic_configure_mode(RTIC_RUN_TIME, RTIC_A1);
		   rtic_start_hash(RTIC_RUN_TIME);
		   printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		   rtic_get_status());
		   if ((rtic_get_status() & 0x04) == RTIC_STAT_HASH_ERR) {
		   RTIC_DEBUG("RTIC TEST DRV: RTIC Status register. "\
		   "0x%08lX \n ", rtic_get_status());
		   printk("RTIC TEST DRV: Encountered Error while "\
		   "processing\n"); */
		/* Bus error has occurred */
		/* Freeing all the memory allocated */
		/*       kfree(rtic_memdata1);
		   return -EACCES;
		   } else if ((rtic_get_status() & 0x02) == RTIC_STAT_HASH_DONE) {
		   printk("RTIC TEST DRV: Hashing done. Continuing "\
		   "hash.\n");
		   }
		   printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		   rtic_get_status()); */
		/* Hashing done successfully. Now reading the  hash data
		 * from memory.
		 */
		tempu32ptr = (ulong *) kmalloc(sizeof(ulong) * 5, GFP_KERNEL);
		rtic_result = rtic_hash_result(RTIC_A1, RTIC_RUN_TIME,
					       &rtic_res);
		if (rtic_result == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Read Hash data from "
				   "RTIC is success.\n");
		} else if (rtic_result == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Read Hash data from  "
				   "RTIC is failure.\n");
		}
		/* Displaying the hash data */
		for (i = 0; i < 5; i++) {
			printk("RTIC TEST DRV: Hash result%lu: 0x%08lX\n",
			       i + 1, rtic_res.hash_result[i]);
		}

		/* Freeing all the memory allocated */
	      out:kfree(rtic_memdata1);
		kfree(tempu32ptr);
		return 0;

	case MXCTEST_RTIC_STATUS:
		printk("RTIC TEST DRV: Status of the RTIC module is: "
		       "0x%08lX", rtic_get_status());
		return rtic_get_status();

	default:
		printk("MXC TEST IOCTL %d not supported\n", cmd);
		break;
	}
	return -EINVAL;
}

static int mxc_test_release(struct inode *inode, struct file *filp)
{
	return 0;
}

static struct file_operations mxc_test_fops = {
	.owner = THIS_MODULE,
	.open = mxc_test_open,
	.release = mxc_test_release,
	.read = mxc_test_read,
	.write = mxc_test_write,
	.ioctl = mxc_test_ioctl,
};

static int __init mxc_test_init(void)
{
	struct class_device *temp_class;
	int res;

	res =
	    register_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test", &mxc_test_fops);

	if (res < 0) {
		printk(KERN_WARNING "MXC Test: unable to register the dev\n");
		return res;
	}

	mxc_test_class = class_create(THIS_MODULE, "mxc_test");
	if (IS_ERR(mxc_test_class)) {
		printk(KERN_ERR "Error creating mxc_test class.\n");
		unregister_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test");
		class_device_destroy(mxc_test_class,
				     MKDEV(MXC_TEST_MODULE_MAJOR, 0));
		return PTR_ERR(mxc_test_class);
	}

	temp_class = class_device_create(mxc_test_class, NULL,
					 MKDEV(MXC_TEST_MODULE_MAJOR, 0), NULL,
					 "mxc_test");
	if (IS_ERR(temp_class)) {
		printk(KERN_ERR "Error creating mxc_test class device.\n");
		class_device_destroy(mxc_test_class,
				     MKDEV(MXC_TEST_MODULE_MAJOR, 0));
		class_destroy(mxc_test_class);
		unregister_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test");
		return -1;
	}

	return 0;
}

static void __exit mxc_test_exit(void)
{
	unregister_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test");
	class_device_destroy(mxc_test_class, MKDEV(MXC_TEST_MODULE_MAJOR, 0));
	class_destroy(mxc_test_class);
}

module_init(mxc_test_init);
module_exit(mxc_test_exit);

MODULE_DESCRIPTION("Test Module for MXC drivers");
MODULE_LICENSE("GPL");
