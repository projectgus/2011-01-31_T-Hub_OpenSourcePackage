/*
 * Copyright 2004 Freescale Semiconductor, Inc. All Rights Reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */ 

#include <sys/types.h>    /* open()  */
#include <sys/stat.h>     /* open()  */
#include <fcntl.h>        /* open()  */
#include <sys/ioctl.h>    /* ioctl() */
#include <unistd.h>       /* close() */
#include <stdio.h>	/* sscanf() & perror() */
#include <stdlib.h>	/* atoi() */
#include <string.h>	/* string */
#include <errno.h>
#include <sched.h>	

#include "../module_test/testmod_ssi.h"

#define SSI1					0x0
#define SSI2					0x1

#define MAX_CHUNK_SIZE				(1024 * 128)

//#define DEBUG 

#ifdef DEBUG
#define DPRINTF(fmt, args...) 		printf("%s: " fmt, __FUNCTION__ , ## args)
#else //DEBUG
#define DPRINTF(fmt, args...)
#endif //DEBUG

#ifndef false
#define false 0
#endif

#ifndef true
#define true 1
#endif

#ifndef bool
#define bool int
#endif

static struct wave_config wave_config;

static char buffer[MAX_CHUNK_SIZE];
static char file[256];

void help_info(void) {
	printf("\n\n**************************************************\n");
        printf("* Test aplication for ssi low level API \n");
        printf("* Options : \n\n");
	printf("mxc_ssi_test <ssi_nb-device> <soundfile.wav> \n Plays the file to /dev/dspX\n");
	printf("ssi_nb-device : 0 for SSI1-STEREODAC, 1 for SSI1-CODEC\n");
	printf("ssi_nb-device : 2 for SSI2-STEREODAC, 3 for SSI2-CODEC\n");
        printf("**************************************************\n\n");
}

/*
void read_header_wave(int sample_fd)
{
        unsigned short header[29];

        read(sample_fd, header, 58);
        wave_config.num_channels = header[11];
        
        wave_config.sample_rate = (((long)(header[12])) & 0x0000FFFF) |
                                       ((((long)((header[13])) << 16)) & 0xFFFF0000);
        wave_config.bits_per_sample = header[17];
	wave_config.sample_size = (((long)(header[27])) & 0x0000FFFF) |
                                       ((((long)((header[28])) << 16)) & 0xFFFF0000);
                                       
        printf("sample size = %d\n", (int)wave_config.sample_size);
        printf("sample rate = %d\n", (int)wave_config.sample_rate);
        printf("bits per sample = %d\n", wave_config.bits_per_sample);
        printf("num channels = %d\n", wave_config.num_channels);
}
*/

void read_header_wave(FILE* sample_fd)
{
        unsigned short header[29];

        fread(header, 2, 29, sample_fd);
        wave_config.num_channels = header[11];
        
        wave_config.sample_rate = (((long)(header[12])) & 0x0000FFFF) |
                                       ((((long)((header[13]))<<16)) & 0xFFFF0000);
        wave_config.bits_per_sample = header[17];
	wave_config.sample_size = (((long)(header[27])) & 0x0000FFFF) |
                                       ((((long)((header[28]))<<16)) & 0xFFFF0000);
                                       
        DPRINTF("sample size = %d\n", (int)wave_config.sample_size);
        DPRINTF("sample rate = %d\n", (int)wave_config.sample_rate);
        DPRINTF("bits per sample = %d\n", wave_config.bits_per_sample);
        DPRINTF("num channels = %d\n", wave_config.num_channels);
}

void play_sample(FILE* sample_fd, int fd)
{
        int size;
        int bytes_read;
        int bytes_written;
        char* p;
                
        size = wave_config.sample_size;
        DPRINTF("sample size = %d\n", size);
        
        while((bytes_read = fread(buffer, 1, MAX_CHUNK_SIZE, sample_fd))){
        	if((bytes_read == -1) && (errno != EINTR)){
        		break;
        	}else if(bytes_read > 0){
        		//DPRINTF("read %d bytes from audio file\n", bytes_read);
        		p = buffer;
        		while((bytes_written = write(fd, p, bytes_read))){
        			if((bytes_read == -1) && (errno != EINTR)){
        				break;
        			}else if(bytes_written == bytes_read){
        				break;
        			}else if(bytes_written > 0){
        				p += bytes_written;
        				bytes_read -= bytes_written;
        			}
        		}
        		
        		if(bytes_written == -1){
        			break;
        		}
        		
        		//DPRINTF("%d bytes written\n", bytes_written);
        		//DPRINTF("%d bytes remaining\n", bytes_read);
        	}
        }
        
        printf("transfer finished\n");
}

int main(int argc, char** argv)
{
	FILE* sample_fd = NULL;
        int option, ret;
        int fd = -1;

	DPRINTF("Get options...\n");
	if(argc != 3){
		help_info();
         	return 1;
        }
        
        DPRINTF("get option for ssi-device\n");
        option = atoi(argv[1]);
        	
	DPRINTF("get option for wav file\n");
	strcpy(file, argv[2]);
	
	if((option < 0) || (option > 3)){
        	printf("unrecognized parameter for device option\n");
        	return 1;
        }
        
       	sample_fd = fopen(file, "r");
       	if(sample_fd == NULL){
       		printf("error when opening sample file\n");
       		return 1;
       	}
       	
       	DPRINTF("Read the file WAV header...\n");
        read_header_wave(sample_fd);
        
        wave_config.mix_enabled = 0;
        wave_config.master_clock = MC13783_MASTER;
        DPRINTF("1 sample rate %d\n", (int)wave_config.sample_rate);
        
	switch(option){
	 case 0:
	 	printf("playing on SSI1-STEREODAC\n");
	 	printf("opening %s\n", DEVICE_NAME_SSI1);

		fd = open(DEVICE_NAME_SSI1, O_RDWR);
		wave_config.ssi = 0;
		wave_config.mc13783_device = STEREO_DAC;
	 	break;
	 	
	 case 1:
	 	printf("playing on SSI1-CODEC\n");
	 	printf("opening %s\n", DEVICE_NAME_SSI1);

		fd = open(DEVICE_NAME_SSI1, O_RDWR);
		wave_config.ssi = 0;
		wave_config.mc13783_device = CODEC;
	 	break;
	 	
	 case 2:
	 	printf("playing on SSI2-STEREODAC\n");
	 	printf("opening %s\n", DEVICE_NAME_SSI2);

		fd = open(DEVICE_NAME_SSI2, O_RDWR);
		wave_config.ssi = 1;
		wave_config.mc13783_device = STEREO_DAC;
	 	break;
	 	
	 case 3:
	 	printf("playing on SSI2-CODEC\n");
	 	printf("opening %s\n", DEVICE_NAME_SSI2);

		fd = open(DEVICE_NAME_SSI2, O_RDWR);
		wave_config.ssi = 1;
		wave_config.mc13783_device = CODEC;
	 	break;
	 	
	 default:
	 	return 1;
	}
	
	DPRINTF("Configure DAM...\n");
	ioctl(fd, IOCTL_SSI_CONFIGURE_AUDMUX, &wave_config);
	
	DPRINTF("Configure SSI...\n");	
        ret = ioctl(fd, IOCTL_SSI_CONFIGURE_SSI, &wave_config);
        if(ret == -1){
               	printf("error in IOCTL_SSI_CONFIGURE_SSI ioctl\n");
               	goto error;
        }
        
        DPRINTF("Configure MC13783 \n");        
        ret = ioctl(fd, IOCTL_SSI_CONFIGURE_MC13783, &wave_config);	
        if(ret == -1){
               	printf("error in IOCTL_SSI_CONFIGURE_MC13783 ioctl\n");
               	goto error;
        }

       	DPRINTF("Play sample \n");
       	play_sample(sample_fd, fd);

error:
	printf("Closing device\n");
        close(fd);
        fclose(sample_fd);
        printf("Quitting application\n");
	
        return 0;
}

