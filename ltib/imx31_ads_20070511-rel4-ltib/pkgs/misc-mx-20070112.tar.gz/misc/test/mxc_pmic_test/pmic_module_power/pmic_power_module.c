/*=============================================================================
    @file   pmic_power_module.c

    @brief  power module source file
===============================================================================

        Copyright (C) 2004, Freescale Semiconductor, Inc. All Rights Reserved
        ТHIS SOURCE CODE IS CONFIDENTIAL AND PROPRIETARY AND MAY NOT
        BE USED OR DISTRIBUTED WITHOUT THE WRITTEN PERMISSION OF
        Freescale Semiconductor, Inc.

================================================================================
Revision History:
                        Modification    Tracking
Author (core id)        Date            Number          Description of Changes
--------------------------------------------------------------------------------
J.QUINTERO/JQUI1C       11/07/2005      DSPhl26599      Initial version
================================================================================
Portability:  ARM GCC  gnu compiler
==============================================================================*/

/*==============================================================================
Total Tests: 3

Test Executable Name:  pmic_power_module.ko

=============================================================================*/

/*==============================================================================
                                        INCLUDE FILES
==============================================================================*/
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/config.h>
#include <linux/device.h>
#include <linux/kdev_t.h>
#include <linux/major.h>
#include <linux/version.h>
#include <linux/devfs_fs_kernel.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <asm/uaccess.h>
#include "pmic_power_module.h"
/*
 * Driver specific include files
 */
#include <asm/arch/pmic_status.h>
#include <asm/arch/pmic_power.h>

/*==============================================================================
                                       DEFINES AND MACROS
==============================================================================*/
#define ERROR_CHECK(a,b,arg...)\
        {\
                printk(KERN_WARNING "Calling "#a" "b"\n.",##arg); \
                status = a; \
                if( status != PMIC_SUCCESS ) { \
                        printk(KERN_WARNING "Error in  power test: "#a" "b". Returned code %d\n",##arg,status); \
                        UT_rv = status; \
                } \
        }

/*==============================================================================
                                     FUNCTION PROTOTYPES
==============================================================================*/

int UT_pmic_power_test_control(void)
{
/*Call pmic_power_regulator_on (t_pmic_regulator regulator) and 
 then pmic_power_regulator_off (t_pmic_regulator regulator) 
 with valid parameters*/

	PMIC_STATUS status;
	t_pmic_regulator regulator[6] = { REGU_VCAM, REGU_VSIM, REGU_VAUDIO,
		REGU_VVIB, REGU_VMMC1, REGU_VMMC2
	};
	int UT_rv = TPASS;
	int i;

	for (i = 0; i <= 5; i++) {
		ERROR_CHECK(pmic_power_regulator_on(regulator[i]), "");
	}

	for (i = 0; i <= 5; i++) {
		ERROR_CHECK(pmic_power_regulator_off(regulator[i]), "");
	}

	return UT_rv;

}

int UT_pmic_power_test_config(void)
{
/* Call pmic_power_set_pc_config (t_pc_config pc_config) and 
then pmic_power_get_pc_config (t_pc_config pc_config) with valid parameters*/

	PMIC_STATUS status;

	t_pc_config *pc_config, *pc_config_1;

	int UT_rv = TPASS;

	if ((pc_config = kmalloc(sizeof(t_pc_config), GFP_KERNEL))
	    == NULL) {
		return -ENOMEM;
	}

	if ((pc_config_1 = kmalloc(sizeof(t_pc_config), GFP_KERNEL))
	    == NULL) {
		return -ENOMEM;
	}

	pc_config->pc_enable = true;
	pc_config->pc_timer = 127;
	pc_config->pc_count_enable = true;
	pc_config->pc_count = 0;	/* read only */
	pc_config->pc_max_count = 15;
	pc_config->warm_enable = true;
	pc_config->clk_32k_enable = true;
	pc_config->vhold_voltage = VH_2_5V;
	pc_config->mem_timer = 15;
	pc_config->mem_allon = true;

	ERROR_CHECK(pmic_power_set_pc_config(pc_config), "");
	ERROR_CHECK(pmic_power_get_pc_config(pc_config_1), "");

	if (pc_config->pc_enable != pc_config_1->pc_enable) {
		printk(KERN_WARNING "Error in power pc config(pc_enable),"
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       pc_config->pc_enable, pc_config_1->pc_enable);
		UT_rv = TFAIL;
	}

	if (pc_config->pc_timer != pc_config_1->pc_timer) {
		printk(KERN_WARNING "Error in power pc config(pc_timer),"
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       pc_config->pc_timer, pc_config_1->pc_timer);
		UT_rv = TFAIL;
	}
	if (pc_config->pc_count_enable != pc_config_1->pc_count_enable) {
		printk(KERN_WARNING "Error in power pc config(pc_count_enable),"
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       pc_config->pc_count_enable,
		       pc_config_1->pc_count_enable);
		UT_rv = TFAIL;
	}

	if (pc_config->pc_count != pc_config_1->pc_count) {
		printk(KERN_WARNING "Error in power pc config(pc_count),"
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       pc_config->pc_count, pc_config_1->pc_count);
		UT_rv = TFAIL;
	}

	if (pc_config->pc_max_count != pc_config_1->pc_max_count) {
		printk(KERN_WARNING "Error in power pc config(pc_max_count),"
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       pc_config->pc_max_count, pc_config_1->pc_max_count);
		UT_rv = TFAIL;
	}

	if (pc_config->warm_enable != pc_config_1->warm_enable) {
		printk(KERN_WARNING "Error in power pc config(warm__enable),"
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       pc_config->warm_enable, pc_config_1->warm_enable);
		UT_rv = TFAIL;
	}

	if (pc_config->clk_32k_enable != pc_config_1->clk_32k_enable) {
		printk(KERN_WARNING "Error in power pc config(clk_32k_enable),"
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       pc_config->clk_32k_enable, pc_config_1->clk_32k_enable);
		UT_rv = TFAIL;
	}

	if (pc_config->vhold_voltage != pc_config_1->vhold_voltage) {
		printk(KERN_WARNING "Error in power pc config(vhold_voltage),"
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       pc_config->vhold_voltage, pc_config_1->vhold_voltage);
		UT_rv = TFAIL;
	}

	if (pc_config->mem_timer != pc_config_1->mem_timer) {
		printk(KERN_WARNING "Error in power pc config(mem_timer),"
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       pc_config->mem_timer, pc_config_1->mem_timer);
		UT_rv = TFAIL;
	}

	if (pc_config->mem_allon != pc_config_1->mem_allon) {
		printk(KERN_WARNING "Error in power pc config(mem_allon),"
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       pc_config->mem_allon, pc_config_1->mem_allon);
		UT_rv = TFAIL;
	}

	kfree(pc_config);
	kfree(pc_config_1);

	return UT_rv;

}

int UT_pmic_power_test_voltage(void)
{
	/* Call pmic_power_regulator_set_voltage (t_pmic_regulator regulator, 
	   t_regulator_voltage voltage) 
	   and then pmic_power_regulator_get_voltage (t_pmic_regulator regulator, 
	   t_regulator_voltage * voltage) 
	   with valid parameters */

	PMIC_STATUS status;
	t_pmic_regulator regulator;
	t_regulator_voltage voltage, voltage_1;

	int UT_rv = TPASS;

	regulator = REGU_VCAM;
	voltage.vcam = VCAM_2_5V;

	ERROR_CHECK(pmic_power_regulator_set_voltage(regulator, voltage),
		    "regulator=SW1 voltage=%d", voltage.vcam);
	ERROR_CHECK(pmic_power_regulator_get_voltage(regulator, &voltage_1),
		    "");

	if (voltage.vcam != voltage_1.vcam) {
		printk(KERN_WARNING "Error in power regulator voltage VCAM, "
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       voltage.vcam, voltage_1.vcam);
		UT_rv = TFAIL;
	}

	regulator = REGU_VSIM;
	voltage.vsim = VSIM_1_8V;

	ERROR_CHECK(pmic_power_regulator_set_voltage(regulator, voltage),
		    "regulator=VSIM voltage=%d", voltage.vsim);
	ERROR_CHECK(pmic_power_regulator_get_voltage(regulator, &voltage_1),
		    "");

	if (voltage.vsim != voltage_1.vsim) {
		printk(KERN_WARNING "Error in power regulator voltage VSIM, "
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       voltage.vsim, voltage_1.vsim);
		UT_rv = TFAIL;
	}

	regulator = REGU_VMMC1;
	voltage.vmmc1 = VMMC1_2_6V;

	ERROR_CHECK(pmic_power_regulator_set_voltage(regulator, voltage),
		    "regulator=VMMC1 voltage=%d", voltage.vmmc1);
	ERROR_CHECK(pmic_power_regulator_get_voltage(regulator, &voltage_1),
		    "");

	if (voltage.vmmc1 != voltage_1.vmmc1) {
		printk(KERN_WARNING "Error in power regulator voltage VMMC1, "
		       "mismatch written and read parametrs:written=%d "
		       "read=%d\n", voltage.sw3, voltage_1.sw3);
		UT_rv = TFAIL;
	}

	regulator = REGU_VMMC2;
	voltage.vmmc2 = VMMC2_2_6V;

	ERROR_CHECK(pmic_power_regulator_set_voltage(regulator, voltage),
		    "regulator=VMMC2 voltage=%d", voltage.vmmc2);
	ERROR_CHECK(pmic_power_regulator_get_voltage(regulator, &voltage_1),
		    "");

	if (voltage.vmmc2 != voltage_1.vmmc2) {
		printk(KERN_WARNING "Error in power regulator voltage VMMC2, "
		       "mismatch written and read parametrs:written=%d read=%d\n",
		       voltage.vmmc2, voltage_1.vmmc2);
		UT_rv = TFAIL;
	}

	return UT_rv;

}

int UT_pmic_power_test_misc(void)
{
	/* Call pmic_power_get_power_sense, pmic_power_set_auto_reset_en
	   pmic_power_set_conf_button, pmic_power_vbk2up_auto_en,
	   pmic_power_bat_det_en */

	PMIC_STATUS status;
	int i = 0;
	int val = 0, val2 = 0;
	struct t_p_up_sense var_p_up_sense;
	int UT_rv = TPASS;

	ERROR_CHECK(pmic_power_get_power_mode_sense(&var_p_up_sense), "");

	ERROR_CHECK(pmic_power_set_auto_reset_en(true), "");
	ERROR_CHECK(pmic_power_get_auto_reset_en(&val), "");
	if (val != true) {
		printk(KERN_WARNING "Error in auto reset conf\n");
		UT_rv = TFAIL;
	}
	ERROR_CHECK(pmic_power_set_auto_reset_en(false), "");

	for (i = 0; i < BT_ON3B; i++) {
		ERROR_CHECK(pmic_power_set_conf_button(i, true, 2), "");
		ERROR_CHECK(pmic_power_get_conf_button(i, &val, &val2), "");
		if ((val != true) || (val2 != 2)) {
			printk(KERN_WARNING "Error in button conf\n");
			UT_rv = TFAIL;
		}
		ERROR_CHECK(pmic_power_set_conf_button(i, false, 0), "");
	}

//#ifdef CONFIG_MXC_MC13783_V2

	ERROR_CHECK(pmic_power_vbkup2_auto_en(true), "");
	ERROR_CHECK(pmic_power_get_vbkup2_auto_state(&val), "");
	if (val != true) {
		printk(KERN_WARNING "Error in auto vbkup conf\n");
		UT_rv = TFAIL;
	}
	ERROR_CHECK(pmic_power_vbkup2_auto_en(false), "");

	ERROR_CHECK(pmic_power_bat_det_en(true), "");
	ERROR_CHECK(pmic_power_get_bat_det_state(&val), "");
	if (val != true) {
		printk(KERN_WARNING "Error in bat detect conf\n");
		UT_rv = TFAIL;
	}
	ERROR_CHECK(pmic_power_bat_det_en(false), "");

//#endif

	return UT_rv;

}

static int pmic_test_open(struct inode *inode, struct file *filp)
{
	return 0;
}

static ssize_t pmic_test_read(struct file *file, char *buf, size_t count,
			      loff_t * ppos)
{
	return 0;
}

static ssize_t pmic_test_write(struct file *filp, const char *buf, size_t count,
			       loff_t * ppos)
{
	return 0;
}

/*============================================================================*/
static int pmic_test_ioctl(struct inode *inode, struct file *file,
			   unsigned int cmd, unsigned long arg)
{
	switch (cmd) {
	case PMIC_POWER_TEST_CONTROL:
		return UT_pmic_power_test_control();
	case PMIC_POWER_TEST_VOLTAGE:
		return UT_pmic_power_test_voltage();
	case PMIC_POWER_TEST_CONFIG:
		return UT_pmic_power_test_config();
	case PMIC_POWER_TEST_MISC:
		return UT_pmic_power_test_misc();

	}
	return -EINVAL;
}

/*============================================================================*/
static int pmic_test_release(struct inode *inode, struct file *filp)
{
	return 0;
}

/*============================================================================*/
/*============================================================================*/

static struct file_operations pmic_test_fops = {
	.owner = THIS_MODULE,
	.open = pmic_test_open,
	.release = pmic_test_release,
	.read = pmic_test_read,
	.write = pmic_test_write,
	.ioctl = pmic_test_ioctl,
};

/*============================================================================*/
static int __init pmic_test_init(void)
{
	int res;
	printk("MC13783 Power Test: creating virtual device\n");
	res = register_chrdev(237, PMIC_POWER_DEV, &pmic_test_fops);

	if (res < 0) {
		printk(KERN_WARNING "MC13783 Power  Test: "
		       "unable to register the device\n");
		return res;
	}
	devfs_mk_cdev(MKDEV(237, 0), S_IFCHR | S_IRUGO | S_IWUGO,
		      PMIC_POWER_DEV);
	return 0;
}

/*============================================================================*/
static void __exit pmic_test_exit(void)
{
	unregister_chrdev(237, PMIC_POWER_DEV);
	devfs_remove(PMIC_POWER_DEV);
	printk("Pmic Power  Test: removing virtual device\n");
}

/*============================================================================*/

module_init(pmic_test_init);
module_exit(pmic_test_exit);

MODULE_DESCRIPTION("Test Module for MC13783 Power driver");
MODULE_LICENSE("GPL");
