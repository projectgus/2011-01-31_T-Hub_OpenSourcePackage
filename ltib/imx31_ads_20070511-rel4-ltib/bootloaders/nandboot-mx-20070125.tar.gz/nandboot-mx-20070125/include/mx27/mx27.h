#ifndef MX27_H_
#define MX27_H_
/*
 * Copyright 2004 Freescale Semiconductor, Inc. All Rights Reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/* definitions */
#ifdef __ASSEMBLER__

#define REG8_VAL(a)      (a)
#define REG16_VAL(a)     (a)
#define REG32_VAL(a)     (a)

#define REG8_PTR(a)      (a)
#define REG16_PTR(a)     (a)
#define REG32_PTR(a)     (a)

#else				/* __ASSEMBLER__ */

#define REG8_VAL(a)      ((unsigned char)(a))
#define REG16_VAL(a)     ((unsigned short)(a))
#define REG32_VAL(a)     ((unsigned int)(a))

#define REG8_PTR(a)      ((volatile unsigned char *)(a))
#define REG16_PTR(a)     ((volatile unsigned short *)(a))
#define REG32_PTR(a)     ((volatile unsigned long *)(a))

#define REG32_SET(addr, val)    (*(volatile unsigned long*) (addr) = (val))
#define REG16_SET(addr, val)    (*(volatile unsigned short*) (addr) = (val))
#define readb(a)             (*(volatile unsigned char *)(a))
#define readw(a)             (*(volatile unsigned short *)(a))
#define readl(a)             (*(volatile unsigned int *)(a))
#define writeb(v,a)          (*(volatile unsigned char *)(a) = (v))
#define writew(v,a)          (*(volatile unsigned short *)(a) = (v))
#define writel(v,a)          (*(volatile unsigned int *)(a) = (v))

#endif				/* __ASSEMBLER__ */

/*  Default Memory Layout Definitions */

#define SOC_AIPI1_BASE              0x10000000
#define SOC_AIPI2_BASE              0x10020000
#define SOC_CRM_BASE                0x10027000
#define SOC_CRM_CSCR                (SOC_CRM_BASE + 0x0)
#define SOC_CRM_MPCTL0              (SOC_CRM_BASE + 0x4)
#define SOC_CRM_MPCTL1              (SOC_CRM_BASE + 0x8)
#define SOC_CRM_SPCTL0              (SOC_CRM_BASE + 0xC)
#define SOC_CRM_SPCTL1              (SOC_CRM_BASE + 0x10)
#define SOC_CRM_OSC26MCTL           (SOC_CRM_BASE + 0x14)
#define SOC_CRM_PCDR0               (SOC_CRM_BASE + 0x18)
#define SOC_CRM_PCDR1               (SOC_CRM_BASE + 0x1C)
#define SOC_CRM_PCCR0               (SOC_CRM_BASE + 0x20)
#define SOC_CRM_PCCR1               (SOC_CRM_BASE + 0x24)
#define SOC_CRM_CCSR                (SOC_CRM_BASE + 0x28)
#define SOC_CRM_PMCTL               (SOC_CRM_BASE + 0x2C)
#define SOC_CRM_PMCOUNT             (SOC_CRM_BASE + 0x30)
#define SOC_CRM_WKGDCTL             (SOC_CRM_BASE + 0x34)

#define CRM_CSCR_IPDIV_OFFSET       8
#define CRM_CSCR_BCLKDIV_OFFSET     9
#define CRM_CSCR_PRESC_OFFSET       13
#define CRM_CSCR_SSI1_SEL_OFFSET    22
#define CRM_CSCR_SSI2_SEL_OFFSET    23
#define CRM_CSCR_USB_DIV_OFFSET     28

#define UART_FIFO_CTRL  	    0xA01
#define FREQ_26MHZ                  26000000
#define FREQ_32768HZ                (32768 * 512 * 2)
#define FREQ_32000HZ                (32000 * 512 * 2)

#define CLOCK_266_133_66
#define PLL_REF_CLK                 FREQ_26MHZ

/*                                             PD             MFD           MFI        MFN */
#define CRM_PLL_PCTL_PARAM(pd, fd, fi, fn)  (((pd-1)<<26) + ((fd-1)<<16) + (fi<<10) + (fn<<0))

#if (PLL_REF_CLK == FREQ_26MHZ)
    #define PLL_REF_CLK_26MHZ

    /* SPCTL0  for 240 MHz */
    #define CRM_SPCTL0_VAL          CRM_PLL_PCTL_PARAM(2, 13, 9, 3)

    #if defined (CLOCK_266_133_66)
        #define CRM_MPCTL0_VAL      CRM_PLL_PCTL_PARAM(1, 26, 5, 3)
        #define CRM_CSCR_VAL                0x33F30307
    #elif defined (CLOCK_399_133_66)
        #define CRM_MPCTL0_VAL      CRM_PLL_PCTL_PARAM(1, 52, 7, 35)
        #define CRM_CSCR_VAL                0x33F30507
    #elif defined (CLOCK_399_100_50)
        #define CRM_MPCTL0_VAL      CRM_PLL_PCTL_PARAM(1, 52, 7, 35)
        #define CRM_CSCR_VAL                0x33F30307
    #else
        #error This clock is not supported !!!!
    #endif   /* CLOCK_266_133_66 */

#elif (PLL_REF_CLK == FREQ_32768HZ)
    #define PLL_REF_CLK_32768HZ

    /* SPCTL0  for 240 MHz */
    #define CRM_SPCTL0_VAL          CRM_PLL_PCTL_PARAM(2, 124, 7, 19)

    #if defined (CLOCK_266_133_66)
        #define CRM_MPCTL0_VAL      CRM_PLL_PCTL_PARAM(2, 400, 7, 371)
        #define CRM_CSCR_VAL                0x33F00307
    #elif defined (CLOCK_399_133_66)
        #define CRM_MPCTL0_VAL      CRM_PLL_PCTL_PARAM(2, 100, 11, 89)
        #define CRM_CSCR_VAL                0x33F00507
    #elif defined (CLOCK_399_100_50)
        #define CRM_MPCTL0_VAL      CRM_PLL_PCTL_PARAM(2, 100, 11, 89)
        #define CRM_CSCR_VAL                0x33F00307
    #else
        #error That clock is not supported !!!!
    #endif  /* CLOCK_266_133_66 */
#else
    #error Not supported PLL_REF_CLK !!!!
#endif   /* PLL_REF_CLK == FREQ_26MHZ */

/* system control registers */
#define SOC_SYSCTRL_BASE            0x10027800
#define SOC_SYSCTRL_CID             (SOC_SYSCTRL_BASE + 0x00)
#define SOC_SYSCTRL_FMCR            (SOC_SYSCTRL_BASE + 0x14)
#define SOC_SYSCTRL_GPCR            (SOC_SYSCTRL_BASE + 0x18)
#define SOC_SYSCTRL_WBCR            (SOC_SYSCTRL_BASE + 0x1C)
#define SOC_SYSCTRL_DSCR1           (SOC_SYSCTRL_BASE + 0x20)
#define SOC_SYSCTRL_DSCR2           (SOC_SYSCTRL_BASE + 0x24)
#define SOC_SYSCTRL_DSCR3           (SOC_SYSCTRL_BASE + 0x28)
#define SOC_SYSCTRL_DSCR4           (SOC_SYSCTRL_BASE + 0x2C)
#define SOC_SYSCTRL_DSCR5           (SOC_SYSCTRL_BASE + 0x30)
#define SOC_SYSCTRL_DSCR6           (SOC_SYSCTRL_BASE + 0x34)
#define SOC_SYSCTRL_DSCR7           (SOC_SYSCTRL_BASE + 0x38)
#define SOC_SYSCTRL_DSCR8           (SOC_SYSCTRL_BASE + 0x3C)
#define SOC_SYSCTRL_DSCR9           (SOC_SYSCTRL_BASE + 0x40)
#define SOC_SYSCTRL_DSCR10          (SOC_SYSCTRL_BASE + 0x44)
#define SOC_SYSCTRL_DSCR11          (SOC_SYSCTRL_BASE + 0x48)
#define SOC_SYSCTRL_DSCR12          (SOC_SYSCTRL_BASE + 0x4C)
#define SOC_SYSCTRL_DSCR13          (SOC_SYSCTRL_BASE + 0x50)
#define SOC_SYSCTRL_PSCR            (SOC_SYSCTRL_BASE + 0x54)
#define SOC_SYSCTRL_PCSR            (SOC_SYSCTRL_BASE + 0x58)
#define SOC_SYSCTRL_PMCR            (SOC_SYSCTRL_BASE + 0x60)
#define SOC_SYSCTRL_DCVR0           (SOC_SYSCTRL_BASE + 0x64)
#define SOC_SYSCTRL_DCVR1           (SOC_SYSCTRL_BASE + 0x68)
#define SOC_SYSCTRL_DCVR2           (SOC_SYSCTRL_BASE + 0x6C)
#define SOC_SYSCTRL_DCVR3           (SOC_SYSCTRL_BASE + 0x70)

/* Interrupt Controller Register Definitions. */
#define SOC_AITC_BASE               0x10040000
#define SOC_AITC_INTCNTL            (SOC_AITC_BASE + 0x00)
#define SOC_AITC_NIMASK             (SOC_AITC_BASE + 0x04)
#define SOC_AITC_INTENNUM           (SOC_AITC_BASE + 0x08)
#define SOC_AITC_INTDISNUM          (SOC_AITC_BASE + 0x0C)
#define SOC_AITC_INTENABLEH         (SOC_AITC_BASE + 0x10)
#define SOC_AITC_INTENABLEL         (SOC_AITC_BASE + 0x14)
#define SOC_AITC_INTTYPEH           (SOC_AITC_BASE + 0x18)
#define SOC_AITC_INTTYPEL           (SOC_AITC_BASE + 0x1C)
#define SOC_AITC_NIPRIORITY7        (SOC_AITC_BASE + 0x20)
#define SOC_AITC_NIPRIORITY6        (SOC_AITC_BASE + 0x24)
#define SOC_AITC_NIPRIORITY5        (SOC_AITC_BASE + 0x28)
#define SOC_AITC_NIPRIORITY4        (SOC_AITC_BASE + 0x2C)
#define SOC_AITC_NIPRIORITY3        (SOC_AITC_BASE + 0x30)
#define SOC_AITC_NIPRIORITY2        (SOC_AITC_BASE + 0x34)
#define SOC_AITC_NIPRIORITY1        (SOC_AITC_BASE + 0x38)
#define SOC_AITC_NIPRIORITY0        (SOC_AITC_BASE + 0x3C)

#define UART_WIDTH_32

/* UART Base Addresses */
#define SOC_UART1_BASE              0x1000A000
#define SOC_UART2_BASE              0x1000B000
#define SOC_UART3_BASE              0x1000C000
#define SOC_UART4_BASE              0x1000D000
#define SOC_UART5_BASE              0x1001B000
#define SOC_UART6_BASE              0x1001C000
#define SOC_MAX_BASE                0x1003F000

/* Slave port base offset */
#define MAX_SLAVE_PORT0_OFFSET      0x0
#define MAX_SLAVE_PORT1_OFFSET      0x100
#define MAX_SLAVE_PORT2_OFFSET      0x200

/* Register offset for slave port */
#define MAX_SLAVE_MPR_OFFSET        0x0		/* Master Priority register */
#define MAX_SLAVE_AMPR_OFFSET       0x4		/* Alternate Master Priority register */
#define MAX_SLAVE_SGPCR_OFFSET      0x10	/* Slave General Purpose Control register */
#define MAX_SLAVE_ASGPCR_OFFSET     0x14	/* Alternate Slave General Purpose control register */

/* Master port base offset */
#define MAX_MASTER_PORT0_OFFSET     0x800
#define MAX_MASTER_PORT1_OFFSET     0x900
#define MAX_MASTER_PORT2_OFFSET     0xA00
#define MAX_MASTER_PORT3_OFFSET     0xB00
#define MAX_MASTER_PORT4_OFFSET     0xC00
#define MAX_MASTER_PORT5_OFFSET     0xD00

/* Register offset for master port */
#define MAX_MASTER_MGPCR_OFFSET     0x0	/* Master General Purpose Control Register */
/*
 * MX27 GPIO Register Definitions
 */
#define SOC_GPIOA_BASE              0x10015000
#define SOC_GPIOB_BASE              0x10015100
#define SOC_GPIOC_BASE              0x10015200
#define SOC_GPIOD_BASE              0x10015300
#define SOC_GPIOE_BASE              0x10015400
#define SOC_GPIOF_BASE              0x10015500
#define SOC_GPIO_PMASK              0x10015600
#define GPIO_DDIR                   0x0		/* Data direction reg */
#define GPIO_OCR1                   0x4		/* Output config reg 1 */
#define GPIO_OCR2                   0x8		/* Output config reg 2 */
#define GPIO_ICONFA1                0xC		/* Input config reg A1 */
#define GPIO_ICONFA2                0x10	/* Input config reg A2 */
#define GPIO_ICONFB1                0x14	/* Input config reg B1 */
#define GPIO_ICONFB2                0x18	/* Input config reg B2 */
#define GPIO_DR                     0x1C	/* Data reg */
#define GPIO_GIUS_OFFSET            0x20	/* GPIO in use reg */
#define GPIO_SSR                    0x24	/* Sample startus reg */
#define GPIO_ICR1                   0x28	/* Int config reg 1 */
#define GPIO_ICR2                   0x2C	/* Int config reg 2 */
#define GPIO_IMR                    0x30	/* Int mask reg */
#define GPIO_ISR                    0x34	/* Int status reg */
#define GPIO_GPR                    0x38	/* Gen purpose reg */
#define GPIO_SWR                    0x3C	/* Software reset reg */
#define GPIO_PUEN                   0x40	/* Pull-up enable reg */

#define GPIO_OCR_A                  0	/* External input a_IN */
#define GPIO_OCR_B                  1	/* External input b_IN */
#define GPIO_OCR_C                  2	/* External input c_IN */
#define GPIO_OCR_DR                 3	/* Data register */
#define GPIO_ICONF_In               0	/* GPIO-in */
#define GPIO_ICONF_Isr              1	/* Interrupt status register */
#define GPIO_ICONF_0                2	/* 0 */
#define GPIO_ICONF_1                3	/* 1 */
#define GPIO_ICR_PosEdge            0	/* Positive edge */
#define GPIO_ICR_NegEdge            1	/* Negative edge */
#define GPIO_ICR_PosLvl             2	/* Positive level */
#define GPIO_ICR_NegLvl             3	/* Negative level */
#define GPIO_SWR_SWR                1	/* Software reset */

/*
 * GPT Timer defines
 */
#define HAL_DELAY_TIMER             SOC_GPT2_BASE	/* use timer2 for hal_delay_us() */

#define SOC_GPT1_BASE               0x10003000
#define SOC_GPT2_BASE               0x10004000
#define SOC_GPT3_BASE               0x10005000
#define SOC_GPT4_BASE               0x10019000
#define SOC_GPT5_BASE               0x1001A000
#define SOC_GPT6_BASE               0x1001F000
#define GPT_TCTL_OFFSET             0x0
#define GPT_TPRER_OFFSET            0x4
#define GPT_TCMP_OFFSET             0x8
#define GPT_TCR_OFFSET              0xC
#define GPT_TCN_OFFSET              0x10
#define GPT_TSTAT_OFFSET            0x14
#define MX_STARTUP_DELAY            (1000000 / 10)	/* 0.1s delay to get around the ethernet reset failure problem */

#define TIMER_PRESCALER             3
#define SOC_SI_ID_REG               0x1002780C
#define SOC_SILICONID_Rev2_x        0x001D101D
#define SOC_SILICONID_Rev3_0        0x101D101D
#define SOC_SILICONID_Rev3_1        0x201D101D
#define CHIP_REV_1_x                1
#define CHIP_REV_2_x                2
#define CHIP_REV_3_0                3
#define CHIP_REV_3_1                4
#define CHIP_REV_unknown            0x100

#define SOC_WDOG_BASE               0x10002000

#define NFC_BASE                    0xD8000000
#define SOC_ESDCTL_BASE             0xD8001000
#define SOC_EIM_BASE                0xD8002000
#define SOC_M3IF_BASE               0xD8003000
#define SOC_PCMCIA_BASE             0xD8004000

#define SOC_CS0_CTL_BASE            SOC_EIM_BASE
#define SOC_CS1_CTL_BASE            (SOC_EIM_BASE + 0x10)
#define SOC_CS2_CTL_BASE            (SOC_EIM_BASE + 0x20)
#define SOC_CS3_CTL_BASE            (SOC_EIM_BASE + 0x30)
#define SOC_CS4_CTL_BASE            (SOC_EIM_BASE + 0x40)
#define SOC_CS5_CTL_BASE            (SOC_EIM_BASE + 0x50)

/* WEIM  */
#define CSCRU_OFFSET                0x00
#define CSCRL_OFFSET                0x04
#define CSCRA_OFFSET                0x08
#define CSWCR_OFFSET                0x60

/* Memories */
#define SOC_CSD0_BASE               0xA0000000
#define SOC_CSD1_BASE               0xB0000000
#define SOC_CS0_BASE                0xC0000000
#define CS0_BASE_ADDR               SOC_CS0_BASE
#define SOC_CS1_BASE                0xC8000000
#define SOC_CS2_BASE                0xD0000000
#define SOC_CS3_BASE                0xD2000000
#define SOC_CS4_BASE                0xD4000000
#define SOC_CS5_BASE                0xD6000000
#define NAND_REG_BASE               (NFC_BASE + 0xE00)

#define NFC_BUFSIZE_REG_OFF             (0 + 0x00)
#define RAM_BUFFER_ADDRESS_REG_OFF      (0 + 0x04)
#define NAND_FLASH_ADD_REG_OFF          (0 + 0x06)
#define NAND_FLASH_CMD_REG_OFF          (0 + 0x08)
#define NFC_CONFIGURATION_REG_OFF       (0 + 0x0A)
#define ECC_STATUS_RESULT_REG_OFF       (0 + 0x0C)
#define ECC_RSLT_MAIN_AREA_REG_OFF      (0 + 0x0E)
#define ECC_RSLT_SPARE_AREA_REG_OFF     (0 + 0x10)
#define NF_WR_PROT_REG_OFF              (0 + 0x12)
#define UNLOCK_START_BLK_ADD_REG_OFF    (0 + 0x14)
#define UNLOCK_END_BLK_ADD_REG_OFF      (0 + 0x16)
#define NAND_FLASH_WR_PR_ST_REG_OFF     (0 + 0x18)
#define NAND_FLASH_CONFIG1_REG_OFF      (0 + 0x1A)
#define NAND_FLASH_CONFIG2_REG_OFF      (0 + 0x1C)
#define RAM_BUFFER_ADDRESS_RBA_3        0x3
#define NFC_BUFSIZE_1KB                 0x0
#define NFC_BUFSIZE_2KB                 0x1
#define NFC_CONFIGURATION_UNLOCKED      0x2
#define ECC_STATUS_RESULT_NO_ERR        0x0
#define ECC_STATUS_RESULT_1BIT_ERR      0x1
#define ECC_STATUS_RESULT_2BIT_ERR      0x2
#define NF_WR_PROT_UNLOCK               0x4
#define NAND_FLASH_CONFIG1_FORCE_CE     (1 << 7)
#define NAND_FLASH_CONFIG1_RST          (1 << 6)
#define NAND_FLASH_CONFIG1_BIG          (1 << 5)
#define NAND_FLASH_CONFIG1_INT_MSK      (1 << 4)
#define NAND_FLASH_CONFIG1_ECC_EN       (1 << 3)
#define NAND_FLASH_CONFIG1_SP_EN        (1 << 2)
#define NAND_FLASH_CONFIG2_INT_DONE     (1 << 15)
#define NAND_FLASH_CONFIG2_FDO_PAGE     (0 << 3)
#define NAND_FLASH_CONFIG2_FDO_ID       (2 << 3)
#define NAND_FLASH_CONFIG2_FDO_STATUS   (4 << 3)
#define NAND_FLASH_CONFIG2_FDI_EN       (1 << 2)
#define NAND_FLASH_CONFIG2_FADD_EN      (1 << 1)
#define NAND_FLASH_CONFIG2_FCMD_EN      (1 << 0)
#define FDO_PAGE_SPARE_VAL              0x8

#define MXC_NAND_BASE_DUMMY         0xE0000000
#define NOR_FLASH_BOOT              0
#define NAND_FLASH_BOOT             0x10
#define SDRAM_NON_FLASH_BOOT        0x20
#define MXCBOOT_FLAG_REG            SOC_AITC_NIPRIORITY7
#define SPL_DEST_ADDR 		    (U16 *)0xA1000000	/* RAM address where SPL code will be copied */
#define MXCFIS_NOTHING              0x00000000
#define MXCFIS_NAND                 0x10000000
#define MXCFIS_NOR                  0x20000000
#define MXCFIS_FLAG_REG             SOC_AITC_NIPRIORITY6

#define IS_BOOTING_FROM_NAND()      (readl(MXCBOOT_FLAG_REG) == NAND_FLASH_BOOT)
#define IS_BOOTING_FROM_NOR()       (readl(MXCBOOT_FLAG_REG) == NOR_FLASH_BOOT)
#define IS_BOOTING_FROM_SDRAM()     (readl(MXCBOOT_FLAG_REG) == SDRAM_NON_FLASH_BOOT)

#define SERIAL_DOWNLOAD_MAGIC       0x000000AA
#define SERIAL_DOWNLOAD_MAGIC_REG   SOC_AITC_NIPRIORITY3
#define SERIAL_DOWNLOAD_SRC_REG     SOC_AITC_NIPRIORITY2
#define SERIAL_DOWNLOAD_TGT_REG     SOC_AITC_NIPRIORITY1
#define SERIAL_DOWNLOAD_SZ_REG      SOC_AITC_NIPRIORITY0

#define     WDOG1_BASE_ADDR          0x10002000
#define     TIMEOUT                    0x4000

#if !defined(__ASSEMBLER__)	/* ADDED FOR COMPILATION */

#define MX2ADS_EMI_IOBASE           0xD8000000
/*
 * GPIO
 * $1001_5000 to $1001_5FFF
 */

#define GPIOA	0
#define GPIOB	1
#define GPIOC	2
#define GPIOD	3
#define GPIOE	4
#define GPIOF	5

/* Use as GPIO_BASE_ADDR(GPIOA)- GPIO_BASE_ADDR(GPIOF)*/
#define GPIO_BASE_ADDR(x)    (0x10015000+x*0x100)
#define _reg_GPIO_GIUS(x)    (*((volatile unsigned long *)(GPIO_BASE_ADDR(x)+0x20))) /*  32bit gpio pta in use reg */
#define _reg_GPIO_GPR(x)     (*((volatile unsigned long *)(GPIO_BASE_ADDR(x)+0x38))) /*  32bit gpio pta general purpose reg*/

#define CRM_BASE_ADDR	0x10027000
#define _reg_CRM_CSCR	(*((volatile unsigned long *)(CRM_BASE_ADDR+0x00)))	/*  32bit Clock Source Control Reg */
#define _reg_CRM_MPCTL0	(*((volatile unsigned long *)(CRM_BASE_ADDR+0x04)))	/*  32bit MCU PLL Control Reg      */
#define _reg_CRM_PCDR0	(*((volatile unsigned long *)(CRM_BASE_ADDR+0x18)))	/*  32bit Serial Perpheral Clk Div Reg */
#define _reg_CRM_PCDR1	(*((volatile unsigned long *)(CRM_BASE_ADDR+0x1C)))
#define _reg_CRM_PCCR1	(*((volatile unsigned long *)(CRM_BASE_ADDR+0x24)))

#define SYS_BASE_ADDR	0x10027800
#define _reg_SYS_FMCR	(*((volatile unsigned long *)(SYS_BASE_ADDR+0x14)))	/*  Functional Muxing Control Reg */
#define _reg_SYS_PCSR	(*((volatile unsigned long *)(SYS_BASE_ADDR+0x50)))	/*  Priority Control/select Reg   */
#define _reg_SYS_GPCR	(*((volatile unsigned long *)(SYS_BASE_ADDR+0x18)))	/*  Global Peripheral Control Reg */ 
#define _reg_WEIM_CSU(x)	(*((volatile unsigned long *)(MX2ADS_EMI_IOBASE+0x2000+8*x))) /* 32bit eim chip sel 0 upper ctr reg */
#define _reg_WEIM_CSL(x)	(*((volatile unsigned long *)(MX2ADS_EMI_IOBASE+0x2000+0x04+8*x)))/*32biteimchip sel 0 lower ctr reg*/
#define AIPI1_BASE_ADDR		0x10000000
#define _reg_AIPI1_PSR0		(*((volatile unsigned long *)(AIPI1_BASE_ADDR+0x00)))	/*  32bit Peripheral Size Reg 0 */
#define _reg_AIPI1_PSR1		(*((volatile unsigned long *)(AIPI1_BASE_ADDR+0x04)))	/*  32bit Peripheral Size Reg 1 */

/*             
 * AIPI2
 * $1002_0000 to $1002_0FFF
 */             
#define AIPI2_BASE_ADDR	0x10020000
#define _reg_AIPI2_PSR0	(*((volatile unsigned long *)(AIPI2_BASE_ADDR+0x00)))	/*  32bit Peripheral Size Reg 0 */
#define _reg_AIPI2_PSR1	(*((volatile unsigned long *)(AIPI2_BASE_ADDR+0x04)))	/*  32bit Peripheral Size Reg 1 */

#define MAX_BASE_ADDR	0x1003F000

#define _reg_MAX_SLV_MPR(x) (*((volatile unsigned long *)(MAX_BASE_ADDR+0x100*x+0x00)))	/*32bit max slv master priority reg */
#define _reg_MAX_SLV_AMPR(x) (*((volatile unsigned long *)(MAX_BASE_ADDR+0x100*x+0x04)))	

/*!
 * NFMS bit in FMCR register for pagesize of nandflash
 */
#define NFMS (*((volatile U32 *)(SYS_BASE_ADDR+0x14)))

#define NFMS_BIT 5

#define NAND_BUSWIDTH NAND_WIDTH_8
#endif				/* !defined(__ASSEMBLER__) */

#endif				/* MX27_H_ */
