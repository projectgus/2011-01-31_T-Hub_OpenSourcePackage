/*
 * Copyright 2005-2006 Freescale Semiconductor, Inc. All rights reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <limits.h>
#include "mxc_test.h"
#include <linux/config.h>

#include <asm-arm/arch-mxc/mxc_pm.h>

#ifdef CONFIG_MACH_MX31ADS
int op_points[] = { 532, 532, 266, 133, 0 };
#elif defined(CONFIG_MACH_MX27ADS)
int op_points[] = {266, 266, 133, 133, 0 };
#else
int op_points[] = { 532, 399, 266, 133, 0 };
#endif

int main(int argc, char **argv)
{
        mxc_pm_test pm_test;
        int fp, option;

       	int op_pt_ctr, random_op_pt, seed;
        int point3, point2, point1, point0, new_op_point;
        int pctr0, pctr1, pctr2, pctr3, i;

        printf("========== TESTING Low-level PM DRIVER ==========\n");
        printf("Note that some option #'s may be skipped depending on platform.\n");
        printf("So, enter the option number corresponding to each option correctly\n");
        printf("Enter any of the following options: \n");
        printf("1. Test Integer Scaling \n");
        printf("2. Test PLL Scaling \n");
        printf("3. Test Int/PLL Scaling (choice decided by PM driver) \n");
        printf("4. Test Low Power Modes \n");
        printf("5. Select CKOH output \n");
#if defined(CONFIG_MACH_MX27ADS)
        printf("6. Configure PMIC for High Voltage (Regs at 1.6V) \n");
        printf("7. Configure PMIC for Low Voltage (Regs at 1.2V) \n");
        printf("8. Configure PMIC for High & Low Voltage (Regs at 1.2 & 1.6V) \n");
#endif
#if defined(CONFIG_MACH_MX31ADS) || defined(CONFIG_MACH_MX27ADS)
        printf("9. Infinite loop cycling through operating points. \n");
#endif

        scanf("%d", &option);
        fp = open("/dev/mxc_test", O_RDWR);
        if (fp < 0) {
                printf("Test module: Open failed with error %d\n", fp);
                perror("Open");
                return -1;
        }

        switch(option) {
        case 1:
#if defined(CONFIG_MACH_MX27ADS)
                printf("Use option 3 to test DVFS\n");
#else
                printf("Enter a valid ARM frequency: \n");
                scanf("%d", &pm_test.armfreq);
                /*
                 * If someone enters just the MHz value, conver to Hz and
                 * assume they want ahb and ipg to be 133, 66.5 MHz.
                 */
                if ( pm_test.armfreq < 1000000 ) {
                        pm_test.armfreq *= 1000000;
#if defined(CONFIG_MACH_MX31ADS)
                        pm_test.ahbfreq = 133000000;
                        pm_test.ipfreq =  66500000;
#endif
                } else {
                        printf("Enter a valid AHB frequency: \n");
                        scanf("%d", &pm_test.ahbfreq);
                        printf("Enter a valid IPG frequency: \n");
                        scanf("%d", &pm_test.ipfreq);
                }
                if (pm_test.armfreq < 0 || pm_test.ahbfreq > 133000000 || pm_test.ipfreq > 66500000) {
                        printf("Please enter a valid frequency value \n");
                        printf("AHB and IP values must be less than maximum, 133MHz and 66.5MHz\n");
                        return -1;
                }
                printf("You have requested %d Hz ARM Core frequency\n", pm_test.armfreq);
                ioctl(fp, MXCTEST_PM_INTSCALE, &pm_test);
#endif
                break;

        case 2:
#if defined(CONFIG_MACH_MX27ADS)
                printf("Use option 3 to test DVFS\n");
#else
                printf("Enter a valid ARM frequency: \n");
                scanf("%d", &pm_test.armfreq);
                /*
                 * If someone enters just the MHz value, conver to Hz and
                 * assume they want ahb and ipg to be 133, 66.5 MHz.
                 */
                if ( pm_test.armfreq < 1000000 ) {
                        pm_test.armfreq *= 1000000;
#if defined(CONFIG_MACH_MX31ADS)
                        pm_test.ahbfreq = 133000000;
                        pm_test.ipfreq =  66500000;
#endif
                } else {
                        printf("Enter a valid AHB frequency: \n");
                        scanf("%d", &pm_test.ahbfreq);
                        printf("Enter a valid IPG frequency: \n");
                        scanf("%d", &pm_test.ipfreq);
                }
                if (pm_test.armfreq < 0 || pm_test.ahbfreq > 133000000 || pm_test.ipfreq > 66500000) {
                        printf("Please enter a valid frequency value \n");
                        printf("AHB and IP values must be less than maximum, 133MHz and 66.5MHz\n");
                        return -1;
                }
                printf("You have requested %d Hz ARM Core frequency\n", pm_test.armfreq);
                ioctl(fp, MXCTEST_PM_PLLSCALE, &pm_test);
#endif
                break;

        case 3:
                printf("Enter a valid ARM frequency: \n");
                scanf("%d", &pm_test.armfreq);
                /*
                 * If someone enters just the MHz value, conver to Hz and
                 * assume they want ahb and ipg to be 133, 66.5 MHz.
                 */
                if ( pm_test.armfreq < 1000000 ) {
                        pm_test.armfreq *= 1000000;
#if defined(CONFIG_MACH_MX31ADS) || defined(CONFIG_MACH_MX27ADS)
                        pm_test.ahbfreq = 133000000;
                        pm_test.ipfreq =  66500000;
#endif                                                                  
                } else {
                        printf("Enter a valid AHB frequency: \n");
                        scanf("%d", &pm_test.ahbfreq);
                        printf("Enter a valid IPG frequency: \n");
                        scanf("%d", &pm_test.ipfreq);
                }
                if (pm_test.armfreq < 0 || pm_test.ahbfreq > 133000000 || pm_test.ipfreq > 66500000) {
                        printf("Please enter a valid frequency value \n");
                        printf("AHB and IP values must be less than maximum, 133MHz and 66.5MHz\n");
                        return -1;
                }
                printf("You have requested %d Hz ARM Core frequency\n", pm_test.armfreq);
                ioctl(fp, MXCTEST_PM_INT_OR_PLL, &pm_test);
                break;


#if defined(CONFIG_MACH_MX31ADS) || defined(CONFIG_MACH_MX27ADS)
        case 4:
                printf("1. WAIT mode \n");
                printf("2. DOZE mode \n");
                printf("3. STOP mode \n");
                printf("4. DSM mode \n");
                printf("Enter a valid choice: \n");
                scanf("%d", &pm_test.lpmd);
                printf("Testing low-power modes\n");
                ioctl(fp, MXCTEST_PM_LOWPOWER, &pm_test);
                break;
#endif

#if defined(CONFIG_MACH_MX31ADS)
        case 5:
                printf("Enter CKOH choice:\n");
                printf(" 0 mpl_dpdgck_clk Clock\n");
                printf(" 1 IPG Clock\n");
                printf(" 2 upl_dpdgck_clk Clock\n");
                printf(" 3 PLL REF Clock\n");
                printf(" 4 fpm_ckil512_clk Clock\n");
                printf(" 5 AHB Clock\n");
                printf(" 6 ARM Clock divided by 8\n");
                printf(" 7 spl_dpdgck_clkg Clock\n");
                printf(" 8 CKIHI Clock\n");
                printf(" 9 ipg_clk_ahb_emi_clkb Clock\n");
                printf("10 ipg_clk_ipu_hsp Clock\n");
                printf("11 NFC Clock\n");
                printf("12 PERCLK Clock\n");
                printf("Enter clock number: ");
                scanf("%d", &pm_test.ckoh);
                if (pm_test.ckoh > 12 || pm_test.ckoh < 0) {
                        printf("Invalid choice\n");
                } else {
                        printf("Setting CLKO output to clock %d.\n", pm_test.ckoh);
                        usleep(100000);
                        ioctl(fp, MXCTEST_PM_CKOH_SEL, &pm_test);
                }
                break;
#else
        case 5:
                printf("Enter CKOH choice (1,2,3): \n");
                printf("1. ARM Clock \n");
                printf("2. AHB Clock \n");
                printf("3. IP Clock \n");
                scanf("%d", &pm_test.ckoh);
                switch( pm_test.ckoh ) {
                case 1:
                        printf("Setting CK_OK output to AP ARM clock divided by 10.\n");
                        pm_test.ckoh = CKOH_AP_SEL;
                        ioctl(fp, MXCTEST_PM_CKOH_SEL, &pm_test);
                        break;

                case 2:
                        printf("Setting CK_OK output to AP AHB clock divided by 10.\n");
                        pm_test.ckoh = CKOH_AHB_SEL;
                        ioctl(fp, MXCTEST_PM_CKOH_SEL, &pm_test);
                        break;

                case 3:
                        printf("Setting CK_OK output to AP IP clock.\n");
                        pm_test.ckoh = CKOH_IP_SEL;
                        ioctl(fp, MXCTEST_PM_CKOH_SEL, &pm_test);
                        break;

                default:
                        printf("Invalid choice\n");
                        break;
                }

                break;
#endif

#if defined(CONFIG_MACH_MX27ADS)
        case 6:
                ioctl(fp, MXCTEST_PM_PMIC_HIGH, &pm_test);
                break;
        case 7:
                ioctl(fp, MXCTEST_PM_PMIC_LOW, &pm_test);
                break;
        case 8:
                ioctl(fp, MXCTEST_PM_PMIC_HILO, &pm_test);
                break;
#endif

#if defined(CONFIG_MACH_MX31ADS) || defined(CONFIG_MACH_MX27ADS)
        case 9:
                printf("Enter a random seed: \n");
                scanf("%d", &seed);

                srand(seed);

                /*
                 * Determine how many operating points we have:
                 * Assuming it is 4 or less
                 */
                for ( op_pt_ctr = 0 ;
                      (op_pt_ctr < 4) && (op_points[op_pt_ctr]!=0) ;
                      op_pt_ctr++ );

                /* current op point */
                pm_test.armfreq = 399000000;
                pm_test.ahbfreq = 133000000;
                pm_test.ipfreq  =  66500000;

                /* History of last 4 op points */
                point3 = point2 = point1 = 0;
                point0 = pm_test.armfreq;

                pctr0 = pctr1 = pctr2 = pctr3 = 0;
                while (1) {
                        /*
                         * get a random number from rand().  It's funny how
                         * some bits are more random than others.
                         */
                        random_op_pt = (rand()>>6) & 0x3;

                        /* toss away random points that are >= op_pt_ctr */
                        if (random_op_pt >= op_pt_ctr) {
                                continue;
                        }

                        new_op_point = (op_points[random_op_pt] * 1000000);

                        pm_test.armfreq = new_op_point;

                        point3 = point2;
                        point2 = point1;
                        point1 = point0;
                        point0 = pm_test.armfreq;

                        // if( pm_test.armfreq == 133000000 ) pctr0++;
                        // if( pm_test.armfreq == 266000000 ) pctr1++;
                        // if( pm_test.armfreq == 399000000 ) pctr2++;
                        // if( pm_test.armfreq == 532000000 ) pctr3++;
                        // printf("%d : %d %d %d %d\n", pm_test.armfreq,
                        //         pctr0, pctr1, pctr2, pctr3 );

                        // printf("Requesting %d Hz\n", pm_test.armfreq);
                        ioctl(fp, MXCTEST_PM_INT_OR_PLL, &pm_test);
                        printf("\n");
                        for ( i=0 ; i<1000000 ; i++ ) {};
                        printf("Sequence: %d -> %d -> %d -> %d\n",
                                point3/1000000,
                                point2/1000000,
                                point1/1000000,
                                point0/1000000 );
                        for ( i=0 ; i<1000000 ; i++ ) {};

                }
                break;
#endif

        default:
        printf("Invalid choice\n");
        }

        return 0;
}

