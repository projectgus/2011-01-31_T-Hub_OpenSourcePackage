/* sys.c */

#include "../ptpd.h"

void displayStats(PtpClock *ptpClock)
{
  static char sbuf[SCREEN_BUFSZ];
  int len = 0;
  
  memset(sbuf, ' ', SCREEN_BUFSZ);
  len += sprintf(sbuf + len, "\r");
  
  len += sprintf(sbuf + len, "state = ");
  
  switch(ptpClock->port_state)
  {
  case PTP_INITIALIZING:  len += sprintf(sbuf + len, "init");   break;
  case PTP_FAULTY:        len += sprintf(sbuf + len, "flt ");   break;
  case PTP_LISTENING:     len += sprintf(sbuf + len, "lstn");   break;
  case PTP_PASSIVE:       len += sprintf(sbuf + len, "pass");   break;
  case PTP_UNCALIBRATED:  len += sprintf(sbuf + len, "uncl");   break;
  case PTP_SLAVE:         len += sprintf(sbuf + len, "slv ");   break;
  case PTP_PRE_MASTER:    len += sprintf(sbuf + len, "pmst");   break;
  case PTP_MASTER:        len += sprintf(sbuf + len, "mst ");   break;
  case PTP_DISABLED:      len += sprintf(sbuf + len, "dsbl");   break;
  default:                len += sprintf(sbuf + len, "?   ");   break;
  }
  
  if(ptpClock->port_state == PTP_SLAVE)
  {
    len += sprintf(sbuf + len, 
      " owd = %s%lu.%09ld"
      " ofm = %s%lu.%09ld",
      ptpClock->one_way_delay.nanoseconds < 0 ? "-" : "",
      ptpClock->one_way_delay.seconds, labs(ptpClock->one_way_delay.nanoseconds),
      ptpClock->offset_from_master.nanoseconds < 0 ? "-" : "",
      ptpClock->offset_from_master.seconds, labs(ptpClock->offset_from_master.nanoseconds));
    
    len += sprintf(sbuf + len, 
      " drift = %ld"
      " var = %d",
      ptpClock->observed_drift, ptpClock->observed_variance);
  }
  
  write(1, sbuf, SCREEN_MAXSZ + 1);
}

Boolean nanoSleep(TimeRepresentation *t)
{
  struct timespec ts, tr;
  
  ts.tv_sec = t->seconds;
  ts.tv_nsec = t->nanoseconds;
  
  if(nanosleep(&ts, &tr) < 0)
  {
    t->seconds = tr.tv_sec;
    t->nanoseconds = tr.tv_nsec;
    return FALSE;
  }
  
  return TRUE;
}

void getTime(UInteger32 *seconds, Integer32 *nanoseconds)
{
  struct timeval t;
  
  gettimeofday(&t, 0);
  *seconds = t.tv_sec;
  *nanoseconds = t.tv_usec*1000;
}

void setTime(UInteger32 seconds, Integer32 nanoseconds)
{
  struct timeval t;
  
  t.tv_sec = seconds;
  t.tv_usec = nanoseconds/1000;
  settimeofday(&t, 0);
  
  NOTIFY("resetting system clock to %lus %ldns\n", seconds, nanoseconds);
}

UInteger16 getRand(UInteger32 *seed)
{
  return rand_r((unsigned int*)seed);
}

Boolean adjFreq(Integer32 adj)
{
  struct timex t;
  
  if(adj > ADJ_FREQ_MAX)
    adj = ADJ_FREQ_MAX;
  else if(adj < -ADJ_FREQ_MAX)
    adj = -ADJ_FREQ_MAX;
  
  t.modes = ADJ_FREQUENCY;
  t.freq = adj*((1<<16)/1000);
  
  return !adjtimex(&t);
}

