/* protocol.c */

#include "ptpd.h"

Boolean doInit(RunTimeOpts*,PtpClock*);
void doState(RunTimeOpts*,PtpClock*);
void toState(UInteger8,RunTimeOpts*,PtpClock*);

void handle(RunTimeOpts*,PtpClock*);
void handleSync(MsgHeader*,MsgSync*,TimeRepresentation*,RunTimeOpts*,PtpClock*);
void handleFollowUp(MsgHeader*,MsgFollowUp*,RunTimeOpts*,PtpClock*);
void handleDelayResp(MsgHeader*,MsgDelayResp*,RunTimeOpts*,PtpClock*);
void handleManagement(MsgHeader*,MsgManagement*,RunTimeOpts*,PtpClock*);

void issueSync(RunTimeOpts*,PtpClock*);
void issueDelayReq(RunTimeOpts*,PtpClock*);
void issueDelayResp(TimeRepresentation*,MsgHeader*,RunTimeOpts*,PtpClock*);
void issueManagement(MsgHeader*,MsgManagement*,RunTimeOpts*,PtpClock*);

MsgSync * addForeign(Octet*,MsgHeader*,PtpClock*);

/* loop until port_state is null, each case has the actions and events to
   be checked at that state. the actions and events may or may not
   change port_state by calling toState(), but once they are done we
   loop around again and perform the actions required at port_state. the 
   STATE_CHANGE_EVENT happens in any state except the initializing state. */
void protocol(RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  DBG("event POWERUP\n");
  
  toState(PTP_INITIALIZING, rtOpts, ptpClock);
  
  for(;;)
  {
    if(ptpClock->port_state != PTP_INITIALIZING)
      doState(rtOpts, ptpClock);
    else if(!doInit(rtOpts, ptpClock))
      return;
    
    if(ptpClock->message_activity)
    {
      DBGV("activity\n");
    }
    else
    {
      DBGV("no activity\n");
    }
  }
}

Boolean doInit(RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  DBG("manufacturerIdentity: %s\n", MANUFACTURER_ID);
  
  /* initialize networking */
  netShutdown(&ptpClock->netPath);
  if(!netInit(&ptpClock->netPath, rtOpts, ptpClock))
  {
    ERROR("failed to initialize network\n");
    toState(PTP_FAULTY, rtOpts, ptpClock);
    return FALSE;
  }
  
  /* initialize other stuff */
  initData(rtOpts, ptpClock);
  initTimer(DEFAULT_POLL_INTERVAL);
  initClock(rtOpts, ptpClock);
  M1(ptpClock);
  msgPackHeader(ptpClock->msgObuf, ptpClock);
  
  DBG("sync message interval: %d\n", PTP_SYNC_INTERVAL_TIMEOUT(ptpClock->sync_interval));
  DBG("clock identifier: %s\n", ptpClock->clock_identifier);
  DBG("256*log2(clock variance): %d\n", ptpClock->clock_variance);
  DBG("clock stratum: %d\n", ptpClock->clock_stratum);
  DBG("clock preferred?: %s\n", ptpClock->preferred?"yes":"no");
  DBG("bound interface name: %s\n", rtOpts->ifaceName);
  DBG("communication technology: %d\n", ptpClock->port_communication_technology);
  DBG("uuid: %02hhx:%02hhx:%02hhx:%02hhx:%02hhx:%02hhx\n",
    ptpClock->port_uuid_field[0], ptpClock->port_uuid_field[1], ptpClock->port_uuid_field[2],
    ptpClock->port_uuid_field[3], ptpClock->port_uuid_field[4], ptpClock->port_uuid_field[5]);
  DBG("PTP subdomain name: %s\n", ptpClock->subdomain_name);
  DBG("subdomain address: %hhx.%hhx.%hhx.%hhx\n",
    ptpClock->subdomain_address[0], ptpClock->subdomain_address[1],
    ptpClock->subdomain_address[2], ptpClock->subdomain_address[3]);
  DBG("event port address: %hhx %hhx\n",
    ptpClock->event_port_address[0], ptpClock->event_port_address[1]);
  DBG("general port address: %hhx %hhx\n",
    ptpClock->general_port_address[0], ptpClock->general_port_address[1]);
  
  toState(PTP_LISTENING, rtOpts, ptpClock);
  return TRUE;
}

/* port specific state actions */
void doState(RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  UInteger8 state;
  
  ptpClock->message_activity = FALSE;
  
  switch(ptpClock->port_state)
  {
  case PTP_LISTENING:
  case PTP_SLAVE:
  case PTP_MASTER:
    if(ptpClock->record_update)
    {
      ptpClock->record_update = FALSE;
      state = bmc(ptpClock->foreign, rtOpts, ptpClock);
      if(state != ptpClock->port_state)
        toState(state, rtOpts, ptpClock);
    }
    break;
    
  default:
    break;
  }
  
  switch(ptpClock->port_state)
  {
  case PTP_FAULTY:
    /* imaginary troubleshooting */
    
    DBG("event FAULT_CLEARED\n");
    toState(PTP_INITIALIZING, rtOpts, ptpClock);
    return;
    
  case PTP_LISTENING:
  case PTP_PASSIVE:
  case PTP_UNCALIBRATED:
  case PTP_SLAVE:
    handle(rtOpts, ptpClock);
    
    if(timerExpired(SYNC_RECEIPT_TIMER, ptpClock->itimer))
    {
      DBG("event SYNC_RECEIPT_TIMEOUT_EXPIRES\n");
      ptpClock->number_foreign_records = 0;
      ptpClock->foreign_record_i = 0;
      if(!rtOpts->slaveOnly)
      {
        M1(ptpClock);
        toState(PTP_MASTER, rtOpts, ptpClock);
      }
      else if(ptpClock->port_state != PTP_LISTENING)
        toState(PTP_LISTENING, rtOpts, ptpClock);
    }
    
    break;
    
  case PTP_MASTER:
    if(timerExpired(SYNC_INTERVAL_TIMER, ptpClock->itimer))
    {
      DBGV("event SYNC_INTERVAL_TIMEOUT_EXPIRES\n");
      issueSync(rtOpts, ptpClock);
    }
    
    handle(rtOpts, ptpClock);
    
    break;
    
  case PTP_DISABLED:
    handle(rtOpts, ptpClock);
    break;
    
  default:
    DBG("do unrecognized state\n");
    break;
  }
  
  if(rtOpts->displayStats)
    displayStats(ptpClock);
}

/* perform actions required when leaving 'port_state' and entering 'state' */
void toState(UInteger8 state, RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  ptpClock->message_activity = TRUE;
  
  /* leaving state tasks */
  switch(ptpClock->port_state)
  {
  case PTP_MASTER:
    timerStop(SYNC_INTERVAL_TIMER, ptpClock->itimer);
    timerStart(SYNC_RECEIPT_TIMER, PTP_SYNC_RECEIPT_TIMEOUT(ptpClock->sync_interval), ptpClock->itimer);
    break;
    
  case PTP_SLAVE:
    initClock(rtOpts, ptpClock);
    break;
    
  default:
    break;
  }
  
  /* entering state tasks */
  switch(state)
  {
  case PTP_INITIALIZING:
    DBG("state PTP_INITIALIZING\n");
    timerStop(SYNC_RECEIPT_TIMER, ptpClock->itimer);
    
    ptpClock->port_state = PTP_INITIALIZING;
    break;
    
  case PTP_FAULTY:
    DBG("state PTP_FAULTY\n");
    timerStop(SYNC_RECEIPT_TIMER, ptpClock->itimer);
    
    ptpClock->port_state = PTP_FAULTY;
    break;
    
  case PTP_DISABLED:
    DBG("state change to PTP_DISABLED\n");
    timerStop(SYNC_RECEIPT_TIMER, ptpClock->itimer);
    
    ptpClock->port_state = PTP_DISABLED;
    break;
    
  case PTP_LISTENING:
    DBG("state PTP_LISTENING\n");
    
    timerStart(SYNC_RECEIPT_TIMER, PTP_SYNC_RECEIPT_TIMEOUT(ptpClock->sync_interval), ptpClock->itimer);
    
    ptpClock->port_state = PTP_LISTENING;
    break;
    
  case PTP_MASTER:
    DBG("state PTP_MASTER\n");
    
    if(ptpClock->port_state != PTP_PRE_MASTER)
      timerStart(SYNC_INTERVAL_TIMER, PTP_SYNC_INTERVAL_TIMEOUT(ptpClock->sync_interval), ptpClock->itimer);
    timerStop(SYNC_RECEIPT_TIMER, ptpClock->itimer);
    
    ptpClock->port_state = PTP_MASTER;
    break;
    
  case PTP_PASSIVE:
    DBG("state PTP_PASSIVE\n");
    ptpClock->port_state = PTP_PASSIVE;
    break;
    
  case PTP_UNCALIBRATED:
    DBG("state PTP_UNCALIBRATED\n");
    ptpClock->port_state = PTP_UNCALIBRATED;
    break;
    
  case PTP_SLAVE:
    DBG("state PTP_PTP_SLAVE\n");
    
    initClock(rtOpts, ptpClock);
    
    /* R is chosen to allow a few syncs before we first get a one-way delay estimate */
    /* this is to allow the offset filter to fill for an accurate initial clock reset */
    ptpClock->Q = 0;
    ptpClock->R = getRand(&ptpClock->random_seed)%4 + 4;
    DBG("Q = %d, R = %d\n", ptpClock->Q, ptpClock->R);
    
    ptpClock->port_state = PTP_SLAVE;
    break;
    
  default:
    DBG("to unrecognized state\n");
    break;
  }
}

void handle(RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  MsgSync *sync;
  TimeRepresentation time = { 0, 0 };
  
  if(!ptpClock->message_activity)
    netSelect(DEFAULT_POLL_INTERVAL, &ptpClock->netPath);
  
  if(netRecvEvent(0, ptpClock->msgIbuf, &time, &ptpClock->netPath))
  {
    subTime(&time, &time, &rtOpts->inboundLatency);
  }
  else if(!netRecvGeneral(0, ptpClock->msgIbuf, &ptpClock->netPath))
    return;
    
  ptpClock->message_activity = TRUE;
  
  if(!msgPeek(ptpClock->msgIbuf))
    return;
  
  msgUnpackHeader(ptpClock->msgIbuf, &ptpClock->msgTmpHeader);
  
  DBGV("event Receipt of Message\n   type %d\n"
    "   uuid %02hhx:%02hhx:%02hhx:%02hhx:%02hhx:%02hhx\n"
    "   sequence %d\n   time %lus %ldns\n",
    ptpClock->msgTmpHeader.control,
    ptpClock->msgTmpHeader.sourceUuid[0], ptpClock->msgTmpHeader.sourceUuid[1], ptpClock->msgTmpHeader.sourceUuid[2],
    ptpClock->msgTmpHeader.sourceUuid[3], ptpClock->msgTmpHeader.sourceUuid[4], ptpClock->msgTmpHeader.sourceUuid[5],
    ptpClock->msgTmpHeader.sequenceId,
    time.seconds, time.nanoseconds);
  
  if(ptpClock->msgTmpHeader.sourceCommunicationTechnology == ptpClock->port_communication_technology
    && ptpClock->msgTmpHeader.sourcePortId == ptpClock->port_id_field
    && !memcmp(ptpClock->msgTmpHeader.sourceUuid, ptpClock->port_uuid_field, PTP_UUID_LENGTH)
    && ptpClock->msgTmpHeader.control != PTP_MANAGEMENT_MESSAGE)
  {
    DBGV("handleMessage: ignoring message from self\n");
    return;
  }
  
  switch(ptpClock->msgTmpHeader.control) {
  case PTP_SYNC_MESSAGE:
    /* addForeign() takes care of msgUnpackSync() */
    sync = addForeign(ptpClock->msgIbuf, &ptpClock->msgTmpHeader, ptpClock);
    ptpClock->record_update = TRUE;
    handleSync(&ptpClock->msgTmpHeader, sync, &time, rtOpts, ptpClock);
    break;
    
  case PTP_DELAY_REQ_MESSAGE:
    if(ptpClock->port_state == PTP_MASTER)
      issueDelayResp(&time, &ptpClock->msgTmpHeader, rtOpts, ptpClock);
    break;
    
  case PTP_FOLLOWUP_MESSAGE:
    msgUnpackFollowUp(ptpClock->msgIbuf, &ptpClock->msgTmp.follow);
    handleFollowUp(&ptpClock->msgTmpHeader, &ptpClock->msgTmp.follow, rtOpts, ptpClock);
    break;
    
  case PTP_DELAY_RESP_MESSAGE:
    msgUnpackDelayResp(ptpClock->msgIbuf, &ptpClock->msgTmp.resp);
    handleDelayResp(&ptpClock->msgTmpHeader, &ptpClock->msgTmp.resp, rtOpts, ptpClock);
    break;
    
  case PTP_MANAGEMENT_MESSAGE:
    msgUnpackManagement(ptpClock->msgIbuf, &ptpClock->msgTmp.manage);
    handleManagement(&ptpClock->msgTmpHeader, &ptpClock->msgTmp.manage, rtOpts, ptpClock);
    break;
    
   default:
    DBG("handleMessage: unrecognized message\n");
    break;
  }
}

void handleSync(MsgHeader *header, MsgSync *sync, TimeRepresentation *time, RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  switch(ptpClock->port_state) {
  case PTP_FAULTY:
  case PTP_INITIALIZING:
  case PTP_DISABLED:
    DBGV("handleSync: disreguard\n");
    return;
    
  case PTP_UNCALIBRATED:
  case PTP_SLAVE:
    if(getFlag(header->flags, PTP_SYNC_BURST) && !ptpClock->burst_enabled)
      return;
    
    DBGV("handleSync: looking for uuid %02hhx:%02hhx:%02hhx:%02hhx:%02hhx:%02hhx\n",
      ptpClock->parent_uuid[0], ptpClock->parent_uuid[1], ptpClock->parent_uuid[2],
      ptpClock->parent_uuid[3], ptpClock->parent_uuid[4], ptpClock->parent_uuid[5]);
    
    if(header->sourceCommunicationTechnology == ptpClock->parent_communication_technology
      && header->sourcePortId == ptpClock->parent_port_id
      && header->sequenceId > ptpClock->parent_last_sync_sequence_number
      && !memcmp(header->sourceUuid, ptpClock->parent_uuid, PTP_UUID_LENGTH))
    {
      if(sync->syncInterval != ptpClock->sync_interval)
      {
        DBGV("message's sync interval is %d, but clock's is %d\n", sync->syncInterval, ptpClock->sync_interval);
        /* spec recommends handling a sync interval discrepancy as a fault */
      }
      
      ptpClock->sync_receipt_time.seconds = time->seconds;
      ptpClock->sync_receipt_time.nanoseconds = time->nanoseconds;
      
      if(!getFlag(header->flags, PTP_ASSIST))
      {
        ptpClock->waitingForFollow = FALSE;
        
        updateOffset(&sync->originTimestamp, &ptpClock->sync_receipt_time,
          &ptpClock->ofm_filt, ptpClock);
        updateClock(rtOpts, ptpClock);
      }
      else
      {
        ptpClock->waitingForFollow = TRUE;
      }
      
      S1(header, sync, ptpClock);
      
      if(!(--ptpClock->R))
      {
        issueDelayReq(rtOpts, ptpClock);
        
        ptpClock->Q = 0;
        ptpClock->R = getRand(&ptpClock->random_seed)%(PTP_DELAY_REQ_INTERVAL - 2) + 2;
        DBG("Q = %d, R = %d\n", ptpClock->Q, ptpClock->R);
      }
    }
  default:
    DBGV("SYNC_RECEIPT_TIMER reset\n");
    timerStart(SYNC_RECEIPT_TIMER, PTP_SYNC_RECEIPT_TIMEOUT(ptpClock->sync_interval), ptpClock->itimer);
    break;
  }
}

void handleFollowUp(MsgHeader *header, MsgFollowUp *follow, RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  switch(ptpClock->port_state) {
  case PTP_FAULTY:
  case PTP_INITIALIZING:
  case PTP_DISABLED:
  default:
    DBGV("handleFollowUp: disreguard\n");
    return;
    
  case PTP_SLAVE:
    if(getFlag(header->flags, PTP_SYNC_BURST) && !ptpClock->burst_enabled)
      return;
    
    DBGV("handleFollowUp: looking for uuid %02hhx:%02hhx:%02hhx:%02hhx:%02hhx:%02hhx\n",
      ptpClock->parent_uuid[0], ptpClock->parent_uuid[1], ptpClock->parent_uuid[2],
      ptpClock->parent_uuid[3], ptpClock->parent_uuid[4], ptpClock->parent_uuid[5]);
    
    if(header->sourceCommunicationTechnology == ptpClock->parent_communication_technology
       /*&& header->sourcePortId == ptpClock->parent_port_id*/
	&& follow->associatedSequenceId == ptpClock->parent_last_sync_sequence_number
	&& !memcmp(header->sourceUuid, ptpClock->parent_uuid, PTP_UUID_LENGTH)
       && ptpClock->waitingForFollow)
    {
      ptpClock->waitingForFollow = FALSE;
      
      updateOffset(&follow->preciseOriginTimestamp, &ptpClock->sync_receipt_time,
        &ptpClock->ofm_filt, ptpClock);
      updateClock(rtOpts, ptpClock);
    }
    else
    {
      DBG("handleFollowUp: unwanted\n");
    }
    break;
  }
}

void handleDelayResp(MsgHeader *header, MsgDelayResp *resp, RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  switch(ptpClock->port_state) {
  case PTP_FAULTY:
  case PTP_INITIALIZING:
  case PTP_DISABLED:
  default:
    DBGV("handleDelayResp: disreguard\n");
    return;
    
  case PTP_SLAVE:
    if(header->sourceCommunicationTechnology == ptpClock->parent_communication_technology
      && header->sourcePortId == ptpClock->parent_port_id
      && !memcmp(header->sourceUuid, ptpClock->parent_uuid, PTP_UUID_LENGTH)
      && header->sourceCommunicationTechnology == ptpClock->parent_communication_technology
      && ptpClock->sentDelayReq
      && resp->requestingSourceSequenceId == ptpClock->sentDelayReqSequenceId
      && resp->requestingSourceCommunicationTechnology == ptpClock->port_communication_technology
      && resp->requestingSourcePortId == ptpClock->port_id_field
      && !memcmp(resp->requestingSourceUuid, ptpClock->port_uuid_field, PTP_UUID_LENGTH))
    {
      ptpClock->sentDelayReq = FALSE;
      updateDelay(&ptpClock->delay_req_sending_time, &resp->delayReceiptTimestamp,
        &ptpClock->owd_filt, rtOpts, ptpClock);
    }
    else
    {
      DBGV("handleDelayResp: unwanted\n");
    }
    break;
  }
}

void handleManagement(MsgHeader *header, MsgManagement *manage, RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  UInteger8 state;
  
  if(ptpClock->port_state == PTP_INITIALIZING)
    return;
  
  if( (manage->targetCommunicationTechnology == ptpClock->clock_communication_technology
       && !memcmp(manage->targetUuid, ptpClock->clock_uuid_field, PTP_UUID_LENGTH))
     || ((manage->targetCommunicationTechnology == PTP_DEFAULT || manage->targetCommunicationTechnology == ptpClock->clock_communication_technology)
         && manage->targetUuid[0]==0x00 && manage->targetUuid[1]==0x00
         && manage->targetUuid[2]==0x00 && manage->targetUuid[3]==0x00
         && manage->targetUuid[4]==0x00 && manage->targetUuid[5]==0x00) )
  {
    switch(manage->managementMessageKey)
    {
    case PTP_MM_OBTAIN_IDENTITY:
    case PTP_MM_GET_DEFAULT_DATA_SET:
    case PTP_MM_GET_CURRENT_DATA_SET:
    case PTP_MM_GET_PARENT_DATA_SET:
    case PTP_MM_GET_PORT_DATA_SET:
    case PTP_MM_GET_GLOBAL_TIME_DATA_SET:
    case PTP_MM_GET_FOREIGN_DATA_SET:
      issueManagement(header, manage, rtOpts, ptpClock);
      break;
      
    default:
      ptpClock->record_update = TRUE;
      state = msgUnloadManagement(ptpClock->msgIbuf, manage, ptpClock, rtOpts);
      if(state != ptpClock->port_state)
        toState(state, rtOpts, ptpClock);
      break;
    }
  }
}

void issueSync(RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  ++ptpClock->last_sync_event_sequence_number;
  ptpClock->grandmaster_sequence_number = ptpClock->last_sync_event_sequence_number;
  
  msgPackSync(ptpClock->msgObuf, FALSE, ptpClock);
  
  if( netSendEvent(0, ptpClock->msgObuf, SYNC_PACKET_LENGTH,
      &ptpClock->sync_receipt_time, &ptpClock->netPath) )
  {
    addTime(&ptpClock->sync_receipt_time, &ptpClock->sync_receipt_time, &rtOpts->outboundLatency);
  }
  else
    toState(PTP_FAULTY, rtOpts, ptpClock);
  
  DBGV("event Send %d Message at %lus %ldns\n",
     PTP_SYNC_MESSAGE,
     ptpClock->sync_receipt_time.seconds,
     ptpClock->sync_receipt_time.nanoseconds);
  
  if(!ptpClock->clock_followup_capable)
    return;
  
  ++ptpClock->last_general_event_sequence_number;
  
  msgPackFollowUp(ptpClock->msgObuf, ptpClock->last_sync_event_sequence_number,
    &ptpClock->sync_receipt_time, ptpClock);
  
  if( !netSendGeneral(0, ptpClock->msgObuf, FOLLOW_UP_PACKET_LENGTH, &ptpClock->netPath) )
    toState(PTP_FAULTY, rtOpts, ptpClock);
  
  DBGV("event Send %d Message\n", PTP_FOLLOWUP_MESSAGE);
}

void issueDelayReq(RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  ptpClock->sentDelayReq = TRUE;
  ptpClock->sentDelayReqSequenceId = ++ptpClock->last_sync_event_sequence_number;

  msgPackDelayReq(ptpClock->msgObuf, FALSE, ptpClock);
  
  if( netSendEvent(0, ptpClock->msgObuf, DELAY_REQ_PACKET_LENGTH,
      &ptpClock->delay_req_sending_time, &ptpClock->netPath) )
  {
    addTime(&ptpClock->delay_req_sending_time, &ptpClock->delay_req_sending_time, &rtOpts->outboundLatency);
  }
  else
    toState(PTP_FAULTY, rtOpts, ptpClock);
  
  DBGV("event Send %d Message at %lus %ldns\n",
     PTP_DELAY_REQ_MESSAGE,
     ptpClock->delay_req_sending_time.seconds,
     ptpClock->delay_req_sending_time.nanoseconds);
}

void issueDelayResp(TimeRepresentation *time, MsgHeader *header, RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  ++ptpClock->last_general_event_sequence_number;
    
  msgPackDelayResp(ptpClock->msgObuf, header, time, ptpClock);
  
  if( !netSendGeneral(0, ptpClock->msgObuf, DELAY_RESP_PACKET_LENGTH, &ptpClock->netPath) )
    toState(PTP_FAULTY, rtOpts, ptpClock);
    
  DBGV("event Send %d Message\n", PTP_DELAY_RESP_MESSAGE);
}

void issueManagement(MsgHeader *header, MsgManagement *manage, RunTimeOpts *rtOpts, PtpClock *ptpClock)
{
  UInteger16 len;
  
  ++ptpClock->last_general_event_sequence_number;
  
  if(!(len = msgPackManagementResponse(ptpClock->msgObuf, header, manage, ptpClock)))
    return;
  
  if( !netSendGeneral(0, ptpClock->msgObuf, len, &ptpClock->netPath) )
    toState(PTP_FAULTY, rtOpts, ptpClock);
  
  DBG("sent management message\n");
}

MsgSync * addForeign(Octet *buf, MsgHeader *header, PtpClock *ptpClock)
{
  int i, j;
  Boolean found = FALSE;
  
  DBGV("updateForeign\n");
  
  j = ptpClock->foreign_record_best;
  for(i = 0; i < ptpClock->number_foreign_records; ++i)
  {
    if(header->sourceCommunicationTechnology == ptpClock->foreign[j].foreign_master_communication_technology
      && header->sourcePortId == ptpClock->foreign[j].foreign_master_port_id
      && !memcmp(header->sourceUuid, ptpClock->foreign[j].foreign_master_uuid, PTP_UUID_LENGTH))
    {
      ++ptpClock->foreign[j].foreign_master_syncs;
      found = TRUE;
      DBGV("updateForeign: update record %d\n", j);
      break;
    }
    
    j = (j + 1)%ptpClock->number_foreign_records;
  }
  
  if(!found)
  {
    if(ptpClock->number_foreign_records < ptpClock->max_foreign_records)
      ++ptpClock->number_foreign_records;
    
    j = ptpClock->foreign_record_i;
    
    ptpClock->foreign[j].foreign_master_communication_technology =
      header->sourceCommunicationTechnology;
    ptpClock->foreign[j].foreign_master_port_id =
      header->sourcePortId;
    memcpy(ptpClock->foreign[j].foreign_master_uuid,
      header->sourceUuid, PTP_UUID_LENGTH);
    
    DBG("updateForeign: new record (%d,%d) %d %d %02hhx:%02hhx:%02hhx:%02hhx:%02hhx:%02hhx\n",
      ptpClock->foreign_record_i, ptpClock->number_foreign_records,
      ptpClock->foreign[j].foreign_master_communication_technology,
      ptpClock->foreign[j].foreign_master_port_id,
      ptpClock->foreign[j].foreign_master_uuid[0], ptpClock->foreign[j].foreign_master_uuid[1],
      ptpClock->foreign[j].foreign_master_uuid[2], ptpClock->foreign[j].foreign_master_uuid[3],
      ptpClock->foreign[j].foreign_master_uuid[4], ptpClock->foreign[j].foreign_master_uuid[5]);
    
    ptpClock->foreign_record_i = (ptpClock->foreign_record_i + 1)%ptpClock->max_foreign_records;
  }
  
  msgUnpackHeader(buf, &ptpClock->foreign[j].header);
  msgUnpackSync(buf, &ptpClock->foreign[j].sync);
  
  return &ptpClock->foreign[j].sync;
}
