/* The system doesn't have <alloca.h>.  Use our alloca.h emulation.  */
#include "alloca_.h"
