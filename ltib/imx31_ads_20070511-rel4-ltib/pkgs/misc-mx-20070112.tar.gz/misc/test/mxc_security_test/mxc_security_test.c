/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All rights reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*
 * This tests the Freescale MXC Security driver for the basic operation.
 * The following tests are done.
 * - IOCTL tests
 *      - Configure RNGA.
 *      - Generate Random number.
 *      - Generate N Random numbers.
 *      - Set entropy (Initial Seed for generating random numbers).
 *      - Status of RNGA.
 *      - Number of data availability in FIFO.
 *      - Size of the FIFO.
 *      - Hash the data. 
 *      - Status of HAC Hash.
 *      - Configure RTIC. 
 */

/*
 * This # define is used if debugging is required
 * #define  SEC_TEST_DEBUG
*/
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <asm/ioctls.h>
#include <asm/termios.h>
#include <errno.h>
#include <malloc.h>

//#include <asm-arm/arch-mxc/mxc_security_api.h>

#include "mxc_test.h"

int ioctl(int fd, int cmd, void *arg);
int close(int fd);

int main(int ac, char **av)
{
        int fd, ret_val, option;
        unsigned int arg,*temp_arg[4], i;
        char *defdev="/dev/mxc_test";
#ifdef  SEC_TEST_DEBUG
        printf("SEC TEST APP: In function main\n\r");
        printf("SEC TEST APP: To open the FD of Security\n\r");
#endif
        fd = open(defdev, O_RDONLY);
        if(fd < 0){
                printf("SEC TEST APP: Open failed with err %d\n", fd);
                perror("Open");
                return -1;
        }
#ifdef  SEC_TEST_DEBUG
        printf("SEC TEST APP: Open succes: retval %d\n", fd);
#endif
        while (1) {
                printf("========> Testing MXC security driver <========\n");
                printf("Select the following security module to be tested: \n");
                printf("1. HAC \n");
                printf("2. RTIC \n");
                printf("3. Exit \n");
                printf("Enter your option: ");
                scanf("%d", &option);

                switch(option) {
                case 1: /* HAC */
                        while (1) {
                        printf("======> Testing MXC HAC driver <======\n");
                        printf("1. Hash the data.\n");
                        printf("2. Get Hash status\n");
                        printf("3. Exit\n");
                        printf("Enter your option: ");
                        scanf("%d",&option);
                        
                        switch (option)
                        {
                                case 1:
                                printf("HAC TEST APP: Start hashing.\n");
                                /* Address of the data to be hashed */
                                temp_arg[0] = (unsigned int *)malloc\
                                                (sizeof(unsigned int) * 0x10);
                                /* Block length that needs to be hashed. 512
                                 * bits per block */
                                temp_arg[1] = (unsigned int *)1;
                                /* Address of the data to be hashed */
                                temp_arg[2] = (unsigned int *)malloc\
                                                (sizeof(unsigned int) * 0x10);
                                /* Block length that needs to be hashed. 512
                                 * bits per block */
                                temp_arg[3] = (unsigned int *)1;
                                
                                for (i = 0; i < 0x10; i++) {
                                        *(temp_arg[0] + i) = i + 0x12345678;
                                        *(temp_arg[2] + i) = i + 0x87654321;
                                }
                                
                                printf("HAC TEST APP: Data in block1:\n");
                                for (i = 0; i < 0x10; i++) {
                                        printf("0x%08X ", temp_arg[0][i]);
                                }
                                        
                                printf("\nHAC TEST APP: Data in block2:\n");
                                for (i = 0; i < 0x10; i++) {
                                        printf("0x%08X ", temp_arg[2][i]);
                                }
                                printf("\nParameters to be sent to driver:\n");
                                printf("HAC TEST APP: Parameter1: 0x%08X\n",\
                                        *(unsigned int *)temp_arg);
                                printf("HAC TEST APP: Parameter2: 0x%08X\n",\
                                        *(unsigned int *)(temp_arg + 1));
                                printf("HAC TEST APP: Parameter3: 0x%08X\n",\
                                        *(unsigned int *)(temp_arg + 2));
                                printf("HAC TEST APP: Parameter4: 0x%08X\n",\
                                        *(unsigned int *)(temp_arg + 3));
                                
                                ret_val = ioctl(fd, MXCTEST_HAC_START_HASH,
                                                 temp_arg);
                                if (ret_val < 0) {
                                        printf("HAC TEST APP: ioctl call fail"
                                                "ed with err %d\n", ret_val);
                                        perror("ioctl");
                                        return -1;
                                }
                                printf("\n==================================="
                                        "============\n");
                                /* Freeing the memory that was allocated */
                                free(temp_arg[0]);
                                free(temp_arg[2]);

                                break;

                                case 2:
                                printf("HAC TEST APP: Display Hash status\n");
                                ret_val = ioctl(fd, MXCTEST_HAC_STATUS, &arg);
                                if (ret_val < 0) {
                                        printf("HAC TEST APP: ioctl call fail"\
                                                "ed with err %d\n", ret_val);
                                        perror("ioctl");
                                        return -1;
                                }
                                printf("\n==================================="
                                        "============\n");

                                break;
                                
                                case 3:
                                default:
                                        goto hac_out;
                                break;
                         
                        }/* End of HAC Switch case statement */
                        }/* End of HAC while */
hac_out:                
                break; /* End of HAC case */

                case 2: /* RTIC */
                        while (1) {
                        printf("======> Testing MXC RTIC driver <======\n");
                        printf("1. Hash the data in One time.\n");
                        printf("2. Hash the data in Run time.\n");
                        printf("3. Check for error condition during Run Time."\
                                "\n");
                        printf("4. Get Hash status\n");
                        printf("5. Exit\n");
                        printf("Enter your option: ");
                        scanf("%d",&option);
                        
                        switch (option)
                        {
                                case 1:
                                printf("RTIC TEST APP: Start hashing.\n");
                                /* Address of the data to be hashed */
                                temp_arg[0] = (unsigned int *)malloc\
                                                (sizeof(unsigned int) * 0x10);
                                /* Block length that needs to be hashed. 512
                                 * bits per block */
                                temp_arg[1] = (unsigned int *)0x10;

                                for (i = 0; i < 0x10; i++) {
                                        *(temp_arg[0] + i) = i + 0x12345678;
                                }

                                printf("RTIC TEST APP: Data in block1:\n");
                                for (i = 0; i < 0x10; i++) {
                                        printf("0x%08X ", temp_arg[0][i]);
                                }

                                printf("\nParameters to be sent to driver:\n");
                                printf("RTIC TEST APP: Parameter1: 0x%08X\n",\
                                        *(unsigned int *)temp_arg);
                                printf("RTIC TEST APP: Parameter2: 0x%08X\n",\
                                        *(unsigned int *)(temp_arg + 1));
                                ret_val = ioctl(fd, MXCTEST_RTIC_ONETIME_TEST,
                                                 temp_arg);
                                if (ret_val < 0) {
                                        printf("RTIC TEST APP: ioctl call fail"
                                                "ed with err %d\n", ret_val);
                                        perror("ioctl");
                                        return -1;
                                }
                                printf("\n==================================="
                                        "============\n");
                                /* Freeing the memory that was allocated */
                                free(temp_arg[0]);
                                break;

                                case 2:
                                printf("RTIC TEST APP: Start hashing.\n");
                                /* Address of the data to be hashed */
                                temp_arg[0] = (unsigned int *)malloc\
                                                (sizeof(unsigned int) * 0x10);
                                /* Block length that needs to be hashed. 512
                                 * bits per block */
                                temp_arg[1] = (unsigned int *)0x10;

                                for (i = 0; i < 0x10; i++) {
                                        *(temp_arg[0] + i) = i + 0x12345678;
                                }

                                printf("RTIC TEST APP: Data in block1:\n");
                                for (i = 0; i < 0x10; i++) {
                                        printf("0x%08X ", temp_arg[0][i]);
                                }

                                printf("\nParameters to be sent to driver:\n");
                                printf("RTIC TEST APP: Parameter1: 0x%08X\n",\
                                        *(unsigned int *)temp_arg);
                                printf("RTIC TEST APP: Parameter2: 0x%08X\n",\
                                        *(unsigned int *)(temp_arg + 1));
                                ret_val = ioctl(fd, MXCTEST_RTIC_RUNTIME_TEST,
                                                 temp_arg);
                                if (ret_val < 0) {
                                        printf("RTIC TEST APP: ioctl call fail"
                                                "ed with err %d\n", ret_val);
                                        perror("ioctl");
                                        return -1;
                                }
                                printf("\n==================================="
                                        "============\n");
                                /* Freeing the memory that was allocated */
                                free(temp_arg[0]);
                                break;

                                case 3:
                                printf("RTIC TEST APP: Start hashing.\n");
                                /* Address of the data to be hashed */
                                temp_arg[0] = (unsigned int *)malloc\
                                                (sizeof(unsigned int) * 0x10);
                                /* Block length that needs to be hashed. 512
                                 * bits per block */
                                temp_arg[1] = (unsigned int *)0x10;

                                for (i = 0; i < 0x10; i++) {
                                        *(temp_arg[0] + i) = i + 0x12345678;
                                }

                                printf("RTIC TEST APP: Data in block1:\n");
                                for (i = 0; i < 0x10; i++) {
                                        printf("0x%08X ", temp_arg[0][i]);
                                }

                                printf("\nParameters to be sent to driver:\n");
                                printf("RTIC TEST APP: Parameter1: 0x%08X\n",\
                                        *(unsigned int *)temp_arg);
                                printf("RTIC TEST APP: Parameter2: 0x%08X\n",\
                                        *(unsigned int *)(temp_arg + 1));
                                ret_val = ioctl(fd, MXCTEST_RTIC_RUNTIME_ERROR,
                                                 temp_arg);
                                if (ret_val < 0) {
                                        printf("RTIC TEST APP: ioctl call fail"
                                                "ed with err %d\n", ret_val);
                                        perror("ioctl");
                                        return -1;
                                }
                                printf("\n==================================="
                                        "============\n");
                                /* Freeing the memory that was allocated */
                                free(temp_arg[0]);
                                break;
                                        
                                case 4:
                                printf("RTIC TEST APP: Display Hash status\n");
                                ret_val = ioctl(fd, MXCTEST_RTIC_STATUS, &arg);
                                if (ret_val < 0) {
                                        printf("RTIC TEST APP: ioctl call fail"
                                                "ed with err %d\n", ret_val);
                                        perror("ioctl");
                                        return -1;
                                }
                                printf("\n==================================="
                                        "============\n");
                                break;

                                case 5:
                                default:
                                        goto rtic_out;
                                break;
                         
                        }/* End of RTIC Switch case statement */
                        }/* End of RTIC while loop */
rtic_out:                        
                break; /* End of RTIC case */

                case 3:
                default: /* Default of main switch statement */
                        goto out_main;
                break; /* End of exit */

                } /* End of main switch statement */
        } /* End of External while loop */

out_main:
        printf("SEC TEST APP: Closing the security device \n");
        ret_val = close(fd);
        if(ret_val < 0)  {
                printf("SEC TEST APP: Close failed with err %d\n", ret_val);
                perror("Close");
                return -1;
        }
        printf("SEC TEST APP: Close success: retval %d\n", ret_val);
        printf("SEC TEST APP: Testing MXC security driver complete\n");
        return 0;
}

