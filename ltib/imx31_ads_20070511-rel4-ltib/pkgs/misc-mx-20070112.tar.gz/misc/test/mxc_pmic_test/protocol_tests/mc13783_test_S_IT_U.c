/*============================================================================*/
/**
    @file   mc13783_test_S_IT_U.c

    @brief  Test scenario C source MC13783.
*/
/*==============================================================================

  Copyright (C) 2004, Freescale Semiconductor, Inc. All Rights Reserved
  THIS SOURCE CODE IS CONFIDENTIAL AND PROPRIETARY AND MAY NOT
  BE USED OR DISTRIBUTED WITHOUT THE WRITTEN PERMISSION OF
  Freescale Semiconductor, Inc.
     
================================================================================
Revision History:
                            Modification     Tracking
Author                          Date          Number    Description of Changes
-------------------------   ------------    ----------  -----------------------
Developer CHEVERNEUIL/RB878C  05/18/2004     TLSbo39480   Initial version
LUDOVIC DeELASPRE/RC149C       05/28/2004     TLSbo39713   VTE 1.2 integration
Alexandr GENIATOV             07/15/2004     TLSbo40262   Code improvement
CHEVERNEUIL/FCHE01            09/16/2004     TLSbo42608   use MC13783 include
        						  files
CHEVERNEUIL/FCHE01            02/09/2005     TLSbo47307   change touchscreen 
        						  IT by PWR button.

================================================================================
Portability: Indicate if this module is portable to other compilers or 
             platforms. 
             If not, indicate specific reasons why is it not portable.

==============================================================================*/

#ifdef __cplusplus
extern "C" {
#endif

/*==============================================================================
                                        INCLUDE FILES
==============================================================================*/
/* Standard Include Files */
#include <stdio.h>
#include <errno.h>
#include <ctype.h>

/* Harness Specific Include Files. */
#include "../include/test.h"

/* Verification Test Environment Include Files */
#include "mc13783_test_common.h"
#include "mc13783_test_S_IT_U.h"

/*==============================================================================
                                        LOCAL MACROS
==============================================================================*/

/*==============================================================================
                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==============================================================================*/

/*==============================================================================
                                       LOCAL CONSTANTS
==============================================================================*/

/*==============================================================================
                                       LOCAL VARIABLES
==============================================================================*/

/*==============================================================================
                                       GLOBAL CONSTANTS
==============================================================================*/

/*==============================================================================
                                       GLOBAL VARIABLES
==============================================================================*/

/*==============================================================================
                                   LOCAL FUNCTION PROTOTYPES
==============================================================================*/

/*==============================================================================
                                       LOCAL FUNCTIONS
==============================================================================*/

/*============================================================================*/
/*===== VT_mc13783_S_IT_U_setup =====*/
/**
@brief  assumes the initial condition of the test case execution

@param  None
  
@return On success - return TPASS
        On failure - return the error code
*/
/*============================================================================*/
	int VT_mc13783_S_IT_U_setup(void) {
		int rv = TFAIL;

		 rv = TPASS;

		 return rv;
	}
															 /*============================================================================*//*===== VT_mc13783_S_IT_U_cleanup =====*//**
@brief  assumes the post-condition of the test case execution

@param  None
  
@return On success - return TPASS
          On failure - return the error code
*//*============================================================================*/ int VT_mc13783_S_IT_U_cleanup(void) {
		int rv = TFAIL;

		rv = TPASS;

		return rv;
	}

	int ask_user(char *question) {
		unsigned char answer;
		int ret = TRETR;

		printf("%s [Y/N]", question);
		do {
			answer = fgetc(stdin);
			if (answer == 'Y' || answer == 'y')
				ret = TPASS;
			else if (answer == 'N' || answer == 'n')
				ret = TFAIL;
		} while (ret == TRETR);
		fgetc(stdin);	/* Wipe CR character from stream */
		return ret;
	}

/*============================================================================*/
/*===== VT_mc13783_test_S_IT_U =====*/
/**
@brief  MC13783 test scenario IT function

@param  None
  
@return On success - return TPASS
        On failure - return the error code
*/
/*============================================================================*/
	int VT_mc13783_test_S_IT_U(void) {
		int rv = TPASS, fd;
		char result;
		int event = EVENT_ONOFD1I;

		fd = open(MC13783_DEVICE, O_RDWR);
		if (fd < 0) {
			pthread_mutex_lock(&mutex);
			tst_resm(TFAIL, "Unable to open %s", MC13783_DEVICE);
			pthread_mutex_unlock(&mutex);
			return TFAIL;
		}

		if (VT_mc13783_subscribe(fd, event) != TPASS) {
			rv = TFAIL;
		}

		pthread_mutex_lock(&mutex);
		printf("\nPress PWR button on the KeyBoard or MC13783 board\n"
		       "you should see IT callback info\n"
		       "Press Enter to continue after pressing the button\n");
		getchar();
		pthread_mutex_unlock(&mutex);
		if (VT_mc13783_unsubscribe(fd, event) != TPASS) {
			rv = TFAIL;
		}

		pthread_mutex_lock(&mutex);
		if (ask_user("Did you see the callback info ") == TFAIL) {
			rv = TFAIL;
		}
		printf("Test subscribe/unsubscribe 2 event = %d\n", event);
		pthread_mutex_unlock(&mutex);
		if (VT_mc13783_subscribe(fd, event) != TPASS) {
			rv = TFAIL;
		}
		if (VT_mc13783_subscribe(fd, event) != TPASS) {
			rv = TFAIL;
		}

		pthread_mutex_lock(&mutex);
		printf("\nPress PWR button on the KeyBoard or MC13783 board\n"
		       "you should see IT callback info twice.\n"
		       "Press Enter to continue after pressing the button\n");
		getchar();
		pthread_mutex_unlock(&mutex);
		if (VT_mc13783_unsubscribe(fd, event) != TPASS) {
			rv = TFAIL;
		}
		if (VT_mc13783_unsubscribe(fd, event) != TPASS) {
			rv = TFAIL;
		}
		if (ask_user("Did you see the callback info twice") == TFAIL) {
			rv = TFAIL;
		}

		if (close(fd) < 0) {
			pthread_mutex_lock(&mutex);
			tst_resm(TFAIL, "Unable to close file descriptor %d",
				 fd);
			pthread_mutex_unlock(&mutex);
			return TFAIL;
		}

		return rv;
	}

#ifdef __cplusplus
}
#endif
