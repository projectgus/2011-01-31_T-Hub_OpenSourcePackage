/*!
 *
 * File: mxc_setup.h
 *
 */
/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#ifndef MXC_SETUP_H
#define MXC_SETUP_H

/*!
 * @defgroup NANDboot Bootloader for NAND Flash
 */

/*!
 * @file mxc_nb_setup.h
 * 
 * @brief This file contains the  kernel tags list definitions 
 *
 * @ingroup NANDboot
 */

#include "mxc.h"

/* Round up a quantity to a longword (32 bit) length */
#define ROUNDUP(n) (((n)+3)&~3)

/* The list ends with an ATAG_NONE node. */
#define ATAG_NONE	0x00000000

struct tag_header {
	U32 size;
	U32 tag;
};

/* The list must start with an ATAG_CORE node */
#define ATAG_CORE	0x54410001

struct tag_core {
	U32 flags;
	U32 pagesize;
	U32 rootdev;
};

/* it is allowed to have multiple ATAG_MEM nodes */
#define ATAG_MEM	0x54410002

struct tag_mem32 {
	U32 size;
	U32 start;
};

/* command line: \0 terminated string */
#define ATAG_CMDLINE	0x54410009

struct tag_cmdline {
	char cmdline[1];
};

struct tag {
	struct tag_header hdr;
	union {
		struct tag_core core;
		struct tag_mem32 mem;
		struct tag_cmdline cmdline;
	} u;
};

#endif				/*MXC_SETUP_H */
