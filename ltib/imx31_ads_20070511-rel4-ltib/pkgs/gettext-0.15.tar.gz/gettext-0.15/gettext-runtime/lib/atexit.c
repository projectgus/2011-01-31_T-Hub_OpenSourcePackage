#include "../../gettext-tools/lib/atexit.c"
