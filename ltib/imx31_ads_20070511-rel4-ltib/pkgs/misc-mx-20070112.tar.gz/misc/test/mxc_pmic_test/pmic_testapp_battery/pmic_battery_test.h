/*============================================================================*/
/**
    @file   pmic_battery_test.h

    @brief  Header file for PMIC Battery driver test scenario. 
*/
/*==============================================================================

Copyright (C) 2004, Freescale Semiconductor, Inc. All Rights Reserved
THIS SOURCE CODE IS CONFIDENTIAL AND PROPRIETARY AND MAY NOT
BE USED OR DISTRIBUTED WITHOUT THE WRITTEN PERMISSION OF
Freescale Semiconductor, Inc.
     
================================================================================
Revision History:
                            Modification     Tracking
Author (core ID)                Date          Number     Description of Changes
-------------------------   ------------    ----------  -----------------------
Jorge QUINTERO               10/19/2005     DSPhl26599   Initial Version

==============================================================================*/

#ifndef PMIC_TEST_BATT_H
#define PMIC_TEST_BATT_H

#ifdef __cplusplus
extern "C"{
#endif

/*==============================================================================
                                         INCLUDE FILES
==============================================================================*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <linux/wait.h>

#include <asm/arch/pmic_status.h>
#include <asm/arch/pmic_battery.h>

/*==============================================================================
                                       DEFINES AND MACROS
==============================================================================*/
#define	PMIC_BATT_DEV "pmic_battery" 

#if !defined(TRUE) && !defined(FALSE)
#define TRUE  1
#define FALSE 0
#endif

/*==============================================================================
                                     FUNCTION PROTOTYPES
==============================================================================*/
int VT_pmic_batt_test(int switch_fct);

#ifdef __cplusplus
}
#endif

#endif 
