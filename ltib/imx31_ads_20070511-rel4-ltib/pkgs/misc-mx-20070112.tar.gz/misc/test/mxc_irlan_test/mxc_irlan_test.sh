#!/bin/sh

if grep 'MX31' /proc/cpuinfo; then
	export IRDA_PORT=/dev/ttymxc1
else
	export IRDA_PORT=/dev/ttymxc3
fi

echo $IRDA_PORT

cp /lib/modules/2.6.10_dev/kernel/net/irda/irlan/irlan.ko .
#setserial $IRDA_PORT
stty -F $IRDA_PORT -echo
modprobe irtty-sir
insmod irlan.ko access=2
if [ $1 != 2 ]; then
  ifconfig irlan0 10.0.0.1 netmask 255.255.255.0 broadcast 10.0.0.255
else
  ifconfig irlan0 10.0.0.2 netmask 255.255.255.0 broadcast 10.0.0.255
fi
irattach $IRDA_PORT -s
#irdadump
