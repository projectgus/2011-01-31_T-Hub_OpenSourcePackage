#ifndef MXC_UART_H
#define MXC_UART_H

/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mxc_uart.h
 * 
 * @brief This file contains the UART register information. 
 *
 * 
 * @ingroup Miniboot and NANDboot
 */

#include "mxc.h"

/* Maximum length of the string */
#define MAX_STRLEN	150

/*!
 * Selection of the UART port depends on the \b UART_PORT value defined in 
 * \b mxc.h
 */
#if defined(IMX21ADS) || defined(IMX27ADS)
#if (UART_PORT==1)
/*!
 * UART 1 base address
 */
#define MXC_UART_BASE         0x1000a000
#endif
#if (UART_PORT==2)

/*!
 * UART 2 base address 
 */
#define MXC_UART_BASE         0x1000b000
#endif
#else
#if (UART_PORT==1)

/*!
 * UART 1 base address
 */
#define MXC_UART_BASE         0x43F90000
#endif
#if (UART_PORT==2)

/*!
 * UART 2 base address 
 */
#define MXC_UART_BASE         0x43F94000
#endif

#endif

/*
 * This defines the addresses for UART registers for 16 bit access 
 */
#define _reg_URXD       (*((volatile U32 *)(MXC_UART_BASE+0x00)))
#define _reg_UTXD       (*((volatile U32 *)(MXC_UART_BASE+0x40)))
#define _reg_UCR1       (*((volatile U32 *)(MXC_UART_BASE+0x80)))
#define _reg_UCR2       (*((volatile U32 *)(MXC_UART_BASE+0x84)))
#define _reg_UCR3       (*((volatile U32 *)(MXC_UART_BASE+0x88)))
#define _reg_UCR4       (*((volatile U32 *)(MXC_UART_BASE+0x8C)))
#define _reg_UFCR       (*((volatile U32 *)(MXC_UART_BASE+0x90)))
#define _reg_USR1       (*((volatile U32 *)(MXC_UART_BASE+0x94)))
#define _reg_USR2       (*((volatile U32 *)(MXC_UART_BASE+0x98)))
#define _reg_UESC       (*((volatile U32 *)(MXC_UART_BASE+0x9C)))
#define _reg_UTIM       (*((volatile U32 *)(MXC_UART_BASE+0xA0)))
#define _reg_UBIR       (*((volatile U32 *)(MXC_UART_BASE+0xA4)))
#define _reg_UBMR       (*((volatile U32 *)(MXC_UART_BASE+0xA8)))
#define _reg_UBRC       (*((volatile U32 *)(MXC_UART_BASE+0xAC)))

#if defined(IMX21ADS)||defined(IMX27ADS)
#define _reg_UTS       (*((volatile U32 *)(MXC_UART_BASE+0xB4)))
#endif
/*
 * Mask to check Tx buffer empty
 */
#define TXFE_MASK   0x4000

/*
 * Mask to check receive data ready
 */
#define RDR_MASK    0x0001

/*
 * UART BRM register value
 */
#define MXC_UART_UBMR	0x1FBC

#ifdef nandboot
#ifdef IMX21ADS
#define BASE		0xCC000000
#define EXT_UART_BASE	(BASE + 0x200000)
#else
#define BASE		0xB4000000
#define EXT_UART_BASE	(BASE + 0x00010000)
#endif
#endif

/*
 * This defines the UART Baud rate configurations 
 */
#ifdef miniboot
#define BASE		0xB4000000
#define EXT_UART_BASE 	(BASE + 0x00010000)
#endif

#if UART_BAUD_RATE==9600
#define EXT_SERIAL_BAUD_MSB        0x00
#define EXT_SERIAL_BAUD_LSB        0x60
#define MXC_UART_UBIR              0x5F
#endif

#if UART_BAUD_RATE==19200
#define EXT_SERIAL_BAUD_MSB        0x00
#define EXT_SERIAL_BAUD_LSB        0x30
#define MXC_UART_UBIR              0xC0
#endif

#if UART_BAUD_RATE==38400
#define EXT_SERIAL_BAUD_MSB        0x00
#define EXT_SERIAL_BAUD_LSB        0x18
#define MXC_UART_UBIR              0x17F
#endif

#if UART_BAUD_RATE==57600
#define EXT_SERIAL_BAUD_MSB        0x00
#define EXT_SERIAL_BAUD_LSB        0x10
#define MXC_UART_UBIR              0x23F
#endif

#if UART_BAUD_RATE==115200
#define EXT_SERIAL_BAUD_MSB        0x00
#define EXT_SERIAL_BAUD_LSB        0x08
#define MXC_UART_UBIR              0x47F
#endif

#if  (UART_PORT==1)
#define EXT_SERIAL_BASE    (EXT_UART_BASE + 0x0000)	/* port A */
#endif

#if (UART_PORT==2)
#define EXT_SERIAL_BASE    (EXT_UART_BASE + 0x0010)	/* port B */
#endif
#endif

/*
 * This defines the addresses for External UART registers 
 */

#define _reg_RHR        (*((volatile U8 *)(EXT_SERIAL_BASE+0x00)))
#define _reg_THR        (*((volatile U8 *)(EXT_SERIAL_BASE+0x00)))
#define _reg_DLL        (*((volatile U8 *)(EXT_SERIAL_BASE+0x00)))
#define _reg_IER        (*((volatile U8 *)(EXT_SERIAL_BASE+0x01)))
#define _reg_DLM        (*((volatile U8 *)(EXT_SERIAL_BASE+0x01)))
#define _reg_IIR        (*((volatile U8 *)(EXT_SERIAL_BASE+0x02)))
#define _reg_FCR        (*((volatile U8 *)(EXT_SERIAL_BASE+0x02)))
#define _reg_AFR        (*((volatile U8 *)(EXT_SERIAL_BASE+0x02)))
#define _reg_LCR        (*((volatile U8 *)(EXT_SERIAL_BASE+0x03)))
#define _reg_MCR        (*((volatile U8 *)(EXT_SERIAL_BASE+0x04)))
#define _reg_MCR_A      (*((volatile U8 *)(EXT_SERIAL_BASE+0x04)))
#define _reg_MCR_B      (*((volatile U8 *)(EXT_SERIAL_BASE+0x04)))
#define _reg_LSR        (*((volatile U8 *)(EXT_SERIAL_BASE+0x05)))
#define _reg_MSR        (*((volatile U8 *)(EXT_SERIAL_BASE+0x06)))
#define _reg_SCR        (*((volatile U8 *)(EXT_SERIAL_BASE+0x07)))

/* The line status register bits. */
#define SIO_LSR_DR      0x01	/* data ready */
#define SIO_LSR_THRE    0x20	/* transmitter holding register empty */

/* The line control register bits. */
#define SIO_LCR_WLS0   0x01	/*word length select bit 0 */
#define SIO_LCR_WLS1   0x02	/* word length select bit 1 */
#define SIO_LCR_DLAB   0x80	/* divisor latch access bit */

#if UART_OUTPUT==INT_UART
#define mxc_outstring         mxc_uart_putstring
#define mxc_getstring         mxc_uart_getstring
#define mxc_getdata           mxc_uart_getdata
#define mxc_putdata           mxc_uart_putdata
#define mxc_dataready         mxc_uart_dataready
#define mxc_gethex            mxc_uart_gethex
#define mxc_puthex            mxc_uart_puthex
#else
#define mxc_outstring         ext_uart_write
#define mxc_getstring         ext_uart_read
#define mxc_getdata           ext_uart_getc
#define mxc_putdata           ext_uart_putc
#define mxc_dataready         ext_uart_dataready
#define mxc_gethex            ext_uart_gethex
#define mxc_puthex            ext_uart_puthex

#endif				/* MXC_UART_H */
