/*
 * Copyright 2006  Freescale Semiconductor, Inc. All Rights Reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*!
 * @file mxc_nandfsbuild.c
 * 
 * @brief NAND file system build utility 
 *
 * This utility copies IPL binary image (ipl.bin), SPL binary image (spl.bin)
 * and Linux kernel Image with information of size and crc (Image_crc) to file
 * flashmem0.dat which simulates a 16 bit 512 bytes page NAND Flash. This file
 * is be used as NAND flash in Virtio.
 * It copies ipl.bin to first 4 pages of the NAND flash, spl.bin to the 5th 
 * page till the end of the 0th block. Linux kernel Image is copied to the 1st
 * block i.e from offset 0x4200.
 * All the empty spaces in page or block are written with 0xFF.
 * After every 512 bytes it writes a spare area of 16 bytes as 0xFF.   
 *      
 * 
 * @ingroup NANDboot
 */

#include<stdio.h>

/* data types */
typedef unsigned int U32;
typedef unsigned char U8;

/*!
 * Path for Initial Program Loader binary image file
 */
char *iplfile = "./bin/ipl.bin";

/*!
 * Path for Secondary Program Loader binary image file
 */
char *splfile = "./bin/spl.bin";

/*!
 * Path for Linux kernel image file with size and crc value embedded
 */
char *imgcrc = "./bin/Image_crc";

/*!
 * Path for root file system
 */
char *rootfs = "./image/rootfs.cramfs";

/*!
 * Path for output file
 */
char *outfile = "./bin/flashmem0.dat";

/*!
 * Array of bad block numbers.  This array can be modified to create bad block.
 * The bad block numbers should be in ascending order.   
 */
int bdblk[] = { /* 40, 2, 40, 72 */  };

/*!
 * Structure for address location on NAND Flash
 */
struct location {
	U32 off;
	U32 page;
	U32 block;
};

/* !
 * Global variable to point the last location of the data written to file
 */
struct location end;

/*!
 * Global variable to indicate to put oob info into the output or not
 */
static int require_oob = 0;

/*!
 * This function writes the data from a binary file to flashmem0.dat which 
 * simulates NAND Flash. It writes the data till the end location specifies by
 * write_end parameter. If this parameter is null it writes the complete binary
 * image and then writes the empty space of that block with 0xFF.  
 * 
 * @param       frd             binary file to be written
 * @param       fwt             file pointer to flashmem0.dat
 * @param       write_end       end location till where data has to be written
 * 
 * @return      This function returns 1  if successful. It returns 0 if invalid 
 * end location which is less than global end location is passed.
 */
int write_data(FILE * frd, FILE * fwt, struct location *write_end)
{
	U32 off, page, block;
	U32 i = 0;
	U32 j, bdblk_id;
	U32 bdblk_max = 0;
	U8 bdblk_data = 0x00;
	U8 empty = 0xFF;
	U8 ch;
	/* check if the end location passed is lesser than current global end 
	 * location
	 */
	if (write_end) {
		if (end.block > write_end->block) {
			if (end.page > write_end->page) {
				if (end.off >= write_end->off) {
					printf("\nIncorrect end offset");
					return 0;
				}
			}
		}
	}
	bdblk_max = sizeof(bdblk) / sizeof(int);
	bdblk_id = bdblk_max;
	while (fread(&ch, 1, 1, frd)) {

		if (i < 512) {
			fwrite(&ch, 1, 1, fwt);
			i++;
		} else if (require_oob) {

			/* write the spare area */
			for (j = 0; j < 16; j++) {
				fwrite(&empty, 1, 1, fwt);
			}

			/* Writing bad block */
			if ((bdblk_max != 0) &&
			    (end.block == bdblk[bdblk_max - bdblk_id])) {
				for (page = 0; page < 32; page++) {
					for (j = 0; j < 528; j++) {
						/* Bad block Information */
						if (j == 523) {
							fwrite(&bdblk_data, 1,
							       1, fwt);
						} else {
							fwrite(&empty, 1,
							       1, fwt);
						}
					}
				}
				end.block++;
				printf("\nBolck no %d marked as bad block ",
				       bdblk[bdblk_max - bdblk_id]);
				if (bdblk_id > 0) {
					bdblk_id--;
				}
			}
			/* Bad block written */
			/* Write the extra byte read */
			fwrite(&ch, 1, 1, fwt);
			i = 1;
		}
		/* else */
		end.off++;
		if (end.off == 512) {
			end.off = 0;
			end.page++;
		}

		if (end.page == 32) {
			end.off = 0;
			end.page = 0;
			end.block++;
		}

	}			/* End of file read */

	if (write_end) {
		off = write_end->off;
		page = write_end->page;
		block = write_end->block;
	} else {
		off = 0;
		page = 0;
		block = end.block + 1;
	}

	/* Write the empty space with 0xFF */
	while ((end.off != off) || (end.page != page) || (end.block != block)) {
		fwrite(&empty, 1, 1, fwt);
		end.off++;

		if (end.off == 528) {
			end.off = 0;
			end.page++;
		}

		if (end.page == 32) {
			end.off = 0;
			end.page = 0;
			end.block++;
		}
	}
	return 1;
}

/*!
 * Main routine for the utility
 */
int main(int ac, char *av[])
{
	int ret;
	FILE *frd, *fwt;
	fpos_t *pos;
	struct location image_end;

	if (ac >= 2) {
		printf("Assuming oob option in image file\n");
		require_oob = 1;
	}

	fwt = fopen(outfile, "wb");
	if (!fwt) {
		printf("Failed to open %s\n", outfile);
		return 1;
	}

	/* Write IPL file */
	printf("\nWriting ipl.bin at block %d", end.block);
	frd = fopen(iplfile, "rb");
	if (frd) {
		/* Write the IPL image at (blk 0, pg 0) till (blk 0, pg 4) */
		image_end.off = 0;
		image_end.page = 4;
		image_end.block = 0;
		ret = write_data(frd, fwt, &image_end);
		fclose(frd);
		if (!ret) {
			return 1;
		}
	} else {
		printf("Failed to open %s\n", iplfile);
		return 1;
	}

	/* Write SPL file */
	printf("\nWriting spl.bin at block %d", end.block);
	frd = fopen(splfile, "rb");
	if (frd) {
		/* Write the IPL image at (blk 0, pg 0) till (blk 0, pg 4) */
		image_end.off = 0;
		image_end.page = 0;
		image_end.block = 1;
		ret = write_data(frd, fwt, &image_end);
		fclose(frd);
		if (!ret) {
			return 1;
		}
	} else {
		printf("Failed to open %s\n", splfile);
		return 1;
	}

	/* Write Kernel image with crc */
	printf("\nWriting Linux kernel image at block %d", end.block);
	frd = fopen(imgcrc, "rb");
	if (frd) {
		/* Write till the end of the image */
		ret = write_data(frd, fwt, 0);
		fclose(frd);
		if (!ret) {
			return 1;
		}
	} else {
		printf("Failed to open %s\n", imgcrc);
		return 1;
	}

	/* Write rootfs image */
	printf("\nWriting rootfs.cramfs image at block %d", end.block);
	frd = fopen(rootfs, "rb");
	if (frd) {
		/* Write till the end of the image */
		ret = write_data(frd, fwt, 0);
		fclose(frd);
		if (!ret) {
			return 1;
		}
	} else {
		printf("\nRootfs not written, %s not found..", rootfs);
	}

	/* Close the output file */
	fclose(fwt);
	printf("\nTotal blocks written %d \n", end.block);
	return 0;
}
