static char SNAPSHOT[] = "050330";
