/* Define if struct passwd has a field pw_quota. */
#undef HAVE_PW_QUOTA

/* Define if struct passwd has a field pw_comment. */
#undef HAVE_PW_COMMENT

/* Define if struct passwd has a field pw_change. */
#undef HAVE_PW_CHANGE

/* Define if struct passwd has a field pw_class. */
#undef HAVE_PW_CLASS

/* Define if struct passwd has a field pw_expire. */
#undef HAVE_PW_EXPIRE
