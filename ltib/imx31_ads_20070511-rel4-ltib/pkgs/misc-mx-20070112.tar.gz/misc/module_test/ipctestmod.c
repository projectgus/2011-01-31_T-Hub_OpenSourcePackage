/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All rights reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*
 * Include Files
 */
#include <linux/config.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/string.h>
#include <linux/fs.h>
#include <linux/major.h>
#include <linux/fs.h>

#include <asm/arch/mxc_ipc.h>
//#include <asm/arch/ipctest.h>

#define DEBUG 1

#if DEBUG
#define DPRINTK(fmt, args...) printk("%s: " fmt, __FUNCTION__ , ## args)
#else
#define DPRINTK(fmt, args...)
#endif

#define IOCTL_IPCTEST_EXEC_OPEN_CLOSE_TEST                      0x0
#define IOCTL_IPCTEST_EXEC_PACKET_DATA_LOOPBACK                 0x1
#define IOCTL_IPCTEST_EXEC_SHORT_MSG_LOOPBACK                   0x2
#define IOCTL_IPCTEST_EXEC_PACKET_DATA_WRITE_EX_CONT_LOOPBACK   0x5
#define IOCTL_IPCTEST_EXEC_PACKET_DATA_WRITE_EX_LINK_LOOPBACK   0x6
#define IOCTL_IPCTEST_EXEC_LOGGING_LOOPBACK                     0x4

#define IPCTEST_MAJOR                                   0
#define MAX_BUFFER_SIZE                                 512

struct ioctl_args {
	int iterations;
	unsigned short channel;
	unsigned short vchannel;
	unsigned short bytes;
	unsigned short message;
};

static int major_num = 0;
static struct class *ipc_tm_class;


static wait_queue_head_t write_queue, read_queue, notify_queue;
static bool read_done, write_done;

static void read_callback(HW_CTRL_IPC_READ_STATUS_T * status)
{
	DPRINTK("IPC: %d bytes read on channel nb %d\n", status->nb_bytes,
		status->channel->channel_nb);
	read_done = true;
	wake_up_interruptible(&read_queue);
}

static void write_callback(HW_CTRL_IPC_WRITE_STATUS_T * status)
{
	DPRINTK("IPC: %d bytes wrote on channel nb %d\n", status->nb_bytes,
		status->channel->channel_nb);
	write_done = true;
	wake_up_interruptible(&write_queue);
}

static void notify_callback(HW_CTRL_IPC_NOTIFY_STATUS_T * status)
{
	DPRINTK("IPC: Notify callback called from channel nb %d\n",
		status->channel->channel_nb);
	wake_up_interruptible(&notify_queue);
}

int check_data_integrity(char *buf1, char *buf2, int count)
{
	int result = 0;
	int i;

	for (i = 0; i < count; i++) {
		if (buf1[i] != buf2[i]) {
			printk("Corrupted data at %d wbuf = %d rbuf = %d\n",
			       i, buf1[i], buf2[i]);
			result = -1;
		}
	}
	return result;
}

int exec_open_close_test(unsigned long arg)
{
	HW_CTRL_IPC_OPEN_T config;
	HW_CTRL_IPC_CHANNEL_T *channel;
	int result;
	int i;

	channel = kmalloc(sizeof(HW_CTRL_IPC_CHANNEL_T), GFP_KERNEL);
	channel->channel_nb = ((struct ioctl_args *)arg)->channel;

	DPRINTK("IPC: opening and closing a SHORT MESSAGE IPC channel from "
		"kernel multiple times\n");

	config.index = channel->channel_nb;
	config.type = HW_CTRL_IPC_SHORT_MSG;
	config.read_callback = read_callback;
	config.write_callback = write_callback;
	config.notify_callback = notify_callback;
	kfree(channel);

	for (i = 0; i < 100; i++) {
		channel = hw_ctrl_ipc_open(&config);
		if (channel == 0) {
			DPRINTK("IPC: Unable to open virtual channel %d\n",
				channel->channel_nb);
			return -1;
		}

		result = hw_ctrl_ipc_close(channel);
		if (result != HW_CTRL_IPC_STATUS_OK) {
			DPRINTK("IPC: Unable to close virtual channel %d\n",
				channel->channel_nb);
			return -1;
		}
	}

	DPRINTK("IPC: open_close test OK \n");

	return 0;
}

int exec_short_message_loopback(unsigned long arg)
{
	HW_CTRL_IPC_OPEN_T config;
	unsigned short channel;
	int result = 0, i;
	int iterations;
	char wbuf[4];
	char rbuf[4];
	int message;
	HW_CTRL_IPC_CHANNEL_T *vchannel = NULL;

	channel = ((struct ioctl_args *)arg)->channel;
	message = ((struct ioctl_args *)arg)->message;
	iterations = ((struct ioctl_args *)arg)->iterations;

	DPRINTK("IPC: about to send %d messages on channel %d\n", iterations,
		channel);

	config.index = channel;
	config.type = HW_CTRL_IPC_SHORT_MSG;
	config.read_callback = read_callback;
	config.write_callback = write_callback;
	config.notify_callback = notify_callback;

	vchannel = hw_ctrl_ipc_open(&config);
	if (vchannel == 0) {
		DPRINTK("IPC: Unable to open virtual channel %d\n",
			vchannel->channel_nb);
		return -1;
	}

	memset(wbuf, 0, 4);
	memset(rbuf, 0, 4);

	for (i = 0; i < 4; i++) {
		wbuf[i] = (char)i;
	}

	i = 0;
	while (i < iterations) {
		write_done = false;
		read_done = false;
		result = hw_ctrl_ipc_write(vchannel, wbuf, 4);
		if (result == HW_CTRL_IPC_STATUS_ERROR) {
			DPRINTK("IPC: Error on hw_ctrl_ipc_write function\n");
			break;
		}

		wait_event_interruptible(write_queue, write_done);

		result = hw_ctrl_ipc_read(vchannel, rbuf, 4);
		if (result != HW_CTRL_IPC_STATUS_OK) {
			DPRINTK("IPC: Error on hw_ctrl_ipc_read function\n");
			break;
		}

		wait_event_interruptible(read_queue, read_done);

		DPRINTK("IPC: Received message # %d from channel %d\n", i,
			channel);

		if (check_data_integrity(wbuf, rbuf, 4) == -1) {
			break;
		}

		memset(rbuf, 0, 4);

		i++;
	}

	if (hw_ctrl_ipc_close(vchannel) != HW_CTRL_IPC_STATUS_OK) {
		DPRINTK("IPC: Error on hw_ctrl_ipc_close function\n");
		result = -1;
	}

	if (result == 0) {
		DPRINTK("TEST for Short Message channels OK\n");
	} else {
		DPRINTK("TEST for Short Message channels FAILED\n");
	}
	return result;
}

int exec_packet_data_loopback(unsigned long arg)
{
	HW_CTRL_IPC_OPEN_T config;
	int status = 0, i;
	int iterations;
	HW_CTRL_IPC_CHANNEL_T *vchannel = NULL;
	char *wbuf;
	char *rbuf;
	int bytes;

	bytes = ((struct ioctl_args *)arg)->bytes;
	iterations = ((struct ioctl_args *)arg)->iterations;

	wbuf = (char *)kmalloc(bytes, GFP_KERNEL);
	rbuf = (char *)kmalloc(bytes, GFP_KERNEL);

	DPRINTK("IPC: about to send %d bytes on channel 2\n", bytes);

	config.index = 0;
	config.type = HW_CTRL_IPC_PACKET_DATA;
	config.read_callback = read_callback;
	config.write_callback = write_callback;
	config.notify_callback = notify_callback;

	vchannel = hw_ctrl_ipc_open(&config);
	if (vchannel == 0) {
		DPRINTK("IPC: Unable to open virtual channel %d\n",
			vchannel->channel_nb);
		return -1;
	}

	memset(wbuf, 0, bytes);
	memset(rbuf, 0, bytes);

	for (i = 0; i < bytes; i++) {
		wbuf[i] = (char)i;
	}

	i = 0;
	while (i < iterations) {
		write_done = false;
		read_done = false;
		status = hw_ctrl_ipc_write(vchannel, wbuf, bytes);
		if (status == HW_CTRL_IPC_STATUS_ERROR) {
			DPRINTK("IPC: Error on hw_ctrl_ipc_write function\n");
			status = -1;
			break;
		}

		wait_event_interruptible(write_queue, write_done);

		status = hw_ctrl_ipc_read(vchannel, rbuf, bytes);
		if (status != HW_CTRL_IPC_STATUS_OK) {
			DPRINTK("IPC: Error on hw_ctrl_ipc_read function\n");
			status = -1;
			break;
		}

		wait_event_interruptible(read_queue, read_done);

		DPRINTK("IPC: Received message # %d from channel 2\n", i);

		if (check_data_integrity(wbuf, rbuf, bytes) == -1) {
			DPRINTK("IPC: TEST FAILED on channel %d iteration %d\n",
				vchannel->channel_nb, i);
			status = -1;
			break;
		}

		memset(rbuf, 0, bytes);
		i++;
	}

	if (hw_ctrl_ipc_close(vchannel) != HW_CTRL_IPC_STATUS_OK) {
		DPRINTK("IPC: Error on hw_ctrl_ipc_close function\n");
		status = -1;
	}

	kfree(wbuf);
	kfree(rbuf);
	if (status == 0) {
		DPRINTK("TEST for Packet Data channel OK\n");
	} else {
		DPRINTK("TEST for Packet Data channel FAILED\n");
	}

	return status;
}

int exec_packet_data_write_ex_cont_loopback(unsigned long arg)
{
	HW_CTRL_IPC_OPEN_T config;
	int status = 0, i;
	int iterations;
	HW_CTRL_IPC_CHANNEL_T *vchannel = NULL;
	HW_CTRL_IPC_WRITE_PARAMS_T write_buf;
	char *wbuf;
	char *rbuf;
	int bytes;

	bytes = ((struct ioctl_args *)arg)->bytes;
	iterations = ((struct ioctl_args *)arg)->iterations;

	wbuf = (char *)kmalloc(bytes, GFP_KERNEL);
	rbuf = (char *)kmalloc(bytes, GFP_KERNEL);

	DPRINTK("IPC: about to send %d bytes on channel 2\n", bytes);

	config.index = 0;
	config.type = HW_CTRL_IPC_PACKET_DATA;
	config.read_callback = read_callback;
	config.write_callback = write_callback;
	config.notify_callback = notify_callback;

	vchannel = hw_ctrl_ipc_open(&config);
	if (vchannel == 0) {
		DPRINTK("IPC: Unable to open virtual channel %d\n",
			vchannel->channel_nb);
		return -1;
	}

	memset(wbuf, 0, bytes);
	memset(rbuf, 0, bytes);

	for (i = 0; i < bytes; i++) {
		wbuf[i] = (char)i;
	}

	write_buf.ipc_memory_read_mode = HW_CTRL_IPC_MODE_CONTIGUOUS;
	write_buf.read.cont_ptr = (HW_CTRL_IPC_CONTIGUOUS_T *)
	    kmalloc(sizeof(HW_CTRL_IPC_CONTIGUOUS_T), GFP_KERNEL);
	write_buf.read.cont_ptr->data_ptr = wbuf;
	write_buf.read.cont_ptr->length = bytes;

	i = 0;
	while (i < iterations) {
		write_done = false;
		read_done = false;

		status = hw_ctrl_ipc_write_ex(vchannel, &write_buf);
		if (status == HW_CTRL_IPC_STATUS_ERROR) {
			DPRINTK
			    ("IPC:Error in hw_ctrl_ipc_write_ex function %d\n",
			     status);
			status = -1;
			break;
		}

		wait_event_interruptible(write_queue, write_done);

		status = hw_ctrl_ipc_read(vchannel, rbuf, bytes);
		if (status != HW_CTRL_IPC_STATUS_OK) {
			DPRINTK("IPC:Error on hw_ctrl_ipc_read function\n");
			status = -1;
			break;
		}

		wait_event_interruptible(read_queue, read_done);

		DPRINTK("IPC: Received message # %d from channel 2\n", i);

		if (check_data_integrity(wbuf, rbuf, bytes) == -1) {
			DPRINTK("IPC: TEST FAILED on channel %d iteration %d\n",
				vchannel->channel_nb, i);
			status = -1;
			break;
		}

		memset(rbuf, 0, bytes);
		i++;
	}

	if (hw_ctrl_ipc_close(vchannel) != HW_CTRL_IPC_STATUS_OK) {
		DPRINTK("IPC: Error on hw_ctrl_ipc_close function\n");
		status = -1;
	}
	write_buf.read.cont_ptr->data_ptr = NULL;
	kfree(write_buf.read.cont_ptr);
	kfree(wbuf);
	kfree(rbuf);
	if (status == 0) {
		DPRINTK
		    ("TEST for Contiguous write_ex with Packet Data chnl OK\n");
	} else {
		DPRINTK
		    ("TEST for Contiguous write_ex with Packet Data chnl FAILED\n");

	}

	return status;
}

int exec_packet_data_write_ex_link_loopback(unsigned long arg)
{
	HW_CTRL_IPC_OPEN_T config;
	int status = 0, i;
	int iterations;
	HW_CTRL_IPC_CHANNEL_T *vchannel = NULL;
	HW_CTRL_IPC_WRITE_PARAMS_T write_buf;
	char *wbuf;
	char *rbuf;
	int bytes;

	bytes = ((struct ioctl_args *)arg)->bytes;
	iterations = ((struct ioctl_args *)arg)->iterations;

	wbuf = (char *)kmalloc(bytes, GFP_KERNEL);
	rbuf = (char *)kmalloc(bytes, GFP_KERNEL);

	DPRINTK("IPC: about to send %d bytes on channel 2\n", bytes);

	config.index = 0;
	config.type = HW_CTRL_IPC_PACKET_DATA;
	config.read_callback = read_callback;
	config.write_callback = write_callback;
	config.notify_callback = notify_callback;

	vchannel = hw_ctrl_ipc_open(&config);
	if (vchannel == 0) {
		DPRINTK("IPC: Unable to open virtual channel %d\n",
			vchannel->channel_nb);
		return -1;
	}

	memset(wbuf, 0, bytes);
	memset(rbuf, 0, bytes);

	for (i = 0; i < bytes; i++) {
		wbuf[i] = (char)i;
	}

	write_buf.ipc_memory_read_mode = HW_CTRL_IPC_MODE_LINKED_LIST;
	write_buf.read.list_ptr = (HW_CTRL_IPC_LINKED_LIST_T *)
	    kmalloc(sizeof(HW_CTRL_IPC_LINKED_LIST_T), GFP_KERNEL);
	write_buf.read.list_ptr->data_ptr = wbuf;
	write_buf.read.list_ptr->length = bytes;
	write_buf.read.list_ptr->next = NULL;

	i = 0;
	while (i < iterations) {
		write_done = false;
		read_done = false;

		status = hw_ctrl_ipc_write_ex(vchannel, &write_buf);
		if (status == HW_CTRL_IPC_STATUS_ERROR) {
			DPRINTK("IPC:Error in hw_ctrl_ipc_write_ex function\n");
			status = -1;
			break;
		}

		wait_event_interruptible(write_queue, write_done);

		status = hw_ctrl_ipc_read(vchannel, rbuf, bytes);
		if (status != HW_CTRL_IPC_STATUS_OK) {
			DPRINTK("IPC:Error on hw_ctrl_ipc_read function\n");
			status = -1;
			break;
		}

		wait_event_interruptible(read_queue, read_done);

		DPRINTK("IPC: Received message # %d from channel 2\n", i);

		if (check_data_integrity(wbuf, rbuf, bytes) == -1) {
			DPRINTK("IPC: TEST FAILED on channel %d iteration %d\n",
				vchannel->channel_nb, i);
			status = -1;
			break;
		}

		memset(rbuf, 0, bytes);
		i++;
	}

	if (hw_ctrl_ipc_close(vchannel) != HW_CTRL_IPC_STATUS_OK) {
		DPRINTK("IPC: Error on hw_ctrl_ipc_close function\n");
		status = -1;
	}
	write_buf.read.list_ptr->data_ptr = NULL;
	kfree(write_buf.read.list_ptr);
	kfree(wbuf);
	kfree(rbuf);
	if (status == 0) {
		DPRINTK("TEST for Linked write_ex with Packet Data chnl OK\n");
	} else {
		DPRINTK("TEST for Linked write_ex with Packet Data chnl FAILED\n");
	}

	return status;
}

int exec_logging_loopback(unsigned long arg)
{
	return 0;
}

static int ipctest_open(struct inode *inode, struct file *filp)
{
	return 0;
}

static int ipctest_close(struct inode *inode, struct file *filp)
{
	unsigned int minor;
	minor = MINOR(inode->i_rdev);
	return 0;
}

static int ipctest_ioctl(struct inode *inode,
			 struct file *file,
			 unsigned int action, unsigned long arg)
{
	int result = 0;

	DPRINTK("IPC: IOCTL to execute: %d\n", action);

	switch (action) {
	case IOCTL_IPCTEST_EXEC_OPEN_CLOSE_TEST:
		result = exec_open_close_test(arg);
		break;

	case IOCTL_IPCTEST_EXEC_PACKET_DATA_LOOPBACK:
		result = exec_packet_data_loopback(arg);
		break;

	case IOCTL_IPCTEST_EXEC_SHORT_MSG_LOOPBACK:
		result = exec_short_message_loopback(arg);
		break;

	case IOCTL_IPCTEST_EXEC_PACKET_DATA_WRITE_EX_CONT_LOOPBACK:
		result = exec_packet_data_write_ex_cont_loopback(arg);
		break;

	case IOCTL_IPCTEST_EXEC_PACKET_DATA_WRITE_EX_LINK_LOOPBACK:
		result = exec_packet_data_write_ex_link_loopback(arg);
		break;

	case IOCTL_IPCTEST_EXEC_LOGGING_LOOPBACK:
		result = exec_logging_loopback(arg);
		break;

	default:
		DPRINTK("IPC: Unknown IOCTL: %d\n", action);
		return -1;
	}

	return result;
}

static struct file_operations ipctest_fops = {
	.owner = THIS_MODULE,
	//.read      = mxc_ipc_read,
	//.write     = mxc_ipc_write,
	.ioctl = ipctest_ioctl,
	.open = ipctest_open,
	.release = ipctest_close,
};

int __init ipctest_init_module(void)
{
	struct class_device *temp_class;
	int res = 0;

	res = register_chrdev(IPCTEST_MAJOR, "ipctest", &ipctest_fops);
	if (res >= 0) {
		DPRINTK("IPCTEST Driver Module Loaded\n");
	} else {
		DPRINTK("IPCTEST Driver Module is not Loaded successfully\n");
		return -1;
	}

	major_num = res;

	ipc_tm_class = class_create(THIS_MODULE, "ipctest");
	if (IS_ERR(ipc_tm_class)) {
		printk(KERN_ERR "Error creating ipctest class.\n");
		unregister_chrdev(major_num, "ipctest");
		class_device_destroy(ipc_tm_class, MKDEV(major_num, 0));
		return PTR_ERR(ipc_tm_class);
	}

	temp_class = class_device_create(ipc_tm_class, NULL,
					     MKDEV(major_num, 0), NULL,
					     "ipctest");
	if (IS_ERR(temp_class)) {
		printk(KERN_ERR "Error creating ipctest class device.\n");
		class_device_destroy(ipc_tm_class, MKDEV(major_num, 0));
		class_destroy(ipc_tm_class);
		unregister_chrdev(major_num, "ipctest");
		return -1;
	}

	init_waitqueue_head(&write_queue);
	init_waitqueue_head(&read_queue);
	init_waitqueue_head(&notify_queue);
	return 0;
}

static void ipctest_cleanup_module(void)
{
	unregister_chrdev(major_num, "ipctest");
	class_device_destroy(ipc_tm_class, MKDEV(major_num, 0));
	class_destroy(ipc_tm_class);

	DPRINTK("IPCTEST Driver Module Unloaded\n");
}

module_init(ipctest_init_module);
module_exit(ipctest_cleanup_module);

MODULE_AUTHOR("Freescale Semiconductor");
MODULE_DESCRIPTION("IPC driver");
MODULE_LICENSE("GPL");
