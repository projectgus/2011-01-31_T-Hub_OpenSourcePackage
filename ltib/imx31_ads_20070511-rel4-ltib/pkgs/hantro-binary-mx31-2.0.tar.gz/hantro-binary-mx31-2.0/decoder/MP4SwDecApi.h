/*------------------------------------------------------------------------------
--                                                                            --
--       This software is confidential and proprietary and may be used        --
--        only as expressly authorized by a licensing agreement from          --
--                                                                            --
--                            Hantro Products Oy.                             --
--                                                                            --
--      In the event of publication, the following notice is applicable:      --
--                                                                            --
--                   (C) COPYRIGHT 2004 HANTRO PRODUCTS OY                    --
--                            ALL RIGHTS RESERVED                             --
--                                                                            --
--         The entire notice above must be reproduced on all copies.          --
--                                                                            --
--------------------------------------------------------------------------------
--
--  Project  : 
--
--  Abstract : The API module user interface of the Decoder.
--
--------------------------------------------------------------------------------
--
--  Version control information, please leave untouched.
--
--  $RCSfile: MP4SwDecApi.h,v $
--  $Date: 2004/11/10 10:11:05 $
--  $Revision: 2.10 $
--
------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------

    Table of contents

    1. Include Headers

    2. Enumerations used as a return value or a parameter.
        2.1. API's return value enumerations.

    3. User Structures
        3.1. Structures for MP4SwDecDecode() parameters.
        3.2. Structures for information interchange with 
             DEC API and user application.

    4. Common defines

    5. Prototypes of Decoder API functions

------------------------------------------------------------------------------*/

#ifndef MP4SWDECAPI_H
#define MP4SWDECAPI_H

#ifdef __cplusplus
extern "C"
    {
#endif

/*------------------------------------------------------------------------------
    1. Include Headers
------------------------------------------------------------------------------*/

#include "basetype.h"

/*------------------------------------------------------------------------------
    2.1. API's return value enumerations.
------------------------------------------------------------------------------*/

    /* API return values */
    typedef enum
    {
        MP4SWDEC_OK = 0,
        MP4SWDEC_STRM_PROCESSED = 1,
        MP4SWDEC_VOP_RDY,
        MP4SWDEC_VOP_RDY_BUFF_NOT_EMPTY,
        MP4SWDEC_VOS_END,
        MP4SWDEC_HDRS_RDY,
        MP4SWDEC_HDRS_RDY_BUFF_NOT_EMPTY, 
        MP4SWDEC_PARAM_ERR = -1,
        MP4SWDEC_STRM_ERR = -2,
        MP4SWDEC_STRM_ERR_BUFF_NOT_EMPTY = -3,
        MP4SWDEC_NOT_INITIALIZED = -4, 
        MP4SWDEC_MEMFAIL = -5,
        MP4SWDEC_EVALUATION_LIMIT_EXCEEDED = -6
    } MP4SwDecRet;



/*------------------------------------------------------------------------------
    3.1. Structures for MP4SwDecDecode() parameters.
------------------------------------------------------------------------------*/

    /* typedef of the Decoder instance */
    typedef void *MP4SwDecInst; 

    /* Input structure */
    typedef struct
    {
        u8  *pStream;            /* Pointer to stream to be decoded       */
        u32  dataLen;            /* Number of bytes to be decoded         */
    } MP4SwDecInput;

    /* Timecode structure */
    typedef struct 
    {
        u32 hours;
        u32 minutes;
        u32 seconds;
        u32 timeIncr;
        u32 timeRes;
    } MP4SwTimeCode;

    /* Output structure */
    typedef struct
    {
        u32 *pOutputPicture;     /* Pointer to the recent decoded picture
                                    decoder output, YUV format		 */
        u32 nbrOfErrMBs;        /* Number of concealed MB's in last VOP  */
        MP4SwTimeCode timeCode;
    } MP4SwDecOutput;

/*------------------------------------------------------------------------------
    3.2. Structures for information interchange with DEC API 
         and user application.
------------------------------------------------------------------------------*/

    /* QP info structure */
    typedef struct
    {
        u8  vopQp;
        u32 *pQp;  
    } MP4SwDecQpInfo;

    /* Deblocking info structure */
    typedef struct
    {
        u8  vopQP;
        u8  *pYuvBuffer;
    } MP4SwDecDeblockingInfo;

    /* Stream information */
    typedef struct
    {
        u32 frameWidth;
        u32 frameHeight;
        u32 isShortVideo;
        u32 profileAndLevelIndication;
        u32 videoFormat;
        u32 videoRange;
        u32 vopNumber;
        u32 vopCodingType;
        u32 resyncMarkerDisable;
        u32 vopQp;
        u32 videoObjectLayerWidth;
        u32 videoObjectLayerHeight;
        u32 userDataVOSLen;
        u32 userDataVISOLen;
        u32 userDataVOLLen;
        u32 userDataGOVLen;
    } MP4SwDecInfo;
 
    /* User data type */
    typedef enum {
        USER_DATA_VOS = 0,
        USER_DATA_VISO,
        USER_DATA_VOL,
        USER_DATA_GOV
    } MP4SwDecUserDataType;
    
    /* User data configuration */
    typedef struct {
        MP4SwDecUserDataType userDataType;
        u8  *pUserDataVOS; 
        u32  userDataVOSMaxLen;
        u8  *pUserDataVISO;
        u32  userDataVISOMaxLen;
        u8  *pUserDataVOL;
        u32  userDataVOLMaxLen;
        u8  *pUserDataGOV;
        u32  userDataGOVMaxLen;
    } MP4SwDecUserConf;
    
    /* Version information */
    typedef struct 
    {
        u32 major;    /* Decoder API major version */
        u32 minor;    /* Dncoder API minor version */
    } MP4SwDecApiVersion;


/*------------------------------------------------------------------------------
    4. Definitions
------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
    5. Prototypes of Decoder API functions
------------------------------------------------------------------------------*/

    MP4SwDecRet MP4SwDecDecode(MP4SwDecInst     decInst, 
                               MP4SwDecInput    *pInput, 
                               MP4SwDecOutput   *pOutput);

    MP4SwDecRet MP4SwDecInit(MP4SwDecInst *decInst);

    MP4SwDecRet MP4SwDecGetInfo(MP4SwDecInst    decInst,
                                MP4SwDecInfo    *pDecInfo);

    void  MP4SwDecRelease(MP4SwDecInst decInst);

    MP4SwDecApiVersion MP4SwDecGetAPIVersion( void );

    MP4SwDecRet MP4SwDecGetQPs(MP4SwDecInst     pDecInst, 
                               MP4SwDecQpInfo   *pQpInfo);

    MP4SwDecRet MP4SwDecGetDeblockingInfo(MP4SwDecInst           pDecInst,
                                          MP4SwDecDeblockingInfo *pInfo);

    MP4SwDecRet MP4SwDecGetUserData(MP4SwDecInst        pDecInst,
                                    MP4SwDecUserConf    *pUserDataConfig);

    /* function prototype for API trace */
    void MP4SwDecTrace(char *);

    /* function prototype for memory allocation */
    void *MP4SwDecMalloc(unsigned int size);

    /* function prototype for memory free*/
    void MP4SwDecFree(void *ptr);

    /* function prototype for memset */
    void *MP4SwDecMemset(void *ptr, int c, unsigned int);
    
#ifdef __cplusplus
    }
#endif
    
#endif /* MP4SWDECAPI_H */

