/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mxc_init.c
 * 
 * @brief This file contains the initialization code of the basic hardware 
 * required for NANDboot to boot the Linux kernel
 * 
 * @ingroup Miniboot and NANDboot
 */

#include "mxc.h"
#include "mxc_uart.h"

#define MSDELAY(x)      ((x)*1000)
/*!
 * Register defines for Watchdog timer
 */
#define _reg_WDOG_WCR           (*((volatile U16 *)(WDOG_BASE + 0x00)))
#define _reg_WDOG_WSR           (*((volatile U16 *)(WDOG_BASE + 0x02)))
#define _red_WDOG_WRSR          (*((volatile U16 *)(WDOG_BASE + 0x04)))

#define  WDOG_WRE       0

/*!
 * This is the initialization function for Watchdog Timer.
 */

#if WDOG_EN==1
void mxc_wd_init(void)
{

#if defined(nandboot)
#if UNIT_TEST
	U32 *debug_addr = DEBUG_ADDR2;
#endif
#endif
	_reg_WDOG_WCR |= WDOG_TIMEOUT;

	/* Set WRE (4th bit) and SRS (5th bit) to 0 to generate 
	 * reset signal on timeout
	 */
	_reg_WDOG_WCR &= ~0x0018;

	_reg_WDOG_WCR |= 0x0004;	/* Enable Watchdog Timer */

#if defined(nandboot)
#if defined(UNIT_TEST)
	if (!(_reg_WDOG_WCR & 0x0400)) {
		*(debug_addr++) = 0x50;	/* error */
	} else {
		*(debug_addr++) = 0x70;	/* success */
	}

	if (_reg_WDOG_WCR & 0x0018) {
		*(debug_addr++) = 0x51;	/* error */
	} else {
		*(debug_addr++) = 0x71;	/* success */
	}

	if (!(_reg_WDOG_WCR & 0x0004)) {
		*(debug_addr++) = 0x52;	/* error */
	} else {
		*(debug_addr++) = 0x72;	/* success */
	}
#endif
#endif
}
#else
void mxc_wd_init(void)
{
}
#endif

/*!
 * This function is used to service the Watchdog Timer before it gets timeout.
 */
void mxc_wd_reset(void)
{
	if (_reg_WDOG_WSR & 0x0004) {	/* service only if WDOG enabled */
		_reg_WDOG_WSR = 0x5555;
		_reg_WDOG_WSR = 0xAAAA;
	}
}

/*!
 * This is helper sleep function which loops for approximately given number
 * usecs.
 *
 * @param       count     number of usec to wait loop
 */
void udelay(int count)
{
	volatile int i;

        for (i = 0; i < count; i++) {
	}
}

/*!
 * This function waits for input from user for few sec(6sec)
 *
 * @param       timeout   indicates the timeout or input from user
 *              1 -> Time out occured
 *              0->  Input from user
 *
 */
int  mxc_timeout(int timeout)
{
        unsigned int j;

        for (j = 0; j < MSDELAY(timeout); j++) {
                 udelay(100);
                 if(mxc_dataready()) {
                         return 0;
                 }
       }
       return 1;
}

