#ifndef HAL_PLATFORM_SETUP_H_
#define HAL_PLATFORM_SETUP_H_
/*
 *         File : hal_platform_setup.h
 *
 *        Platform specific code for MX31 platform.
 *        This code is derived from eCos files hal_platform_setup.h
 *        hal_mx31.h.
 */
/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */
#include "mx31ads.h"
#if !defined(__ASSEMBLER__) /* ADDED FOR COMPILATION */
#define SETUP_IOMUX()         setup_iomux() 

static void setup_iomux(void)
{
	int i;
        int dummy;
        
	writew(0x8023, PBC_BASE + PBC_BCTRL1);
	udelay(500);
	writew(0x00DF, PBC_BASE + PBC_BCTRL1_CLR);
	udelay(500);
	dummy = readb(0xB4000008);
	dummy = readb(0xB4000007);
	dummy = readb(0xB4000008);
	dummy = readb(0xB4000007);
	/* Uart 1 */
	writel(0x12121212, IOMUXC_BASE_ADDR + 0x7C);
	writel(0x12121212, IOMUXC_BASE_ADDR + 0x78);
	writel(0x12121212, IOMUXC_BASE_ADDR + 0x80);
	writel(0x12121212, IOMUXC_BASE_ADDR + 0x7C);

}
#endif

#if defined(__ASSEMBLER__) /* ADDED FOR COMPILATION */
#if !defined(NOHALASM)       

#define PLATFORM_SETUP1 _platform_setup1

/*#define PLATFORM_SETUP1 _platform_setup1
 * 
 * Platform setup macro
 *
 * This macro represents the initial startup code for the platform 
 */
        .macro   _platform_setup1
MX31_SETUP_START:
/*
 * - set correct memory timings & bus widths
 * - configure chip select lines
 * - init anything that could be undefined after reset
 */
/*
 * Step 1: ARM1136 init
 *       - invalidate I/D cache/TLB and drain write buffer;
 *       - invalidate L2 cache
 *       - unaligned access
 *       - branch predictions
*/
#ifdef TURN_OFF_IMPRECISE_ABORT
	mrs r0, cpsr
	bic r0, r0, #0x100
	msr cpsr, r0
#endif
 
	mov r0, #0
	mcr 15, 0, r0, c7, c7, 0        /* invalidate I cache and D cache */
	mcr 15, 0, r0, c8, c7, 0        /* invalidate TLBs */
	mcr 15, 0, r0, c7, c10, 4        /* Drain the write buffer */
 
	/* Also setup the Peripheral Port Remap register inside the core */
	ldr r0, =0x40000015        /* start from AIPS 2GB region */
	mcr p15, 0, r0, c15, c2, 4
 
	/* L2 Cache setup/invalidation/disable */
	/* Disable L2 cache first */
        ldr r0, =L2CC_BASE_ADDR
        ldr r2, [r0, #L2_CACHE_CTL_REG]
	bic r2, r2, #0x1
	str r2, [r0, #L2_CACHE_CTL_REG]
 
/* End of Step 1: ARM1136 init */
  
/*
 * Step 2: AIPI setup
 * Only setup MPROTx registers. The PACR default values are good.
 */
	/*
	 * Set all MPROTx to be non-bufferable, trusted for R/W,
	 * not forced to user-mode.
         */
	ldr r0, =AIPS1_CTRL_BASE_ADDR
	ldr r1, =0x77777777
	str r1, [r0, #0x00]
	str r1, [r0, #0x04]
	ldr r0, =AIPS2_CTRL_BASE_ADDR
	str r1, [r0, #0x00]
	str r1, [r0, #0x04]

	/*
	 * Clear the on and off peripheral modules Supervisor Protect bit
	 * for SDMA to access them. Did not change the AIPS control registers
	 * (offset 0x20) access type
	 */
	ldr r0, =AIPS1_CTRL_BASE_ADDR
	ldr r1, =0x0
	str r1, [r0, #0x40]
	str r1, [r0, #0x44]
	str r1, [r0, #0x48]
	str r1, [r0, #0x4C]
	ldr r1, [r0, #0x50]
	and r1, r1, #0x00FFFFFF
	str r1, [r0, #0x50]

	ldr r0, =AIPS2_CTRL_BASE_ADDR
	ldr r1, =0x0
	str r1, [r0, #0x40]
	str r1, [r0, #0x44]
	str r1, [r0, #0x48]
	str r1, [r0, #0x4C]
	ldr r1, [r0, #0x50]
	and r1, r1, #0x00FFFFFF
	str r1, [r0, #0x50]
/*
 * End of Step 2: AIPI setup
 */
 
/*
 * Step 3: MAX (Multi-Layer AHB Crossbar Switch) setup
 */
	ldr r0, =MAX_BASE_ADDR
	/* MPR - priority is M4 > M2 > M3 > M5 > M0 > M1 */
	ldr r1, =0x00302154
	str r1, [r0, #0x000]        /* for S0 */
	str r1, [r0, #0x100]        /* for S1 */
	str r1, [r0, #0x200]        /* for S2 */
	str r1, [r0, #0x300]        /* for S3 */
	str r1, [r0, #0x400]        /* for S4 */
	/* SGPCR - always park on last master */
	ldr r1, =0x10
	str r1, [r0, #0x010]        /* for S0 */
	str r1, [r0, #0x110]        /* for S1 */
	str r1, [r0, #0x210]        /* for S2 */
	str r1, [r0, #0x310]        /* for S3 */
	str r1, [r0, #0x410]        /* for S4 */
	/* MGPCR - restore default values */
	ldr r1, =0x0
	str r1, [r0, #0x800]        /* for M0 */
	str r1, [r0, #0x900]        /* for M1 */
	str r1, [r0, #0xA00]        /* for M2 */
	str r1, [r0, #0xB00]        /* for M3 */
	str r1, [r0, #0xC00]        /* for M4 */
	str r1, [r0, #0xD00]        /* for M5 */
/*
 * End of Step 3: MAX setup
 */
 
/*
 * Step 4: setup SPBA to allow all 3 masters to have access to these shared peripherals
 */
	ldr r0, =SPBA_CTRL_BASE_ADDR
	ldr r1, =0x7            /* allow all 3 masters access */
	/* Do nothing. The default setting is good */
/*
 * End of Step 4: SPBA setup
 */
 
/*
 * Step 5: Clock setup
 */
	ldr r0, =IPU_CTRL_BASE_ADDR
	ldr r1, =0x40
	str r1, [r0]
	
	/* RVAL/WVAL for L2 cache memory */
	ldr r0, =0x515
	ldr r1, =CLKCTL_BASE_ADDR
	str r0, [r1, #0x10]
	
	ldr r0, =CRM_MCU_BASE_ADDR
	ldr r1, =0x074B0B7D
	str r1, [r0, #CLKCTL_CCMR]   /* Select 26MHz clock as ref clk. SPLL for FIR */

	/* 532-133-66.5 */
	ldr r1, =PDR0_532_133_66
	str r1, [r0, #CLKCTL_PDR0]
	ldr r1, =MPCTL_PARAM_532
	str r1, [r0, #CLKCTL_MPCTL]
	
	/* Set UPLL=240MHz, USB=60MHz */
	ldr r1, =0x49FCFE7F
	str r1, [r0, #CLKCTL_PDR1]
	ldr r1, =UPCTL_PARAM_240
	str r1, [r0, #CLKCTL_UPCTL]
/*
 * End of Step 5: Clock setup
 */
 
/*
 * Step 6: M3IF/WEIM/ESDCTL setup
 */
	/* M3IF setup */
	/* Configure M3IF registers */
	ldr r1, =M3IF_BASE
	/*
	 * M3IF Control Register (M3IFCTL)
	 * MRRP[0] = L2CC0 not on priority list (0 << 0)      = 0x00000000
	 * MRRP[1] = L2CC1 not on priority list (0 << 0)      = 0x00000000
	 * MRRP[2] = MBX not on priority list (0 << 0)        = 0x00000000
	 * MRRP[3] = MAX1 not on priority list (0 << 0)       = 0x00000000
	 * MRRP[4] = SDMA not on priority list (0 << 0)       = 0x00000000
	 * MRRP[5] = MPEG4 not on priority list (0 << 0)      = 0x00000000
	 * MRRP[6] = IPU1 on priority list (1 << 6)           = 0x00000040
	 * MRRP[7] = IPU2 not on priority list (0 << 0)       = 0x00000000
	 *                                                     ------------
	 *                                                      0x00000040
	 */
	ldr r0, =0x00000040
	str r0, [r1]  /* M3IF control reg */
	
	/* WEIM setup */
	/* CS0 setup */
#ifdef FLASH_BURST_MODE_ENABLE
	/*
	 * Sync mode (AHB Clk = 133MHz ; BCLK = 44.3MHz):
	 */
	/* Flash reset command */
	
	ldr     r0, =CS0_BASE_ADDR
	ldr     r1, =0xF0F0
	strh    r1, [r0]
	/* 1st command */
	ldr     r2, =0xAAA
	add     r2, r2, r0
	ldr     r1, =0xAAAA
	strh    r1, [r2]
	/* 2nd command */
	ldr     r2, =0x554
	add     r2, r2, r0
	ldr     r1, =0x5555
	strh    r1, [r2]
	/* 3rd command */
	ldr     r2, =0xAAA
	add     r2, r2, r0
	ldr     r1, =0xD0D0
	strh    r1, [r2]
	/* Write flash config register */
	ldr     r1, =0x56CA
	strh    r1, [r2]
	/* Flash reset command */
	ldr     r1, =0xF0F0
	strh    r1, [r0]

	/* WEIM setup */
	ldr r0, =WEIM_BASE_ADDR
	ldr r1, =0x23524E80
	str r1, [r0, #CSCRU]
	ldr r1, =0x10000D03
	str r1, [r0, #CSCRL]
	ldr r1, =0x00720900
	str r1, [r0, #CSCRA]
#else
	/* Async flash mode */
	ldr r0, =WEIM_CTRL_CS0
	ldr r1, =0x11414C80
	str r1, [r0, #CSCRU]
	ldr r1, =0x30000D03
	str r1, [r0, #CSCRL]
	ldr r1, =0x00310800
	str r1, [r0, #CSCRA]
#endif

	/* CPLD on CS4 setup */
	ldr r0, =WEIM_CTRL_CS4
	ldr r1, =0x0000D843
	str r1, [r0, #CSCRU]
	ldr r1, =0x22252521
	str r1, [r0, #CSCRL]
	ldr r1, =0x22220A00
	str r1, [r0, #CSCRA]
 
init_sdram:  /* Get here only when not boot out of SDRAM */
	/*
	 * Disable maximum drive strength SDRAM/DDR lines by clearing DSE1 bits
	 * in SW_PAD_CTL registers
	 */
	
	/* SDCLK */
	ldr r1, =(IOMUXC_BASE_ADDR + 0x26C)
	ldr r0, [r1]
	bic r0, r0, #(1 << 12)
	str r0, [r1]
	
	/* CAS */
	ldr r1, =(IOMUXC_BASE_ADDR + 0x270)
	ldr r0, [r1]
	bic r0, r0, #(1 << 22)
	str r0, [r1]

	/* RAS */
	ldr r1, =(IOMUXC_BASE_ADDR + 0x274)
	ldr r0, [r1]
	bic r0, r0, #(1 << 2)
	str r0, [r1]

	/* CS2 (CSD0) */
	ldr r1, =(IOMUXC_BASE_ADDR + 0x27C)
	ldr r0, [r1]
	bic r0, r0, #(1 << 22)
	str r0, [r1]

	/* DQM3 */
	ldr r1, =(IOMUXC_BASE_ADDR + 0x284)
	ldr r0, [r1]
	bic r0, r0, #(1 << 22)
	str r0, [r1]

	/* DQM2, DQM1, DQM0, SD31-SD0, A25-A0, MA10 (0x288..0x2DC) */
	ldr r1, =(IOMUXC_BASE_ADDR + 0x288)
	ldr r2, =22     /* (0x2E0 - 0x288) / 4 = 22 */

pad_loop:
	ldr r0, [r1]
	bic r0, r0, #(1 << 22)
	bic r0, r0, #(1 << 12)
	bic r0, r0, #(1 << 2)
	str r0, [r1]
	add r1, r1, #4
	subs r2, r2, #0x1
	bne pad_loop

	/* Assuming DDR memory first */
	ldr r3, =0x82226080     /* 32 bit memory */
	init_ddr_sdram
	/* Testing if it is truly DDR */
	ldr r1, =SDRAM_COMPARE_CONST1
	ldr r0, =SDRAM_BASE_ADDR
	str r1, [r0]
	ldr r2, =SDRAM_COMPARE_CONST2
	str r2, [r0, #0x4]
	ldr r2, [r0]
	cmp r1, r2
	beq HWInitialise_skip_SDRAM_setup

	ldr r3, =0x82216080     /* 16 bit memory */
	init_ddr_sdram
	/* Testing if it is truly DDR */
	ldr r1, =SDRAM_COMPARE_CONST1
	ldr r0, =SDRAM_BASE_ADDR
	str r1, [r0]
	ldr r2, =SDRAM_COMPARE_CONST2
	str r2, [r0, #0x4]
	ldr r2, [r0]
	cmp r1, r2
	beq HWInitialise_skip_SDRAM_setup

	/* Reach here ONLY when SDR */
	ldr r3, =0x82126180     /* 32 bit memory */
	init_sdr_sdram
	/* Still test to make sure SDR */
	ldr r1, =SDRAM_COMPARE_CONST1
	ldr r0, =SDRAM_BASE_ADDR
	str r1, [r0]
	ldr r2, =SDRAM_COMPARE_CONST2
	str r2, [r0, #0x4]
	ldr r2, [r0]
	cmp r1, r2
	beq HWInitialise_skip_SDRAM_setup

	ldr r3, =0x82116180     /* 16 bit memory */
	init_sdr_sdram
	/* Still test to make sure SDR */
	ldr r1, =SDRAM_COMPARE_CONST1
	ldr r0, =SDRAM_BASE_ADDR
	str r1, [r0]
	ldr r2, =SDRAM_COMPARE_CONST2
	str r2, [r0, #0x4]
	ldr r2, [r0]
	cmp r1, r2
	beq HWInitialise_skip_SDRAM_setup

	/* Reach hear means memory setup problem. Try to 
	 * increase the HCLK divider */
	ldr r0, =CRM_MCU_BASE_ADDR
	ldr r1, [r0, #CLKCTL_PDR0]
	and r2, r1, #0x38
	cmp r2, #0x38
	beq loop_forever
	add r1, r1, #0x8
	str r1, [r0, #CLKCTL_PDR0]
	b init_sdram

loop_forever:
	b loop_forever  /* shouldn't get here */
 
HWInitialise_skip_SDRAM_setup:
 
/*
 * End of Step 7: M3IF/WEIM/ESDCTL setup
 */
HWInitialise_skip_SDRAM_copy:
 
skip_dsp_reset:
/* End of DSP reset */
 
NAND_ClockSetup:
 
	.endm

     .macro  init_ddr_sdram
	ldr r0, =ESDCTL_BASE
	ldr r2, =SDRAM_BASE_ADDR
	ldr r1, =0x0075E73A
	str r1, [r0, #0x4]
	ldr r1, =0x2            /* reset  */
	str r1, [r0, #0x10]
	ldr r1, =0x4            /* DDR  */
	str r1, [r0, #0x10]

	/* Hold for more than 200ns */
	ldr r1, =0x10000
 1:
	subs r1, r1, #0x1
	bne 1b
	ldr r1, =0x92100000
	str r1, [r0]
	ldr r1, =0x12344321
	ldr r12, =0x80000F00
	str r1, [r12]
	ldr r1, =0xA2100000
	str r1, [r0]
	ldr r1, =0x12344321
	str r1, [r2]
	str r1, [r2]

	ldr r1, =0xB2100000
	str r1, [r0]
	ldr r1, =0xDA
	strb r1, [r2, #0x33]
	ldr r1, =0xFF
	ldr r12, =0x81000000
	strb r1, [r12]
	str r3, [r0]
	ldr r1, =0xDEADBEEF
	str r1, [r2]
	ldr r1, =0x0000000C
	str r1, [r0, #0x10]
     .endm
 
 /* SDR SDRAM setup
  * r3 = value for ESDCTL0 
  */
     .macro  init_sdr_sdram
 /* 
  * Do nothing as the ipl is already very large
  */
     .endm

#endif  /* !defined (NOHALASM) */
#endif  /* defined(__ASSEMBLER__) */
#endif /* MXC_SETUP_MX31_H_ */

