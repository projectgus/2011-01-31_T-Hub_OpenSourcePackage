/* $Header: /u/linuxdev/LINUX2.6/misc/source/test/ltp_tests/lib/get_high_address.c,v 1.1 2004/07/21 09:10:41 rb878c Exp $ */

/*
 *	(C) COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED PROPRIETARY INFORMATION.
 *	ALL RIGHTS RESERVED.
 */

#include <unistd.h> 

char *
get_high_address()
{
       return (char *)sbrk(0) + (4 * getpagesize());
}
