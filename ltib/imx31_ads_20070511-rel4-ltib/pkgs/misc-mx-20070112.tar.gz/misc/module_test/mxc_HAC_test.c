/*
 * Copyright 2005-2006 Freescale Semiconductor, Inc. All rights reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*
 * General Include Files
 */
#include <linux/config.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <asm/uaccess.h>
#include "../include/mxc_test.h"
/*
 * Driver specific include files
 */
#include <asm/arch/mxc_i2c.h>
#include <asm/arch/mxc_pm.h>
#include <asm/arch/mxc_security_api.h>
#include <asm/arch/clock.h>
#include <asm/arch/gpio.h>
ulong *gtempu32ptr;
static struct class *mxc_test_class;

static int mxc_test_open(struct inode *inode, struct file *filp)
{
	return 0;
}

static ssize_t mxc_test_read(struct file *file, char *buf, size_t count,
			     loff_t * ppos)
{
	return 0;
}

static ssize_t mxc_test_write(struct file *filp, const char *buf, size_t count,
			      loff_t * ppos)
{
	return 0;
}

static int mxc_test_ioctl(struct inode *inode, struct file *file,
			  unsigned int cmd, unsigned long arg)
{
	ulong *tempu32ptr, tempu32, i = 0;

#ifndef CONFIG_ARCH_MX3
#ifdef CONFIG_MXC_SECURITY_HAC
	ulong hac_length1 = 0x01, hac_length2 =
	    0x01, *hac_memdata1, *hac_memdata2;
	ulong hacc_phyaddr1, hacc_phyaddr2, rem1, rem2;
	hac_hash_rlt hash_res;
	ulong hac_config, hac_continue;
#endif				/* CONFIG_MXC_SECURITY_HAC */
#endif				/* CONFIG_ARCH_MX3 */

	tempu32 = (ulong) (*(ulong *) arg);
	tempu32ptr = (ulong *) arg;

	switch (cmd) {
	case MXCTEST_HAC_START_HASH:
#ifdef CONFIG_MXC_SECURITY_HAC
#ifdef CONFIG_ARCH_MX3
		printk("HAC TEST DRV: HAC Module is not supported in MX31.\n");
		break;
#endif
#else
		printk("HAC TEST DRV: HAC Module is not supported.\n");
		break;
#endif

	case MXCTEST_HAC_STATUS:
#ifdef CONFIG_MXC_SECURITY_HAC
#ifdef  CONFIG_ARCH_MX3
		printk("HAC TEST DRV: HAC Module is not supported in MX31.\n");
		break;
#endif
#else
		printk("HAC TEST DRV: HAC Module is not supported.\n");
		break;
#endif

	default:
		printk("MXC TEST IOCTL %d not supported.\n", cmd);
		break;
	}
	return -EINVAL;
}

static int mxc_test_release(struct inode *inode, struct file *filp)
{
	return 0;
}

static struct file_operations mxc_test_fops = {
      owner:THIS_MODULE,
      open:mxc_test_open,
      release:mxc_test_release,
      read:mxc_test_read,
      write:mxc_test_write,
      ioctl:mxc_test_ioctl,
};

static int __init mxc_test_init(void)
{
	struct class_device *temp_class;
	int res;

	res =
	    register_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test", &mxc_test_fops);

	if (res < 0) {
		printk(KERN_WARNING "MXC Test: unable to register the dev\n");
		return res;
	}

	mxc_test_class = class_create(THIS_MODULE, "mxc_test");
	if (IS_ERR(mxc_test_class)) {
		printk(KERN_ERR "Error creating mxc_test class.\n");
		unregister_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test");
		class_device_destroy(mxc_test_class, MKDEV(MXC_TEST_MODULE_MAJOR, 0));
		return PTR_ERR(mxc_test_class);
	}

	temp_class = class_device_create(mxc_test_class, NULL,
					     MKDEV(MXC_TEST_MODULE_MAJOR, 0), NULL,
					     "mxc_test");
	if (IS_ERR(temp_class)) {
		printk(KERN_ERR "Error creating mxc_test class device.\n");
		class_device_destroy(mxc_test_class, MKDEV(MXC_TEST_MODULE_MAJOR, 0));
		class_destroy(mxc_test_class);
		unregister_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test");
		return -1;
	}

	return 0;
}

static void __exit mxc_test_exit(void)
{
	unregister_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test");
	class_device_destroy(mxc_test_class, MKDEV(MXC_TEST_MODULE_MAJOR, 0));
	class_destroy(mxc_test_class);
}

module_init(mxc_test_init);
module_exit(mxc_test_exit);

MODULE_DESCRIPTION("Test Module for MXC drivers");
MODULE_LICENSE("GPL");
