/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All rights reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */


/*
 * General Include Files
 */
#include <linux/config.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <asm/uaccess.h>
#include "../include/mxc_test.h"
/*
 * Driver specific include files
 */
#include <asm/arch/mxc_i2c.h>
#include <asm/arch/mxc_pm.h>
#include <asm/arch/mxc_security_api.h>
#include <asm/arch/clock.h>
#include <asm/arch/gpio.h>
#include <../drivers/mxc/mc13783_legacy/module/mc13783_power.h>
ulong *gtempu32ptr;
static struct class *mxc_test_class;

static int mxc_test_open(struct inode *inode, struct file *filp)
{
	return 0;
}

static ssize_t mxc_test_read(struct file *file, char *buf, size_t count,
			     loff_t * ppos)
{
	return 0;
}

static ssize_t mxc_test_write(struct file *filp, const char *buf, size_t count,
			      loff_t * ppos)
{
	return 0;
}

static int mxc_i2c_read_test(mxc_i2c_test * arg)
{
	mxc_i2c_test i2c_struct;
	char buf[32];
	char reg[32];
	int ret;

	copy_from_user(&i2c_struct, arg, sizeof(i2c_struct));
	copy_from_user(reg, i2c_struct.reg, i2c_struct.reg_size);
	copy_from_user(buf, i2c_struct.buf, i2c_struct.buf_size);

	ret = mxc_i2c_read(i2c_struct.bus, i2c_struct.slave_addr, reg,
			   i2c_struct.reg_size, buf, i2c_struct.buf_size);
	copy_to_user(i2c_struct.buf, buf, i2c_struct.buf_size);

	return ret;
}

static int mxc_i2c_write_test(mxc_i2c_test * arg)
{
	mxc_i2c_test i2c_struct;
	char buf[32];
	char reg[32];

	//printk("I2C Write IOCTL\n");
	copy_from_user(&i2c_struct, arg, sizeof(i2c_struct));
	copy_from_user(reg, i2c_struct.reg, i2c_struct.reg_size);
	copy_from_user(buf, i2c_struct.buf, i2c_struct.buf_size);

	//printk("WRITE DATA=%x to REGISTER=%x\n", buf[0], reg[0]);

	return mxc_i2c_write(i2c_struct.bus, i2c_struct.slave_addr, reg,
			     i2c_struct.reg_size, buf, i2c_struct.buf_size);
}

static int mxc_call_intscale(mxc_pm_test * arg)
{
	int result;

	printk("============== INT Scale IOCTL ==============\n");
	printk("Calling Integer Scaling \n");
	result = mxc_pm_intscale(arg->armfreq, arg->ahbfreq, arg->ipfreq);
	printk("The result is %d \n", result);
	return 0;
}

static int mxc_call_pllscale(mxc_pm_test * arg)
{
	int result;

	printk("============== PLL Scale IOCTL ==============\n");
	printk("Calling PLL Scaling \n");
	result = mxc_pm_pllscale(arg->armfreq, arg->ahbfreq, arg->ipfreq);
	printk("The result is %d \n", result);
	return 0;
}

static int mxc_call_dvfs(mxc_pm_test * arg)
{
	int result;

	printk("============== INT/PLL Scale IOCTL ==============\n");
	result = mxc_pm_dvfs(arg->armfreq, arg->ahbfreq, arg->ipfreq);
	printk("The result is %d \n", result);
	return 0;
}

static int mxc_call_ckohsel(mxc_pm_test * arg)
{
	int result = 0;

	printk("============= CKOH SEL IOCTL ================\n");
	switch (arg->ckoh) {
	case CKOH_AP_SEL:
		mxc_set_clock_output(CKOH, CPU_CLK, 10);
		break;
	case CKOH_AHB_SEL:
		mxc_set_clock_output(CKOH, AHB_CLK, 10);
		break;
	case CKOH_IP_SEL:
		mxc_set_clock_output(CKOH, IPG_CLK, 1);
		break;
	}
	printk("The result is %d \n", result);
	return 0;
}

#if defined(CONFIG_ARCH_MX3)
static int mxc_call_lowpower(mxc_pm_test * arg)
{
	printk("============= Low-Power mode IOCTL ============\n");
	switch (arg->lpmd) {
	case 1:
		printk("To Test WAIT mode\n");
		mxc_pm_lowpower(WAIT_MODE);
		break;
	case 2:
		printk("To Test DOZE mode\n");
		mxc_pm_lowpower(DOZE_MODE);
		break;
	case 3:
		printk("To Test STOP mode\n");
		mxc_pm_lowpower(STOP_MODE);
		break;
	case 4:
		printk("To Test DSM mode\n");
		mxc_pm_lowpower(DSM_MODE);
		break;
	}
	return 0;
}
#else
static int mxc_call_lowpower(mxc_pm_test * arg)
{
	printk("============= Low-Power mode IOCTL ============\n");
	switch (arg->lpmd) {
	case 1:
		printk("To Test WAIT mode\n");
		mxc_pm_lowpower(WAIT_MODE);
		break;
	case 2:
		printk("To Test STOP mode\n");
		mxc_pm_lowpower(STOP_MODE);
		break;
	case 3:
		printk("To Test DSM mode\n");
		mxc_pm_lowpower(DSM_MODE);
		break;
	}
	return 0;
}
#endif

static int mxc_call_pmic_high(void)
{
	struct t_switcher_conf sconfa;
	printk("Configuring MC13783 for Hi (1.6V) voltage \n");

	/* Configure MC13783 regulator */
	/* get the current configuration */
	mc13783_power_get_switcher(SW_SW1A, &sconfa);
	/* change from current configuration */
	sconfa.sw_setting = MXC_PMIC_1_6_VOLT;
	sconfa.sw_setting_dvs = MXC_PMIC_1_6_VOLT;
	sconfa.sw_setting_standby = MXC_PMIC_1_0_VOLT;
	sconfa.sw_dvs_speed = MXC_PMIC_DVS_SPEED;
	mc13783_power_conf_switcher(SW_SW1A, &sconfa);

	return 0;
}

static int mxc_call_pmic_low(void)
{
	struct t_switcher_conf sconfa;
	printk("Configuring MC13783 for Lo (1.2V) voltage \n");

	/* Configure MC13783 regulator */
	/* get the current configuration */
	mc13783_power_get_switcher(SW_SW1A, &sconfa);
	/* change from current configuration */
	sconfa.sw_setting = MXC_PMIC_1_2_VOLT;
	sconfa.sw_setting_dvs = MXC_PMIC_1_2_VOLT;
	sconfa.sw_setting_standby = MXC_PMIC_1_0_VOLT;
	sconfa.sw_dvs_speed = MXC_PMIC_DVS_SPEED;
	mc13783_power_conf_switcher(SW_SW1A, &sconfa);

	return 0;
}

static int mxc_call_pmic_hilo(void)
{
	struct t_switcher_conf sconfa;
	printk("Configuring MC13783 for Lo (1.2V) and Hi (1.6V) voltage \n");

	/* Configure MC13783 regulator */
	/* get the current configuration */
	mc13783_power_get_switcher(SW_SW1A, &sconfa);
	/* change from current configuration */
	sconfa.sw_setting = MXC_PMIC_1_6_VOLT;
	sconfa.sw_setting_dvs = MXC_PMIC_1_2_VOLT;
	sconfa.sw_setting_standby = MXC_PMIC_1_0_VOLT;
	sconfa.sw_dvs_speed = MXC_PMIC_DVS_SPEED;
	mc13783_power_conf_switcher(SW_SW1A, &sconfa);

	return 0;
}

static int mxc_test_ioctl(struct inode *inode, struct file *file,
			  unsigned int cmd, unsigned long arg)
{
#ifdef CONFIG_MXC_SECURITY_RNGA
	unchar tempu8;
	ulong rnga_rand, rnga_config;
	ulong *random_data;
#endif				/* CONFIG_MXC_SECURITY_RNGA */
	ulong *tempu32ptr, tempu32, i = 0;

#ifndef CONFIG_ARCH_MX3
#ifdef CONFIG_MXC_SECURITY_HAC
	ulong hac_length1 = 0x01, hac_length2 =
	    0x01, *hac_memdata1, *hac_memdata2;
	ulong hacc_phyaddr1, hacc_phyaddr2, rem1, rem2;
	hac_hash_rlt hash_res;
	ulong hac_config, hac_continue;
#endif				/* CONFIG_MXC_SECURITY_HAC */
#endif				/* CONFIG_ARCH_MX3 */

	ulong rtic_length1 = 0x01, *rtic_memdata1;
	ulong rtic_memdata2, rtic_rem;
	ulong rtic_config, rtic_run_config, rtic_config_mode, rtic_int,
	    rtic_result;
	rtic_hash_rlt rtic_res;
	unchar irq_en = 0x01;
	tempu32 = (ulong) (*(ulong *) arg);
	tempu32ptr = (ulong *) arg;

	switch (cmd) {
	case MXCTEST_I2C_READ:
		return mxc_i2c_read_test((mxc_i2c_test *) arg);
	case MXCTEST_I2C_WRITE:
		return mxc_i2c_write_test((mxc_i2c_test *) arg);
	case MXCTEST_I2C_CSICLKENB:
		i = mxc_get_clocks_parent(CSI_BAUD) / 32000000;
		if ((mxc_get_clocks_parent(CSI_BAUD) / i) > 32000000) {
			i++;
		}
		mxc_set_clocks_div(CSI_BAUD, 2 * i);
		mxc_clks_enable(CSI_BAUD);
		msleep(10);
		break;
	case MXCTEST_I2C_CSICLKDIS:
		mxc_clks_disable(CSI_BAUD);
		break;

	case MXCTEST_PM_INTSCALE:
		return mxc_call_intscale((mxc_pm_test *) arg);
	case MXCTEST_PM_PLLSCALE:
		return mxc_call_pllscale((mxc_pm_test *) arg);

	case MXCTEST_PM_INT_OR_PLL:
		return mxc_call_dvfs((mxc_pm_test *) arg);

	case MXCTEST_PM_CKOH_SEL:
		return mxc_call_ckohsel((mxc_pm_test *) arg);

	case MXCTEST_PM_LOWPOWER:
		return mxc_call_lowpower((mxc_pm_test *) arg);

	case MXCTEST_PM_PMIC_HIGH:
		return mxc_call_pmic_high();
	case MXCTEST_PM_PMIC_LOW:
		return mxc_call_pmic_low();
	case MXCTEST_PM_PMIC_HILO:
		return mxc_call_pmic_hilo();

	case MXCTEST_RNGA_CONFIGURE:
#ifdef CONFIG_MXC_SECURITY_RNGA
		printk("RNGA TEST DRV: Configuring RNGA.\n");
		rnga_config = rnga_configure();
		if (rnga_config == RNGA_SUCCESS) {
			RNGA_DEBUG("RNGA TEST DRV: Configuring RNGA module is "
				   "success.\n");
		} else if (rnga_config == RNGA_FAILURE) {
			RNGA_DEBUG("RNGA TEST DRV: Configuring RNGA Module is "
				   "failure.\n");
		}
		return rnga_config;
#else
		printk("RNGA TEST DRV: RNGA Module is not supported.\n");
		break;
#endif

	case MXCTEST_RNGA_GET_RAND:
#ifdef CONFIG_MXC_SECURITY_RNGA
		printk("RNGA TEST DRV: Generate random number\n");
		random_data = (ulong *) kmalloc(sizeof(ulong), GFP_KERNEL);
		rnga_rand = rnga_get_rand(random_data);
		if (rnga_rand == 0) {
			printk("RNGA TEST DRV: Random number generated is:"
			       "0x%08lX\n", *random_data);
			printk("RNGA TEST DRV: FIFO Depth level: 0x%08X\n",
			       rnga_get_fifo_level());
		} else {
			printk("RNGA TEST DRV: Failure in random number \
                                generation.\n");
		}
		return 0;
#else
		printk("RNGA TEST DRV: RNGA Module is not supported.\n");
		break;
#endif

	case MXCTEST_RNGA_SET_ENTROPY:
#ifdef CONFIG_MXC_SECURITY_RNGA
		printk("RNGA TEST DRV: Setting Entropy register a new"
		       "value\n");
		rnga_seed_rand(tempu32);
		printk("RNGA TEST DRV: RNGA set to new Entropy value %lu",
		       tempu32);
		return 0;
#else
		printk("RNGA TEST DRV: RNGA Module is not supported.\n");
		break;
#endif

	case MXCTEST_RNGA_PWR_DOWN_MODE:
#ifdef CONFIG_MXC_SECURITY_RNGA
		printk("RNGA TEST DRV: Putting RNGA to low power mode\n");
		rnga_sleep();
		return 0;
#else
		printk("RNGA TEST DRV: RNGA Module is not supported.\n");
		break;
#endif

	case MXCTEST_RNGA_GET_STATUS:
#ifdef CONFIG_MXC_SECURITY_RNGA
		printk("RNGA TEST DRV: Getting the status of RNGA.\n");
		printk("RNGA TEST DRV: Status of RNGA = 0x%08lX\n",
		       rnga_get_status());
		return 0;
#else
		printk("RNGA TEST DRV: RNGA Module is not supported.\n");
		break;
#endif

	case MXCTEST_RNGA_GET_FIFO_INFO:
#ifdef CONFIG_MXC_SECURITY_RNGA
		printk("RNGA TEST DRV: Getting the status of RNGA.\n");
		printk("RNGA TEST DRV: Getting the number of data words in "
		       "FIFO.\n");
		tempu8 = rnga_get_fifo_level();
		printk("RNGA TEST DRV: Total number of words in FIFO:"
		       "0x%02X\n", tempu8);
		return tempu8;
#else
		printk("RNGA TEST DRV: RNGA Module is not supported.\n");
		break;
#endif

	case MXCTEST_RNGA_GET_FIFO_SIZE:
#ifdef CONFIG_MXC_SECURITY_RNGA
		printk("RNGA TEST DRV: Getting the size of the FIFO.\n");
		tempu8 = rnga_get_fifo_size();
		printk("RNGA TEST DRV: Total size of FIFO is: "
		       "0x%02X words\n", tempu8);
		return tempu8;
#else
		printk("RNGA TEST DRV: RNGA Module is not supported.\n");
		break;
#endif

	case MXCTEST_RNGA_NORMAL_MODE:
#ifdef CONFIG_MXC_SECURITY_RNGA
		printk("RNGA TEST DRV: Setting RNGA in Normal Mode.\n");
		rnga_normal();
		return 0;
#else
		printk("RNGA TEST DRV: RNGA Module is not supported.\n");
		break;
#endif

	case MXCTEST_HAC_START_HASH:
#ifdef CONFIG_MXC_SECURITY_HAC
#ifdef CONFIG_ARCH_MX3
		printk("HAC TEST DRV: HAC Module is not supported in MX31.\n");
		break;
#endif
#else
		printk("HAC TEST DRV: HAC Module is not supported.\n");
		break;
#endif

	case MXCTEST_HAC_STATUS:
#ifdef CONFIG_MXC_SECURITY_HAC
#ifdef  CONFIG_ARCH_MX3
		printk("HAC TEST DRV: HAC Module is not supported in MX31.\n");
		break;
#endif
#else
		printk("HAC TEST DRV: HAC Module is not supported.\n");
		break;
#endif

	case MXCTEST_RTIC_ONETIME_TEST:
		printk("RTIC TEST DRV: Parameters received from user"
		       "space:\n");
		printk("RTIC TEST DRV: Parameter1 0x%08lX\n",
		       *(tempu32ptr + 0));
		printk("RTIC TEST DRV: Parameter2 0x%08lX\n",
		       *(tempu32ptr + 1));
		rtic_length1 = *(tempu32ptr + 1);
		if ((rtic_rem = ((ulong) rtic_length1 % 4)) != 0) {
			rtic_length1 = ((ulong) rtic_length1 + 4 - rtic_rem);
		}
		/* Allocating memory to copy user data to kernel memory */
		printk("RTIC TEST DRV: Allocating memory for copying the "
		       "data to be hashed.\n");
		rtic_memdata1 = (ulong *) kmalloc(sizeof(ulong) *
						  (rtic_length1 + 1),
						  GFP_KERNEL);

		RTIC_DEBUG("RTIC TEST DRV: Converting Virtual to Physical"
			   "Addr\n");
		rtic_memdata2 = virt_to_phys(rtic_memdata1);

		RTIC_DEBUG("RTIC TEST DRV: Virtual address 0x%08lX\n",
			   (ulong) rtic_memdata1);
		RTIC_DEBUG("RTIC TEST DRV: Physical address 0x%08lX\n",
			   rtic_memdata2);
		/* Physical address 64 byte alignment */
		if ((rtic_rem = ((ulong) rtic_memdata2 % 4)) != 0) {
			rtic_memdata2 = ((ulong) rtic_memdata2 + 4 - rtic_rem);
		}

		/* Copying 1st memory block from user space to kernel space */
		/* 1 block of data is 512 bytes */
		printk("RTIC TEST DRV: Copying data from user space.\n");
		i = copy_from_user(rtic_memdata1, (ulong *) * tempu32ptr,
				   rtic_length1 * 4);
		if (i != 0) {
			RTIC_DEBUG("RTIC TEST DRV: Couldn't copy %lu bytes of"
				   "data from user space\n", i);
			return -EFAULT;
		}
		printk("RTIC TEST DRV: Block lengths received from user:\n"
		       "Block Length 1: 0x%06lX\n", rtic_length1);
		printk("RTIC TEST DRV: Data received from user space:\n"
		       "Mem block 1: \n");
		tempu32 = rtic_length1;
		for (i = 0; i < tempu32; i++) {
			printk("0x%08lX ", *(rtic_memdata1 + i));
		}
		/* Configure for start address and blk length */
		RTIC_DEBUG("\nRTIC TEST DRV: Configuring address and length\n");
		rtic_config = rtic_configure_mem_blk((ulong) rtic_memdata2,
						     rtic_length1, RTIC_A1);
		if (rtic_config == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring memory block "
				   "of RTIC is success.\n");
		} else if (rtic_config == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring memory block "
				   "of RTIC is failure.\n");
			goto rtic_out;
		}
		/* DMA Throttle reg is set to 0x00 during boot time mode. */
		rtic_hash_once_dma_throttle();
		/* Configuring the ONE-TIME Hashing */
		printk("\nRTIC TEST DRV: Configuring ONE-TIME HASH.\n");
		rtic_config_mode = rtic_configure_mode(RTIC_ONE_TIME, RTIC_A1);
		if (rtic_config_mode == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring "
				   "of RTIC is success.\n");
		} else if (rtic_config_mode == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring  "
				   "of RTIC is failure.\n");
			goto rtic_out;
		}
		/* Enable Interrupt */
		printk("\nRTIC TEST DRV: Configuring interrupt.\n");
		rtic_int = rtic_configure_interrupt(irq_en);
		if (rtic_int == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring "
				   "of RTIC interrupt is success.\n");
		} else if (rtic_int == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring  "
				   "of RTIC interrupt is failure.\n");
		}
		printk("RTIC TEST DRV: Starting ONE_TIME hash the data.\n");
		rtic_start_hash(RTIC_ONE_TIME);
		printk("RTIC TEST DRV: Waiting for the hashing to be "
		       "finished..\n");
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());
		if ((rtic_get_status() & 0x04) == RTIC_STAT_HASH_ERR) {
			RTIC_DEBUG("RTIC TEST DRV: RTIC Status register. "
				   "0x%08lX \n ", rtic_get_status());
			printk("RTIC TEST DRV: Encountered Error while "
			       "processing\n");
			/* Bus error has occurred */
			/* Freeing all the memory allocated */
			kfree(rtic_memdata1);
			return -EACCES;
		} else if ((rtic_get_status() & 0x02) == RTIC_STAT_HASH_DONE) {
			printk("RTIC TEST DRV: Hashing done. Continuing "
			       "hash.\n");
		}
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());

		/* Hashing done successfully. Now reading the  hash data
		 * from memory.
		 */
		tempu32ptr = (ulong *) kmalloc(sizeof(ulong) * 5, GFP_KERNEL);
		rtic_result = rtic_hash_result(RTIC_A1, RTIC_ONE_TIME,
					       &rtic_res);
		if (rtic_result == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Read Hash data from "
				   "RTIC is success.\n");
		} else if (rtic_result == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Read Hash data from  "
				   "RTIC is failure.\n");
		}
		/* Displaying the hash data */
		for (i = 0; i < 5; i++) {
			printk("RTIC TEST DRV: Hash result%lu: 0x%08lX\n",
			       i + 1, rtic_res.hash_result[i]);
		}
		/* Freeing all the memory allocated */
	      rtic_out:kfree(rtic_memdata1);
		kfree(tempu32ptr);
		return 0;

	case MXCTEST_RTIC_RUNTIME_TEST:
		printk("RTIC TEST DRV: Parameters received from user"
		       "space:\n");
		printk("RTIC TEST DRV: Parameter1 0x%08lX\n",
		       *(tempu32ptr + 0));
		printk("RTIC TEST DRV: Parameter2 0x%08lX\n",
		       *(tempu32ptr + 1));
		rtic_length1 = *(tempu32ptr + 1);
		if ((rtic_rem = ((ulong) rtic_length1 % 4)) != 0) {
			rtic_length1 = ((ulong) rtic_length1 + 4 - rtic_rem);
		}
		/* Allocating memory to copy user data to kernel memory */
		printk("RTIC TEST DRV: Allocating memory for copying the "
		       "data to be hashed.\n");
		rtic_memdata1 = (ulong *) kmalloc(sizeof(ulong) *
						  (rtic_length1 + 1),
						  GFP_KERNEL);

		RTIC_DEBUG("RTIC TEST DRV: Converting Virtual to Physical"
			   "Addr\n");
		rtic_memdata2 = virt_to_phys(rtic_memdata1);

		RTIC_DEBUG("RTIC TEST DRV: Virtual address 0x%08lX\n",
			   (ulong) rtic_memdata1);
		RTIC_DEBUG("RTIC TEST DRV: Physical address 0x%08lX\n",
			   rtic_memdata2);
		/* Physical address 64 byte alignment */
		if ((rtic_rem = ((ulong) rtic_memdata2 % 4)) != 0) {
			rtic_memdata2 = ((ulong) rtic_memdata2 + 4 - rtic_rem);
		}

		/* Copying 1st memory block from user space to kernel space */
		/* 1 block of data is 512 bytes */
		printk("RTIC TEST DRV: Copying data from user space.\n");
		i = copy_from_user(rtic_memdata1, (ulong *) * tempu32ptr,
				   rtic_length1 * 4);
		if (i != 0) {
			RTIC_DEBUG("RTIC TEST DRV: Couldn't copy %lu bytes of"
				   "data from user space\n", i);
			return -EFAULT;
		}

		printk("RTIC TEST DRV: Block lengths received from user:\n"
		       "Block Length 1: 0x%06lX\n", rtic_length1);
		printk("RTIC TEST DRV: Data received from user space:\n"
		       "Mem block 1: \n");
		tempu32 = rtic_length1;
		for (i = 0; i < tempu32; i++) {
			printk("0x%08lX ", *(rtic_memdata1 + i));
		}
		printk("RTIC TEST: Pass DMA Burst read.\n");
		rtic_dma_burst_read(RTIC_DMA_16_WORD);
		/* DMA Throttle reg is set to 0x00 during boot time mode. */
		rtic_hash_once_dma_throttle();
		printk("RTIC Control reg.0x%08lX\n", rtic_get_control());
		/* Configuring the ONE-TIME Hashing */
		printk("\nRTIC TEST DRV: Configuring ONE-TIME HASH.\n");
		rtic_config_mode = rtic_configure_mode(RTIC_ONE_TIME, RTIC_A1);
		if (rtic_config_mode == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring "
				   "of RTIC is success.\n");
		} else if (rtic_config_mode == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring  "
				   "of RTIC is failure.\n");
			goto rtic_run_out;
		}
		/* Enable Interrupt */
		printk("\nRTIC TEST DRV: Configuring interrupt.\n");
		rtic_int = rtic_configure_interrupt(irq_en);
		if (rtic_int == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring "
				   "of RTIC interrupt is success.\n");
		} else if (rtic_int == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring  "
				   "of RTIC interrupt is failure.\n");
		}
		printk("RTIC TEST DRV: Starting ONE_TIME hash the data.\n");
		rtic_start_hash(RTIC_ONE_TIME);
		printk("RTIC TEST DRV: Waiting for the hashing to be "
		       "finished..\n");
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());
		printk("RTIC: Dma delay configure.\n");
		rtic_dma_delay(0x001f);
		printk("configure mem for run-time.\n");
		rtic_run_config = rtic_configure_mode(RTIC_RUN_TIME, RTIC_A1);
		printk("RTIC TEST DRV: Starting RUn_TIME hash the data.\n");
		rtic_start_hash(RTIC_RUN_TIME);
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());
		tempu32ptr = (ulong *) kmalloc(sizeof(ulong) * 5, GFP_KERNEL);
		rtic_result = rtic_hash_result(RTIC_A1, RTIC_ONE_TIME,
					       &rtic_res);
		if (rtic_result == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Read Hash data from "
				   "RTIC is success.\n");
		} else if (rtic_result == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Read Hash data from  "
				   "RTIC is failure.\n");
		}
		/* Displaying the hash data */
		for (i = 0; i < 5; i++) {
			printk("RTIC TEST DRV: Hash result%lu: 0x%08lX\n",
			       i + 1, rtic_res.hash_result[i]);
		}

		/* Freeing all the memory allocated */
	      rtic_run_out:kfree(rtic_memdata1);
		kfree(tempu32ptr);
		return 0;

	case MXCTEST_RTIC_RUNTIME_ERROR:
		printk("RTIC TEST DRV: Parameters received from user"
		       "space:\n");
		printk("RTIC TEST DRV: Parameter1 0x%08lX\n",
		       *(tempu32ptr + 0));
		printk("RTIC TEST DRV: Parameter2 0x%08lX\n",
		       *(tempu32ptr + 1));
		rtic_length1 = *(tempu32ptr + 1);
		if ((rtic_rem = ((ulong) rtic_length1 % 4)) != 0) {
			rtic_length1 = ((ulong) rtic_length1 + 4 - rtic_rem);
		}
		/* Allocating memory to copy user data to kernel memory */
		printk("RTIC TEST DRV: Allocating memory for copying the "
		       "data to be hashed.\n");
		rtic_memdata1 = (ulong *) kmalloc(sizeof(ulong) *
						  (rtic_length1 + 1),
						  GFP_KERNEL);

		RTIC_DEBUG("RTIC TEST DRV: Converting Virtual to Physical"
			   "Addr\n");
		rtic_memdata2 = virt_to_phys(rtic_memdata1);

		RTIC_DEBUG("RTIC TEST DRV: Virtual address 0x%08lX\n",
			   (ulong) rtic_memdata1);
		RTIC_DEBUG("RTIC TEST DRV: Physical address 0x%08lX\n",
			   rtic_memdata2);
		/* Physical address 64 byte alignment */
		if ((rtic_rem = ((ulong) rtic_memdata2 % 4)) != 0) {
			rtic_memdata2 = ((ulong) rtic_memdata2 + 4 - rtic_rem);
		}

		/* Copying 1st memory block from user space to kernel space */
		/* 1 block of data is 512 bytes */
		printk("RTIC TEST DRV: Copying data from user space.\n");
		i = copy_from_user(rtic_memdata1, (ulong *) * tempu32ptr,
				   rtic_length1 * 4);
		if (i != 0) {
			RTIC_DEBUG("RTIC TEST DRV: Couldn't copy %lu bytes of"
				   "data from user space\n", i);
			return -EFAULT;
		}
		printk("RTIC TEST DRV: Block lengths received from user:\n"
		       "Block Length 1: 0x%06lX\n", rtic_length1);
		printk("RTIC TEST DRV: Physical address 0x%08lX\n",
		       rtic_memdata2);
		printk("RTIC TEST DRV: Data received from user space:\n"
		       "Mem block 1: \n");
		tempu32 = rtic_length1;
		for (i = 0; i < tempu32; i++) {
			printk("0x%08lX ", *(rtic_memdata1 + i));
		}

		/* Configure for start address and blk length */
		RTIC_DEBUG("\nRTIC TEST DRV: Configuring address and length\n");
		rtic_config = rtic_configure_mem_blk((ulong) rtic_memdata2,
						     rtic_length1, RTIC_A1);
		if (rtic_config == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring memory block "
				   "of RTIC is success.\n");
		} else if (rtic_config == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring memory block "
				   "of RTIC is failure.\n");
			goto rtic_out;
		}
		/* Configuring the ONE-TIME Hashing */
		printk("\nRTIC TEST DRV: Configuring ONE-TIME HASH.\n");
		rtic_config_mode = rtic_configure_mode(RTIC_ONE_TIME, RTIC_A1);
		if (rtic_config_mode == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring "
				   "of RTIC is success.\n");
		} else if (rtic_config_mode == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring  "
				   "of RTIC is failure.\n");
			goto out;
		}
		/* Enable Interrupt */
		printk("\nRTIC TEST DRV: Configuring interrupt.\n");
		rtic_int = rtic_configure_interrupt(irq_en);
		if (rtic_int == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring "
				   "of RTIC interrupt is success.\n");
		} else if (rtic_int == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Configuring  "
				   "of RTIC interrupt is failure.\n");
		}
		printk("RTIC TEST: Pass DMA Burst read.\n");
		rtic_dma_burst_read(RTIC_DMA_16_WORD);
		printk("RTIC Control reg.0x%08lX\n", rtic_get_control());
		printk("RTIC: Dma delay configure.\n");
		rtic_dma_delay(0x001f);
		printk("RTIC TEST: WDtimer set.\n");
		rtic_wd_timer(0x001f);
		printk("RTIC TEST DRV: Starting ONE_TIME hash the data.\n");
		rtic_start_hash(RTIC_ONE_TIME);
		printk("RTIC TEST DRV: Waiting for the hashing to be "
		       "finished..\n");
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());
		printk("configure mem for run-time.\n");
		rtic_run_config = rtic_configure_mode(RTIC_RUN_TIME, RTIC_A1);
		printk("RTIC TEST DRV: Starting RUn_TIME hash the data.\n");
		rtic_start_hash(RTIC_RUN_TIME);
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());
		if ((rtic_get_status() & 0x04) == RTIC_STAT_HASH_ERR) {
			RTIC_DEBUG("RTIC TEST DRV: RTIC Status register. "
				   "0x%08lX \n ", rtic_get_status());
			printk("RTIC TEST DRV: Encountered Error while "
			       "processing\n");
			/* Bus error has occurred */
			/* Freeing all the memory allocated */
			kfree(rtic_memdata1);
			return -EACCES;
		} else if ((rtic_get_status() & 0x02) == RTIC_STAT_HASH_DONE) {
			printk("RTIC TEST DRV: Hashing done. Continuing "
			       "hash.\n");
		}
		printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		       rtic_get_status());
		/* Hashing done successfully. Now reading the  hash data
		 * from memory.
		 */
		/*tempu32ptr = (ulong *) kmalloc(sizeof(ulong) * 5, GFP_KERNEL);
		   rtic_result = rtic_hash_result(RTIC_A1, &rtic_res);
		   if (rtic_result == RTIC_SUCCESS) {
		   RTIC_DEBUG("RTIC TEST DRV: Read Hash data from "\
		   "RTIC is success.\n");
		   } else if (rtic_result == RTIC_FAILURE) {
		   RTIC_DEBUG("RTIC TEST DRV: Read Hash data from  "\
		   "RTIC is failure.\n");
		   } */
		/*rtic_run_config = rtic_configure_mode(RTIC_RUN_TIME, RTIC_A1);
		   rtic_start_hash(RTIC_RUN_TIME);
		   printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		   rtic_get_status());
		   if ((rtic_get_status() & 0x04) == RTIC_STAT_HASH_ERR) {
		   RTIC_DEBUG("RTIC TEST DRV: RTIC Status register. "\
		   "0x%08lX \n ", rtic_get_status());
		   printk("RTIC TEST DRV: Encountered Error while "\
		   "processing\n"); */
		/* Bus error has occurred */
		/* Freeing all the memory allocated */
		/*       kfree(rtic_memdata1);
		   return -EACCES;
		   } else if ((rtic_get_status() & 0x02) == RTIC_STAT_HASH_DONE) {
		   printk("RTIC TEST DRV: Hashing done. Continuing "\
		   "hash.\n");
		   }
		   printk("RTIC TEST DRV: RTIC Status register.0x%08lX  \n",
		   rtic_get_status()); */
		/* Hashing done successfully. Now reading the  hash data
		 * from memory.
		 */
		tempu32ptr = (ulong *) kmalloc(sizeof(ulong) * 5, GFP_KERNEL);
		rtic_result = rtic_hash_result(RTIC_A1, RTIC_RUN_TIME,
					       &rtic_res);
		if (rtic_result == RTIC_SUCCESS) {
			RTIC_DEBUG("RTIC TEST DRV: Read Hash data from "
				   "RTIC is success.\n");
		} else if (rtic_result == RTIC_FAILURE) {
			RTIC_DEBUG("RTIC TEST DRV: Read Hash data from  "
				   "RTIC is failure.\n");
		}
		/* Displaying the hash data */
		for (i = 0; i < 5; i++) {
			printk("RTIC TEST DRV: Hash result%lu: 0x%08lX\n",
			       i + 1, rtic_res.hash_result[i]);
		}

		/* Freeing all the memory allocated */
	      out:kfree(rtic_memdata1);
		kfree(tempu32ptr);
		return 0;

	case MXCTEST_RTIC_STATUS:
		printk("RTIC TEST DRV: Status of the RTIC module is: "
		       "0x%08lX", rtic_get_status());
		return rtic_get_status();

	default:
		printk("MXC TEST IOCTL %d not supported.\n", cmd);
		break;
	}
	return -EINVAL;
}

static int mxc_test_release(struct inode *inode, struct file *filp)
{
	return 0;
}

static struct file_operations mxc_test_fops = {
      owner:THIS_MODULE,
      open:mxc_test_open,
      release:mxc_test_release,
      read:mxc_test_read,
      write:mxc_test_write,
      ioctl:mxc_test_ioctl,
};

static int __init mxc_test_init(void)
{
	struct class_device *temp_class;
	int res;

	res =
	    register_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test", &mxc_test_fops);

	if (res < 0) {
		printk(KERN_WARNING "MXC Test: unable to register the dev\n");
		return res;
	}

	mxc_test_class = class_create(THIS_MODULE, "mxc_test");
	if (IS_ERR(mxc_test_class)) {
		printk(KERN_ERR "Error creating mxc_test class.\n");
		unregister_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test");
		class_device_destroy(mxc_test_class, MKDEV(MXC_TEST_MODULE_MAJOR, 0));
		return PTR_ERR(mxc_test_class);
	}

	temp_class = class_device_create(mxc_test_class, NULL,
					     MKDEV(MXC_TEST_MODULE_MAJOR, 0), NULL,
					     "mxc_test");
	if (IS_ERR(temp_class)) {
		printk(KERN_ERR "Error creating mxc_test class device.\n");
		class_device_destroy(mxc_test_class, MKDEV(MXC_TEST_MODULE_MAJOR, 0));
		class_destroy(mxc_test_class);
		unregister_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test");
		return -1;
	}

	return 0;
}

static void __exit mxc_test_exit(void)
{
	unregister_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test");
	class_device_destroy(mxc_test_class, MKDEV(MXC_TEST_MODULE_MAJOR, 0));
	class_destroy(mxc_test_class);
}

module_init(mxc_test_init);
module_exit(mxc_test_exit);

MODULE_DESCRIPTION("Test Module for MXC drivers");
MODULE_LICENSE("GPL");
