This folder contains configuration files that try to help setup RVD easily.

Step 1: Copy the rvc files into 
    C:\Program Files\ARM\RVD\Core\1.7\283\win_32-pentium\etc for RVDS2.1 and 
    C:\Program Files\arm\rvd\core\1.8\734\win_32-pentium\etc for RVDS2.2.

Step 2: Modify the IP address inside the rvc files.
    Find out the IP address of your ICE box and then open the proper rvc file 
    to replace the IP address after "TCP:" with the one you are using.

Step 3: Backup and copy rvdebug.brd file
    Backup the existing rvdebug.brd file from the RVDS install directory. 
    For RVDS2.1, the directory will be like:
    C:\Program Files\ARM\RVD\Core\1.7\283\win_32-pentium\home\AKZ002
    (the directory name after "home" will be different on your machine.)
    Now, copy the rvdebug.brd file into that directory.

Step 4: Modify the rvdebug.brd file to use proper rvc file.
    Open rvdebug.brd file with a text editor and search for:
	configuration="rvi
    and replace the file name between quotes with the one for the platform. 
    For example, use "rvi_mx31.rvc" for mx31 board. 
    The provided brd file also sets up the endianess mode to little 
    endian which is required to run the provided RVD script.

    Note: this step can also be done with the following method:
          Start RVD. Under "Connection Control" window, right click on "RealView-ICE"
          and then "Connection Properties". Then select "*CONNECTION=RealView-ICE" 
          on the left window. Now on the right window, modify "Configuration" field 
          to select the correct rvc file. For example, use "rvi_mx31.rvc" for mx31 
          board.
          To change the default endianess from "big" to "little", go to: 
          *CONNECTION=RealView-ICE -> *Advanced_Information -> *Default
          and change the "Endianess" value to "little" and save the configuration.
