/*
 * Copyright 2005-2006 Freescale Semiconductor, Inc. All rights reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*
 * General Include Files
 */
#include <linux/config.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <asm/uaccess.h>
#include "../include/mxc_test.h"
/*
 * Driver specific include files
 */
#include <asm/arch/mxc_i2c.h>
#include <asm/arch/clock.h>
#include <asm/arch/gpio.h>
ulong *gtempu32ptr;
static struct class *mxc_test_class;

static int mxc_test_open(struct inode *inode, struct file *filp)
{
	return 0;
}

static ssize_t mxc_test_read(struct file *file, char *buf, size_t count,
			     loff_t * ppos)
{
	return 0;
}

static ssize_t mxc_test_write(struct file *filp, const char *buf, size_t count,
			      loff_t * ppos)
{
	return 0;
}

static int mxc_i2c_read_test(mxc_i2c_test * arg)
{
	mxc_i2c_test i2c_struct;
	char buf[32];
	char reg[32];
	int ret;

	copy_from_user(&i2c_struct, arg, sizeof(i2c_struct));
	copy_from_user(reg, i2c_struct.reg, i2c_struct.reg_size);
	copy_from_user(buf, i2c_struct.buf, i2c_struct.buf_size);

	ret = mxc_i2c_read(i2c_struct.bus, i2c_struct.slave_addr, reg,
			   i2c_struct.reg_size, buf, i2c_struct.buf_size);
	copy_to_user(i2c_struct.buf, buf, i2c_struct.buf_size);

	return ret;
}

static int mxc_i2c_write_test(mxc_i2c_test * arg)
{
	mxc_i2c_test i2c_struct;
	char buf[32];
	char reg[32];

	//printk("I2C Write IOCTL\n");
	copy_from_user(&i2c_struct, arg, sizeof(i2c_struct));
	copy_from_user(reg, i2c_struct.reg, i2c_struct.reg_size);
	copy_from_user(buf, i2c_struct.buf, i2c_struct.buf_size);

	//printk("WRITE DATA=%x to REGISTER=%x\n", buf[0], reg[0]);

	return mxc_i2c_write(i2c_struct.bus, i2c_struct.slave_addr, reg,
			     i2c_struct.reg_size, buf, i2c_struct.buf_size);
}

static int mxc_test_ioctl(struct inode *inode, struct file *file,
			  unsigned int cmd, unsigned long arg)
{
	ulong *tempu32ptr, tempu32, i = 0;

	tempu32 = (ulong) (*(ulong *) arg);
	tempu32ptr = (ulong *) arg;

	switch (cmd) {
	case MXCTEST_I2C_READ:
		return mxc_i2c_read_test((mxc_i2c_test *) arg);
	case MXCTEST_I2C_WRITE:
		return mxc_i2c_write_test((mxc_i2c_test *) arg);
	case MXCTEST_I2C_CSICLKENB:
		mxc_clks_enable(CSI_BAUD);
		i = mxc_get_clocks_parent(CSI_BAUD) / 32000000;
		if ((mxc_get_clocks_parent(CSI_BAUD) / i) > 32000000) {
			i++;
		}
		mxc_set_clocks_div(CSI_BAUD, 2 * i);
		msleep(10);
		break;
	case MXCTEST_I2C_CSICLKDIS:
		mxc_clks_disable(CSI_BAUD);
		break;

    default:
		printk("MXC TEST IOCTL %d not supported\n", cmd);
		break;
	}
	return -EINVAL;
}

static int mxc_test_release(struct inode *inode, struct file *filp)
{
	return 0;
}

static struct file_operations mxc_test_fops = {
      owner:THIS_MODULE,
      open:mxc_test_open,
      release:mxc_test_release,
      read:mxc_test_read,
      write:mxc_test_write,
      ioctl:mxc_test_ioctl,
};

static int __init mxc_test_init(void)
{
	struct class_device *temp_class;
	int res;

	res =
	    register_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test", &mxc_test_fops);

	if (res < 0) {
		printk(KERN_WARNING "MXC Test: unable to register the dev\n");
		return res;
	}

	mxc_test_class = class_create(THIS_MODULE, "mxc_test");
	if (IS_ERR(mxc_test_class)) {
		printk(KERN_ERR "Error creating mxc_test class.\n");
		unregister_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test");
		class_device_destroy(mxc_test_class, MKDEV(MXC_TEST_MODULE_MAJOR, 0));
		return PTR_ERR(mxc_test_class);
	}

	temp_class = class_device_create(mxc_test_class, NULL,
					     MKDEV(MXC_TEST_MODULE_MAJOR, 0), NULL,
					     "mxc_test");
	if (IS_ERR(temp_class)) {
		printk(KERN_ERR "Error creating mxc_test class device.\n");
		class_device_destroy(mxc_test_class, MKDEV(MXC_TEST_MODULE_MAJOR, 0));
		class_destroy(mxc_test_class);
		unregister_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test");
		return -1;
	}

	return 0;
}

static void __exit mxc_test_exit(void)
{
	unregister_chrdev(MXC_TEST_MODULE_MAJOR, "mxc_test");
	class_device_destroy(mxc_test_class, MKDEV(MXC_TEST_MODULE_MAJOR, 0));
	class_destroy(mxc_test_class);
}

module_init(mxc_test_init);
module_exit(mxc_test_exit);

MODULE_DESCRIPTION("Test Module for MXC drivers");
MODULE_LICENSE("GPL");
