/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All rights reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*
 * @file mxc_v4l2_test.c
 * 
 * @brief Mxc Video For Linux 2 driver test application
 * 
 */

/*
 * test process: insmod camera/mt9v143.ko
 *               insmod usecase/ipu_usecase_mt9v143.ko
 *               insmod usecase/ipu_usecase_7_10.ko
 *               mxc_v4l2_test.out
 */

#ifdef __cplusplus
extern "C"{
#endif

/*=======================================================================
                                        INCLUDE FILES
=======================================================================*/
/* Standard Include Files */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
    
/* Verification Test Environment Include Files */
#include <sys/types.h>	
#include <sys/stat.h>	
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>    
#include <stdio.h>
#include <stdlib.h>
#include <asm/types.h>
#include <linux/compiler.h>
#include <linux/videodev.h>

#include <linux/config.h>
#if !defined( CONFIG_MACH_MX31ADS ) && !defined( CONFIG_MACH_MX21ADS )
#include <linux/delay.h>
#endif

#include <linux/fb.h>
#include <sys/mman.h>
#include <math.h>
#include <string.h>
#include <malloc.h>


#define TFAIL -1
#define TPASS 0

#define CONFIG_SDC

#ifdef CONFIG_SDC /* SDC */ 
#define MXCFB_SCREEN_WIDTH      240
#endif
#ifdef CONFIG_ADC /* ADC */
#define MXCFB_SCREEN_WIDTH      176
#endif

#define CONFIG_BPP32

#ifdef CONFIG_BPP32
#define MXCFB_BPP 4
#endif
#ifdef CONFIG_BPP24
#define MXCFB_BPP 3
#endif
#ifdef CONFIG_BPP16
#define MXCFB_BPP 2
#endif

char v4l_device[100] = "/dev/v4l/video0";
char fb_device[100] = "/dev/fb0";
int fd_v4l = 0;
int fd_fb = 0;
int g_display_width;
int g_display_height;
int g_rotate;

#define TEST_BUFFER_NUM 3

struct testbuffer
{
        unsigned char *start;
        size_t offset;
        unsigned int length;
};

struct testbuffer buffers[4];
unsigned char *fb = NULL;

int 
start_capturing (void)
{
        unsigned int i;
        struct v4l2_buffer buf;
        for (i = 0; i < TEST_BUFFER_NUM; i++)
        {
                memset(&buf, 0, sizeof (buf));
                buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
                buf.memory = V4L2_MEMORY_MMAP;
                buf.index = i;
                if (ioctl(fd_v4l, VIDIOC_QUERYBUF, &buf) < 0)
                {
                        printf("VIDIOC_QUERYBUF error\n");
                        return TFAIL;
                }

                buffers[i].length = buf.length;
                buffers[i].offset = (size_t) buf.m.offset;
                buffers[i].start = mmap (NULL, buffers[i].length, 
                                         PROT_READ | PROT_WRITE, MAP_SHARED, 
                                         fd_v4l, buffers[i].offset);
        }

        for (i = 0; i < TEST_BUFFER_NUM; i++)
        {
                memset(&buf, 0, sizeof (buf));
                buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
                buf.memory = V4L2_MEMORY_MMAP;
                buf.index = i;
                if (ioctl (fd_v4l, VIDIOC_QBUF, &buf) < 0)
                        return TFAIL;
        }

        enum v4l2_buf_type type;
        type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        if (ioctl (fd_v4l, VIDIOC_STREAMON, &type) < 0)
                return TFAIL;

        return TPASS;
}


int 
stop_capturing (void)
{
        enum v4l2_buf_type type;
        type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        if (ioctl (fd_v4l, VIDIOC_STREAMOFF, &type) < 0)
                return TFAIL;

        return TPASS;
}

void process_image(unsigned char *start, int src_w, int dst_w, int size)
{
	int i = 0, j = 0;
	unsigned char *ptr_src = start, *ptr_dst = fb;
	while (i < size)
	{
		*ptr_dst = *ptr_src;
		i++; ptr_src++;
		j++; ptr_dst++;
		if (i%src_w == 0)
		{
			while (j%dst_w != 0)
			{
				j++;
				ptr_dst++;
			}
		}
	}
}

void 
VT_v4l_capture_test(void)
{
        struct v4l2_buffer buf;
        unsigned int count = 100;
        fd_set fds;
        struct timeval tv;
        int ret = -1;

        struct v4l2_format fmt;

        fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        if (ioctl(fd_v4l, VIDIOC_G_FMT, &fmt) < 0)
        {
                printf("get format failed\n");
                return;
        } 
        else
        {
                printf("\t Width = %d", fmt.fmt.pix.width);
                printf("\t Height = %d", fmt.fmt.pix.height);
                printf("\t Image size = %d\n", fmt.fmt.pix.sizeimage);
        }

        while (count-- > 0)
        {
                FD_ZERO (&fds);
                FD_SET (fd_v4l, &fds);
                // Timeout.
                tv.tv_sec = 20;
                tv.tv_usec = 0;
                ret = select(fd_v4l + 1, &fds, NULL, NULL, &tv);
                
                if (ret < 0)
                {
                        printf("Select fault");
                        return;
                }
                if (ret == 0)
                {
                        printf("Select timeout");
                        return;
                }

                memset(&buf, 0, sizeof (buf));
                buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
                buf.memory = V4L2_MEMORY_MMAP;
                if (ioctl (fd_v4l, VIDIOC_DQBUF, &buf) < 0)
                {
                        printf("VIDIOC_DQBUF failed.\n");
                        break;
                }

                process_image(buffers[buf.index].start, fmt.fmt.pix.width * MXCFB_BPP, 
                    MXCFB_SCREEN_WIDTH * MXCFB_BPP, fmt.fmt.pix.sizeimage); 

                if (count >= TEST_BUFFER_NUM) { 
                        if (ioctl (fd_v4l, VIDIOC_QBUF, &buf) < 0) {
                                printf("Buffer error\n");
                        		break;
                        }
                }
                else
                        printf("buf.index %d\n", buf.index);
        }


        stop_capturing();
        close(fd_v4l);
        close(fd_fb);
}

int 
VT_v4l_capture_setup(void)
{
        struct v4l2_format fmt;
        struct v4l2_control ctl;
        if ((fd_fb = open(fb_device, O_RDWR )) < 0)
        {
                printf("Unable to open frame buffer\n");
                return TFAIL;
        }

        if ((fb = mmap(0, 0x40000, PROT_READ | PROT_WRITE, MAP_SHARED, fd_fb, 0)) < 0)
        {
                printf("Error: failed to map framebuffer device to memory.\n");
                return TFAIL;
        }

        if ((fd_v4l = open(v4l_device, O_RDWR, 0)) < 0)
        {
                printf("Unable to open %s\n", v4l_device);
                return TFAIL;
        }

        fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

        if (MXCFB_BPP == 3)       
                fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_BGR24;
        if (MXCFB_BPP == 2)       
                fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_RGB565;
        if (MXCFB_BPP == 4)       
                fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_BGR32;

        fmt.fmt.pix.width = g_display_width;
        fmt.fmt.pix.height = g_display_height;
        fmt.fmt.pix.sizeimage = 0;

        if (ioctl(fd_v4l, VIDIOC_S_FMT, &fmt) < 0)
        {
                printf("set format failed\n");
                return TFAIL;
        } 

        if (ioctl(fd_v4l, VIDIOC_G_FMT, &fmt) < 0)
        {
                printf("get format failed\n");
                return TFAIL;
        } 

        ctl.id = V4L2_CID_PRIVATE_BASE;
		ctl.value = g_rotate;
        if (ioctl(fd_v4l, VIDIOC_S_CTRL, &ctl) < 0)
        {
                printf("set control failed\n");
                return TFAIL;
        } 

        struct v4l2_requestbuffers req;
        memset(&req, 0, sizeof (req));
        req.count = TEST_BUFFER_NUM;
        req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        req.memory = V4L2_MEMORY_MMAP;

        if (ioctl(fd_v4l, VIDIOC_REQBUFS, &req) < 0)
        {
                printf("VT_v4l_capture_setup: VIDIOC_REQBUFS failed\n");
                return TFAIL;
        }

        if (start_capturing() != TPASS)
        {
                printf("%s capturing start failed\n", v4l_device);
                return  TFAIL;
        }

        return TPASS;
}

int process_cmdline(int argc, char **argv)
{
        int i;
        
        for (i = 1; i < argc; i++) {
                if (strcmp(argv[i], "-ow") == 0) {
                        g_display_width = atoi(argv[++i]);

                }
                else if (strcmp(argv[i], "-oh") == 0) {
                        g_display_height = atoi(argv[++i]);
                }
                else if (strcmp(argv[i], "-r") == 0) {
                        g_rotate = atoi(argv[++i]);

                }
        }

        printf("g_display_width = %d, g_display_height = %d\n", g_display_width, g_display_height);
        
        if ((g_display_width == 0) || (g_display_height == 0)) {
                return -1;
        }
        return 0;
}

int 
main(int argc, char **argv)
{
        int retval = TPASS;
        if (process_cmdline(argc, argv) < 0) {
                printf("MXC Video4Linux capture Device Test\n\n" \
                       "Syntax: mxc_v4l2_test.out -ow <display width>\n -oh <display height> -r <rotate mode>\n");
                return TFAIL;
        }

        VT_v4l_capture_setup();
        VT_v4l_capture_test();
        return retval;
}

