/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mxc_init.c
 *
 * @brief This file contains the initialization code of the basic hardware
 * required for NANDboot to boot the Linux kernel
 *
 * @ingroup Miniboot and NANDboot
 */

/*!
*    Init Mx2 Hardware.
*    Init CS0,CS1,CS3
*/
#include "mxc.h"

#if defined(IMX21ADS)||defined(IMX27ADS)
void mx2_init()
{
	int dummy, reg;

	/* burst-flash initialization */

	/* comment # CS0 Initialization (Async Mode) */
#ifdef nandboot
	/*comment # 32-bit, ?? wait states
	 *setmem 0xDF001000 0x00003E00 32
	 *setmem 0xDF001004 0x00000E01 32
	 */

	_reg_WEIM_CSU(0) = 0x00003E00;
	_reg_WEIM_CSL(0) = 0x00000E01;

	/* comment # Setting for Memory Map IO Port
	* comment # CS1 Initialization (Async Mode)
	* comment # 16-bit, D0..15, ?? wait states
	* setmem 0xDF001008 0x00002000 32
	* setmem 0xDF00100C 0x11118501 32
	*/
	_reg_WEIM_CSU(1) = 0x00002000;
	_reg_WEIM_CSL(1) = 0x11118501;

	/*comment # CS3 Initialization (Async Mode)
	 *comment # 32-bit, ?? wait states
	 *setmem 0xDF001018 0x00003E00 32
	 *setmem 0xDF00101C 0x11110601 32
	 */	

	_reg_WEIM_CSU(3) = 0x00003E00;
	_reg_WEIM_CSL(3) = 0x11110601;

#ifdef IMX21ADS
	/* comment # Config MUX for pin PF18->CS1
	 * comment # Clear PTF_GIUSE
	 * setmem 0x10015520 0x00000000 32
	*/
	_reg_GPIO_GIUS(GPIOF) &= ~0x40000;
	/* comment # Clear PTF_GPR
	 * setmem 0x10015538 0x00000000 32
	 */
	_reg_GPIO_GPR(GPIOF) &= ~0x40000;
#endif
#endif				//nandboot

#ifdef miniboot
	/* setmem /32 0xd8002000 = 0x0000CC03
 	 * setmem /32 0xd8002004 = 0xa0330D01
 	 * setmem /32 0xd8002008 = 0x00220800
 	 */

	_reg_WEIM_CSU(0) = 0x0000CC03;
	_reg_WEIM_CSL(0) = 0xa0330D01;
	_reg_WEIM_CSU(1) = 0x00220800;
#endif				/* miniboot */

	/* FMCR Register
   	 * comment # Select CS3/CSD0 Pin as CS3 only.
	 * setmem 0x10027814 0xFFFFFFC9 32
	*/
	_reg_SYS_FMCR &= 0xFFFFFFF9;

#ifdef nandboot
	/* Initialize all peripheral in AIPI1 PSR[1:0] => 10=32bit, 01=16bit, 00=8bit */
	_reg_AIPI1_PSR0 = 0x00040304;
	_reg_AIPI1_PSR1 = 0xFFFBFCFB;
#endif

#ifdef miniboot
	/* 
	 *      AHB-Lite IP Interface
	 * 
	 * setmem /32 0x10000000 = 0x20040304
	 * setmem /32 0x10020000 = 0x00000000
	 * setmem /32 0x10000004 = 0xDFFBFCFB
	 * setmem /32 0x10020004 = 0xFFFFFFFF
	 */
	_reg_AIPI1_PSR0 = 0x20040304;
	_reg_AIPI1_PSR1 = 0xDFFBFCFB;
#endif
	/* Initialize all peripheral in AIPI1 PSR[1:0] => 10=32bit, 01=16bit, 00=8bit */
	_reg_AIPI2_PSR0 = 0x0;
	_reg_AIPI2_PSR1 = 0xFFFFFFFF;

	/*write to the FMCR [31:24] (CLKMODE[1:0]) in order to get the write enable signal active */
	_reg_SYS_FMCR |= 0xAA000000;
}

void mx2_module_init()
{
	/* comment ### Master Priority Register for Slave Port 3
	 * Keep LCDC as the highest priority
	 */
	_reg_SYS_PCSR = 0;

#if defined(nandboot)
#ifdef IMX21ADS
	_reg_MAX_SLV_MPR(3) = 0x00123056;
	_reg_MAX_SLV_SGPCR(3) = 0;
#endif
#endif
#ifdef IMX27ADS
	_reg_MAX_SLV_MPR(0) = 0x00302145;
	_reg_MAX_SLV_MPR(1) = 0x00302145;
	_reg_MAX_SLV_MPR(2) = 0x00302145;

	_reg_MAX_SLV_AMPR(0) = 0x00302145;
	_reg_MAX_SLV_AMPR(1) = 0x00302145;
	_reg_MAX_SLV_AMPR(2) = 0x00302145;
#endif

	/* comment # enable user mode CSI access
	 * setmem 0x10027818 0x6000e 32 */
	_reg_SYS_GPCR = 0x6000e;
}
#endif				/* defined(IMX21ADS) || defined(IMX27ADS) */
