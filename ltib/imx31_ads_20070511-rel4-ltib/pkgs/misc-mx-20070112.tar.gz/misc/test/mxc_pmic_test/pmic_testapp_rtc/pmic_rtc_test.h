/*============================================================================*/
/**
    @file   PMIC_test_rtc.h

    @brief  Test scenario C header PMIC.
*/
/*==============================================================================

  Copyright (C) 2004, Freescale Semiconductor, Inc. All Rights Reserved
  THIS SOURCE CODE IS CONFIDENTIAL AND PROPRIETARY AND MAY NOT
  BE USED OR DISTRIBUTED WITHOUT THE WRITTEN PERMISSION OF
  Freescale Semiconductor, Inc.
     
================================================================================
Revision History:
                            Modification     Tracking
Author (core ID)                Date          Number    Description of Changes
-------------------------   ------------    ----------  -----------------------
QUINTERO/JQUI1C               11/10/2005     DSPhl26599   Initial version

==============================================================================*/

#ifndef PMIC_TEST_RTC_H
#define PMIC_TEST_RTC_H

#ifdef __cplusplus
extern "C"{
#endif

/*==============================================================================
                                         INCLUDE FILES
==============================================================================*/
#ifndef bool
#define bool    int
#endif

#ifndef true
#define true    1
#endif 

#ifndef false
#define false    1
#endif 

#include <sys/types.h>	/* open() */
#include <sys/stat.h>	/* open() */
#include <fcntl.h>	/* open() */
#include <sys/ioctl.h>	/* ioctl() */
#include <unistd.h>	/* close() */
#include <stdio.h>	/* sscanf() & perror() */
#include <stdlib.h>	/* atoi() */
#include <errno.h>
#include <linux/wait.h>

#include <asm/arch/pmic_rtc.h>

/*==============================================================================
                                       DEFINES AND MACROS
==============================================================================*/

#define    TEST_CASE1	"TEST"
#define    TEST_CASE2	"TIME"
#define    TEST_CASE3	"ALARM"
#define    TEST_CASE4	"WAIT_ALARM"
#define    TEST_CASE5	"POLL_TEST"

#define PMIC_DEVICE_RTC	"/dev/pmic_rtc"

/*==============================================================================
                                     FUNCTION PROTOTYPES
==============================================================================*/
int VT_pmic_rtc_test_setup();
void VT_pmic_rtc_test_cleanup();
int VT_pmic_rtc_test(int switch_fct);

#ifdef __cplusplus
}
#endif

#endif  // PMIC_TEST_RTC_H //
