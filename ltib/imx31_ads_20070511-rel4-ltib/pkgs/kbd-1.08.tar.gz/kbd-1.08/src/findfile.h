extern void fpclose(FILE *fp);
extern FILE *findfile(char *fnam, char **dirpath, char **suffixes);
