#ifndef HAL_PLATFORM_SETUP_H_
#define HAL_PLATFORM_SETUP_H_
/*
 * Copyright 2004-2006 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#include "mx27ads.h"

#if !defined(__ASSEMBLER__) /*ADDED FOR COMPILATION */

#define SETUP_IOMUX()  setup_iomux()

static void setup_iomux(void)
 {

	_reg_CRM_PCDR1 |= 0x5;	
	_reg_CRM_PCDR1 &= 0xFFFFFFC5;

  	/* enable clock for HCLK BROM and UART_1 */
	_reg_CRM_PCCR1 |= 0x80400400;
		
	/* Set up GPIO/IOMUX for UART_1  */
	_reg_GPIO_GIUS(GPIOE) &= 0xFFFF0FFF;	/* clear bit 12-bit 15 of GIUS_E */
	_reg_GPIO_GPR(GPIOE) &= 0xFFFF0FFF;	/* clear bit 12-bit 15 of GPR_E  */

        _reg_GPIO_GIUS(GPIOE) &= ~0x00000d8;    /* port E pin 3,4,6,7 for uart2 */
        _reg_GPIO_GPR(GPIOE) &= ~0x00000d8;     /* port E pin 3,4,6,7 for primary function */

	
}   
#endif

#if defined(__ASSEMBLER__) 
#if !defined(NOHALASM)  /* Added for linking */
/*
 * Platform setup macro
 */
#define PLATFORM_SETUP1 _platform_setup1


/*
 * This macro represents the initial startup code for the platform
 * r11 is reserved to contain chip rev info in this file
 */
    .macro  _platform_setup1
   
MX27_SETUP_START:
    /* invalidate I/D cache/TLB and drain write buffer */

    mov r0, #0
    mcr 15, 0, r0, c7, c7, 0    /* invalidate I cache and D cache */
    mcr 15, 0, r0, c8, c7, 0    /* invalidate TLBs */
    mcr 15, 0, r0, c7, c10, 4   /* Drain the write buffer */

    /* setup AIPI1 and AIPI2 */
    mov r0, #SOC_AIPI1_BASE
    ldr r1,=0x20040304
    str r1, [r0]  /* PSR0 */
    ldr r2, =0xDFFBFCFB
    str r2, [r0, #4]  /* PSR1 */
    /* set r0 = AIPI2 base */
    add r0, r0, #0x20000
    mov r1, #0x0
    str r1, [r0]  /* PSR0 */
    mov r2, #0xFFFFFFFF
    str r2, [r0, #4]  /* PSR1 */
    
    /* setup System Controls */
    ldr r0, =SOC_SYSCTRL_BASE
    mov r1, #0x03
    str r1, [r0, #(SOC_SYSCTRL_PCSR - SOC_SYSCTRL_BASE)]
 /*   mov r1, #0xFFFFFFC9
    str r1, [r0, #(SOC_SYSCTRL_FMCR - SOC_SYSCTRL_BASE)]
*/
init_max_start:
    init_max

init_drive_strength_start:
    init_drive_strength

init_cs0_start:
    init_cs0

     /* check if sdram has been setup */
      cmp pc, #SDRAM_BASE_ADDR   
      blo init_clock_start  
      cmp pc, #(SDRAM_BASE_ADDR + SDRAM_SIZE)    
      blo HWInitialise_skip_SDRAM_setup
init_clock_start:
    init_clock

init_sdram_start:
    setup_sdram_ddr

HWInitialise_skip_SDRAM_setup:


HWInitialise_skip_SDRAM_copy:

CS4_Setup: /* ADS board expanded IOs */
    
    ldr r1, =SOC_EIM_BASE   
    ldr r1, =SOC_CS4_CTL_BASE   
    ldr r2, =0x0000DCF6
    str r2, [r1, #CSCRU_OFFSET]
    ldr r2, =0x444A4541    
    str r2, [r1, #CSCRL_OFFSET]
    ldr r2, =0x44443302    
    str r2, [r1, #CSCRA_OFFSET]

NAND_ClockSetup:

/* end of NAND clock divider setup */

    /* Set up a stack [for calling C code] */
    ldr r1, =STACK_ADDR
    ldr r2, =RAM_BANK0_BASE
10:

    .endm   /* _platform_setup1 */

    .macro init_clock
        ldr r0, =SOC_CRM_BASE
        /* disable MPLL/SPLL first */
        ldr r1, [r0, #(SOC_CRM_CSCR - SOC_CRM_BASE)]    
        bic r1, r1, #0x3
        str r1, [r0, #(SOC_CRM_CSCR - SOC_CRM_BASE)]
        ldr r2, =0x1000
    1:
        subs r2, r2, #0x1
        bne 1b

        /* configure MPCTL0 */
        ldr r1, =CRM_MPCTL0_VAL
        str r1, [r0, #(SOC_CRM_MPCTL0 - SOC_CRM_BASE)]
        
        /* configure SPCTL0 */
        ldr r1, =CRM_SPCTL0_VAL   
        str r1, [r0, #(SOC_CRM_SPCTL0 - SOC_CRM_BASE)]

        /* issue SPLL restart and MPLL restart */
        ldr r1, [r0, #(SOC_CRM_CSCR - SOC_CRM_BASE)]    
#ifdef PLL_REF_CLK_26MHZ
        /* Make sure to use CKIH */
        orr r1, r1, #(3 << 16)      /* select 26MHz */
#else
        bic r1, r1, #(3 << 16)
#endif
        str r1, [r0, #(SOC_CRM_CSCR - SOC_CRM_BASE)]

        /* add some delay here */
        mov r1, #0x100
    1:  subs r1, r1, #0x1
        bne 1b
    
        /* enable MPLL/SPLL  */
        ldr r1, [r0, #(SOC_CRM_CSCR - SOC_CRM_BASE)]    
        orr r1, r1, #0x3
        str r1, [r0, #(SOC_CRM_CSCR - SOC_CRM_BASE)]
        ldr r2, =0x1000
    1:
        subs r2, r2, #0x1
        bne 1b

        /* restart PLLs */
        ldr r1, [r0, #(SOC_CRM_CSCR - SOC_CRM_BASE)]
        orr r1, r1, #0x00080000
        str r1, [r0, #(SOC_CRM_CSCR - SOC_CRM_BASE)]
    SPLL_Not_Locked:
        ldr r1, [r0, #(SOC_CRM_SPCTL1 - SOC_CRM_BASE)]
        ands r1, r1, #0x8000
        beq SPLL_Not_Locked

        ldr r1, [r0, #(SOC_CRM_CSCR - SOC_CRM_BASE)]    
        orr r1, r1, #0x00040000
        str r1, [r0, #(SOC_CRM_CSCR - SOC_CRM_BASE)]
    MPLL_Not_Locked:
        ldr r1, [r0, #(SOC_CRM_MPCTL1 - SOC_CRM_BASE)]
        ands r1, r1, #0x8000
        beq MPLL_Not_Locked     /* reach here means MPLL is locked okay */
        
        /* add some delay here */
        mov r1, #0x100
    1:  subs r1, r1, #0x1
        bne 1b
    
        ldr r2, =CRM_CSCR_VAL
        str r2, [r0, #(SOC_CRM_CSCR - SOC_CRM_BASE)] 

        /* Configure PCDR */
        /* Configure PCDR1 */
        ldr r1, =0x09030913
        str r1, [r0, #(SOC_CRM_PCDR1 - SOC_CRM_BASE)]
    
        /* Configure PCCR0 and PCCR1 */
        ldr r1, =0x3108480F
        str r1, [r0, #(SOC_CRM_PCCR0 - SOC_CRM_BASE)]

        ldr r1, [r0, #(SOC_CRM_PCCR1 - SOC_CRM_BASE)]
        orr r1, r1, #0x0780
        str r1, [r0, #(SOC_CRM_PCCR1 - SOC_CRM_BASE)]
        /* make default CLKO to be FCLK */
        ldr r1, [r0, #(SOC_CRM_CCSR - SOC_CRM_BASE)]
        and r1, r1, #0xFFFFFFE0
        orr r1, r1, #0x7
        str r1, [r0, #(SOC_CRM_CCSR - SOC_CRM_BASE)]
    .endm /* init_clock */

    .macro init_cs0
        ldr r1, =SOC_CS0_CTL_BASE
        ldr r2, =0x0000CC03
        str r2, [r1, #CSCRU_OFFSET]
        ldr r2, =0xA0330D01
        str r2, [r1, #CSCRL_OFFSET]
        ldr r2, =0x00220800
        str r2, [r1, #CSCRA_OFFSET]
    .endm /* init_cs0 */

    .macro init_max
        ldr r0, =SOC_MAX_BASE
        add r1, r0, #MAX_SLAVE_PORT1_OFFSET
        add r2, r0, #MAX_SLAVE_PORT2_OFFSET
        add r0, r0, #MAX_SLAVE_PORT0_OFFSET

        /* MPR and AMPR */
        ldr r6, =0x00302145         /* Priority SLCD>EMMA>DMA>Codec>DAHB>IAHB */
        str r6, [r0, #MAX_SLAVE_MPR_OFFSET]   /* same for all slave ports */
        str r6, [r0, #MAX_SLAVE_AMPR_OFFSET]  
        str r6, [r1, #MAX_SLAVE_MPR_OFFSET]
        str r6, [r1, #MAX_SLAVE_AMPR_OFFSET]
        str r6, [r2, #MAX_SLAVE_MPR_OFFSET]
        str r6, [r2, #MAX_SLAVE_AMPR_OFFSET]

    .endm /* init_max */

   .macro init_drive_strength
        ldr r0, =SOC_SYSCTRL_BASE
        ldr r1, =0x55555555
        str r1, [r0, #(SOC_SYSCTRL_DSCR3 - SOC_SYSCTRL_BASE)]
        str r1, [r0, #(SOC_SYSCTRL_DSCR5 - SOC_SYSCTRL_BASE)]
        str r1, [r0, #(SOC_SYSCTRL_DSCR6 - SOC_SYSCTRL_BASE)]
        ldr r1, =0x00005005
        str r1, [r0, #(SOC_SYSCTRL_DSCR7 - SOC_SYSCTRL_BASE)]
        ldr r1, =0x15555555
        str r1, [r0, #(SOC_SYSCTRL_DSCR8 - SOC_SYSCTRL_BASE)]
    .endm       /* init_drive_strength */

    .macro setup_sdram_ddr
        ldr r0,= SOC_ESDCTL_BASE
        mov r2, #SOC_CSD0_BASE
        mov r1, #0x8        /* initial reset */
        str r1, [r0, #0x10]
        /* Hold for more than 200ns */
        ldr r1, =0x10000
    1:
        subs r1, r1, #0x1
        bne 1b

        mov r1, #0x4
        str r1, [r0, #0x10]
        ldr r1, =0x00795429
        str r1, [r0, #0x4]
        ldr r1, =0x92200000
        str r1, [r0, #0x0]
        ldr r1, [r2, #0xF00]
        ldr r1, =0xA2200000
        str r1, [r0, #0x0]
        ldr r1, [r2, #0xF00]
        ldr r1, [r2, #0xF00]
        ldr r1, =0xB2200000
        str r1, [r0, #0x0]
        ldrb r1, [r2, #0x33]
        add r3, r2, #0x1000000
        ldrb r1, [r3]
        ldr r1, =0x82228485
        str r1, [r0, #0x0]
    .endm   /* setup_sdram_ddr */

    .macro do_wait_op_done
    1:
        ldrh r3, [r12, #NAND_FLASH_CONFIG2_REG_OFF]
        ands r3, r3, #NAND_FLASH_CONFIG2_INT_DONE
        beq 1b
        mov r3, #0x0
        strh r3, [r12, #NAND_FLASH_CONFIG2_REG_OFF]
    .endm   /* do_wait_op_done */

    .macro do_addr_input
        and r3, r3, #0xFF
        strh r3, [r12, #NAND_FLASH_ADD_REG_OFF]
        mov r3, #NAND_FLASH_CONFIG2_FADD_EN
        strh r3, [r12, #NAND_FLASH_CONFIG2_REG_OFF]
        do_wait_op_done
    .endm   /* do_addr_input */

#endif  /*!defined(NOHALASM) */
#endif  /*defined(__ASSEMBLER__) */
#endif  /* HAL_PLATFORM_SETUP_H_ */

