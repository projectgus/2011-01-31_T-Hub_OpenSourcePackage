
/*!
 * @file pmic_testapp_light.c
 * @brief This is the main file of PMIC tests for Light and Backlight driver. 
 *
 * @ingroup MC13783_LIGHT
 */

/*
 * Includes
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#ifndef false
#define false 0
#endif

#ifndef true
#define true 1
#endif

#ifndef bool
#define bool int
#endif

#include <sys/types.h>		/* open() */
#include <sys/stat.h>		/* open() */
#include <fcntl.h>		/* open() */
#include <sys/ioctl.h>		/* ioctl() */
#include <unistd.h>		/* close() */
#include <stdio.h>		/* sscanf() & perror() */
#include <stdlib.h>		/* atoi() */

#include <asm/arch/pmic_external.h>
#include <asm/arch/pmic_light.h>

#include "../include/test.h"
/*!
 * Display available option and read user input.
 *
 * @return       This function returns the selected option
 */
int read_user_input(void)
{
	int option;

	printf("========== TESTING PMIC Light DRIVER ==========\n");
	printf("Enter any of the following options : \n");
	printf("1. Enable Backlight\n");
	printf("2. Ramp up Backlight\n");
	printf("3. Ramp down Backlight\n");
	printf("4. Disable Backlight\n");
	printf("5. Automated Backlight test\n");
	printf("6. Start TC LED pattern\n");
	printf("7. Automated FUN test\n");
	printf("8. Start TC LED Indicator\n");
	printf("9. Automated TCLED INDICATOR test\n");
	printf("0. Exit \n");
	printf("=>");
	scanf("%d", &option);

	return option;
}

int ask_user(char *question)
{
    unsigned char answer;
    int           ret = TRETR;
    
    printf("%s [Y/N]", question);
    do
    {
        answer = fgetc(stdin);
        if (answer == 'Y' || answer == 'y')
            ret = TPASS;
        else if (answer == 'N' || answer == 'n')
            ret = TFAIL;
    }
    while (ret == TRETR);
    fgetc(stdin);       /* Wipe CR character from stream */
    return ret;
}

/*!
 * Display error message for test
 *
 * @return       This function returns a void
 */
void err_message(void)
{
	printf("Test FAILED");
}

/*!
 * This function enable backlights
 * Main, Aux and Keypad
 *
 * @param        tcled_setting  the tcled setting
 *
 * @return       This function returns a void
 */
void enable_backlight(int fp, t_bklit_setting_param * setting)
{
	setting->channel = BACKLIGHT_LED1;
	setting->current_level = 4;
	setting->duty_cycle = 7;
	setting->mode = BACKLIGHT_CURRENT_CTRL_MODE;
	setting->cycle_time = 2;
	setting->strobe = BACKLIGHT_STROBE_NONE;
	setting->edge_slow = false;
	setting->en_dis = 0;
	setting->abms = 0;
	setting->abr = 0;
	printf("Main Backlight LED ON.\n");
	ioctl(fp, PMIC_SET_BKLIT, setting);

	sleep(1);
	setting->channel = BACKLIGHT_LED2;
	printf("Auxiliary Backlight LED ON.\n");
	ioctl(fp, PMIC_SET_BKLIT, setting);

	sleep(1);
	printf("Keypad Backlight LED ON.\n");
	setting->channel = BACKLIGHT_LED3;
	ioctl(fp, PMIC_SET_BKLIT, setting);

	/* Check result */
	if(ask_user("Did you see the BACKLIGHTS ON?") == TPASS)
		printf("Test Passed\n");
	else
		printf("Test Failed\n");

}

/*!
 * This function disable backlights
 * Main, Aux and Keypad
 *
 * @param        tcled_setting  the tcled setting
 *
 * @return       This function returns a void
 */
void disable_backlight(int fp, t_bklit_setting_param * setting)
{
	setting->channel = BACKLIGHT_LED1;
	setting->current_level = 0;
	setting->duty_cycle = 0;
	setting->mode = BACKLIGHT_CURRENT_CTRL_MODE;
	setting->cycle_time = 0;
	setting->strobe = BACKLIGHT_STROBE_NONE;
	setting->edge_slow = false;
	ioctl(fp, PMIC_SET_BKLIT, setting);

	setting->channel = BACKLIGHT_LED2;
	ioctl(fp, PMIC_SET_BKLIT, setting);

	setting->channel = BACKLIGHT_LED3;
	ioctl(fp, PMIC_SET_BKLIT, setting);

}

/*!
 * This function start a specific fun pattern
 *
 * @param        fp             the file pointer
 * @param        tcled_setting  the tcled setting
 * @param        fun_param      the fun parameter
 *
 * @return       This function returns 0 if successful.
 */
int start_fun_pattern(int fp,
		      t_tcled_enable_param * tcled_setting,
		      t_fun_param * fun_param)
{
	int option;

	printf("Choose a bank:\n");
	printf("1. Bank1\n");
	printf("2. Bank2\n");
	printf("3. Bank3\n");
	scanf("%d", &option);
	tcled_setting->bank = option - 1;
	tcled_setting->mode = TCLED_FUN_MODE;
	fun_param->bank = option - 1;

	printf("Choose a pattern - no effect on MC13783:\n");
	printf("1. Red\n");
	printf("2. Green\n");
	printf("3. Blue\n");
	scanf("%d", &option);
	fun_param->channel = option - 1;

	printf("Choose a pattern:\n");
	printf("1. BLENDED_RAMPS_SLOW\n");
	printf("2. BLENDED_RAMPS_FAST\n");
	printf("3. SAW_RAMPS_SLOW\n");
	printf("4. SAW_RAMPS_FAST\n");
	printf("5. BLENDED_BOWTIE_SLOW\n");
	printf("6. BLENDED_BOWTIE_FAST\n");
	printf("7. STROBE_SLOW\n");
	printf("8. STROBE_FAST\n");
	printf("9. CHASING_LIGHT_RGB_SLOW\n");
	printf("10. CHASING_LIGHT_RGB_FAST\n");
	printf("11. CHASING_LIGHT_BGR_SLOW\n");
	printf("12. CHASING_LIGHT_BGR_FAST\n");
	scanf("%d", &option);
	fun_param->pattern = option - 1;

	ioctl(fp, PMIC_TCLED_PATTERN, fun_param);
	ioctl(fp, PMIC_TCLED_ENABLE, tcled_setting);
	sleep(2);
	ioctl(fp, PMIC_TCLED_DISABLE, tcled_setting->bank);

	printf("Test Passed\n");
	return 0;
}

/*!
 * This is the unit test for the backlight.
 *
 * @param        fp             the file pointer
 * @param        tcled_setting  the tcled setting
 * @param        fun_param        the fun parameter
 *
 * @return       This function returns 0 if successful.
 */
int run_backlight_test(int fp, t_bklit_setting_param * setting)
{
	t_bklit_setting_param r_setting;

	if (ioctl(fp, PMIC_SET_BKLIT, setting)) {
		printf("Test Failed ...1!");
		return -1;
	}
	r_setting.channel = setting->channel;
	if (ioctl(fp, PMIC_GET_BKLIT, &r_setting)) {
		printf("Test Failed ...2!");
		return -1;
	}
	if ((r_setting.mode != setting->mode) ||
	    (r_setting.mode != setting->mode) ||
	    (r_setting.strobe != setting->strobe) ||
	    (r_setting.channel != setting->channel) ||
	    (r_setting.current_level != setting->current_level) ||
	    (r_setting.duty_cycle != setting->duty_cycle) ||
	    (r_setting.cycle_time != setting->cycle_time) ||
	    (r_setting.edge_slow != setting->edge_slow) ||
	    (r_setting.en_dis != setting->en_dis) ||
	    (r_setting.abms != setting->abms) ||
	    (r_setting.abr != setting->abr)) {
		err_message();
		printf("mode %d - %d\n", r_setting.mode, setting->mode);
		printf("strobe %d - %d\n", r_setting.strobe, setting->strobe);
		printf("channel %d - %d\n", r_setting.channel,
		       setting->channel);
		printf("current level %d - %d\n", r_setting.current_level,
		       setting->current_level);
		printf("duty cycle %d - %d\n", r_setting.duty_cycle,
		       setting->duty_cycle);
		printf("cycle time%d - %d\n", r_setting.cycle_time,
		       setting->cycle_time);
		printf("edge slow %d - %d\n", r_setting.edge_slow,
		       setting->edge_slow);
		printf("en dis %d - %d\n", r_setting.en_dis, setting->en_dis);
		printf("abms %d - %d\n", r_setting.abms, setting->abms);
		printf("abr %d - %d\n", r_setting.abr, setting->abr);
		return -1;
	}
	
	if (ioctl(fp, PMIC_RAMPUP_BKLIT, setting->channel))
		return -1;
	if (ioctl(fp, PMIC_OFF_RAMPUP_BKLIT, setting->channel))
		return -1;
	if (ioctl(fp, PMIC_RAMPDOWN_BKLIT, setting->channel))
		return -1;
	if (ioctl(fp, PMIC_OFF_RAMPDOWN_BKLIT, setting->channel))
		return -1;

	return 0;
}

/*!
 * This is the suite test for the backlight.
 *
 * @param        fp             the file pointer
 * @param        setting          the backlight setting
 *
 * @return       This function returns 0 if successful.
 */
int run_suite_backlight_test(int fp, t_bklit_setting_param * setting)
{
	for (setting->channel = BACKLIGHT_LED1;
	     setting->channel <= BACKLIGHT_LED3; setting->channel++) {
		for (setting->current_level = 0;
		     setting->current_level <= 7; setting->current_level++) {
			for (setting->duty_cycle = 0;
			     setting->duty_cycle <= 15; setting->duty_cycle++) {
				for (setting->cycle_time = 0;
				     setting->cycle_time <= 3;
				     setting->cycle_time++) {
					for (setting->edge_slow = 0;
					     setting->edge_slow <= 1;
					     setting->edge_slow++) {
						if (run_backlight_test(fp,
								       setting)
						    < 0) {
							return -1;
						}
					}
				}
			}
		}
	}
	return 0;
}

/*!
 * This is the main test for the backlight.
 *
 * @param        fp             the file pointer
 * @param        setting          the backlight setting
 *
 * @return       This function returns 0 if successful.
 */
int backlight_test(int fp, t_bklit_setting_param * setting)
{
	printf("Backlight test:\n");

	setting->mode = BACKLIGHT_CURRENT_CTRL_MODE;
	setting->strobe = BACKLIGHT_STROBE_NONE;
	setting->en_dis = 0;
	setting->abms = 0;
	setting->abr = 0;
	for (setting->mode = BACKLIGHT_CURRENT_CTRL_MODE;
	     setting->mode <= BACKLIGHT_TRIODE_MODE; setting->mode++) {
		if (run_suite_backlight_test(fp, setting) < 0) {
			err_message();
			return -1;
		}
	}

	setting->channel = BACKLIGHT_LED1;
	setting->current_level = 3;
	setting->duty_cycle = 10;
	setting->cycle_time = 2;
	setting->edge_slow = 0;
	setting->en_dis = 0;
	for (setting->mode = BACKLIGHT_CURRENT_CTRL_MODE;
	     setting->mode <= BACKLIGHT_TRIODE_MODE; setting->mode++) {
		for (setting->abms = 0; setting->abms <= 7; setting->abms++) {
			for (setting->abr = 0; setting->abr <= 3;
			     setting->abr++) {
				if (run_backlight_test(fp, setting) < 0) {
					err_message();
					return -1;
				}
			}
		}
	}

	/* Clean configuration */
	disable_backlight(fp, setting);

	printf("Test PASSED\n");
	return 0;
}

/*!
 * This is the suite test for the fun pattern.
 * It checks that the read/write operation are coherent.
 * Tester has to check the pattern
 *
 * @param        fp             the file pointer
 * @param        tcled_setting  the tcled setting
 * @param        fun_param        the fun parameter
 *
 * @return       This function returns 0 if successful.
 */
int fun_light_test(int fp,
		   t_tcled_enable_param * tcled_setting,
		   t_fun_param * fun_param)
{
	for (tcled_setting->bank = 0;
	     tcled_setting->bank <= 2; tcled_setting->bank++) {
		ioctl(fp, PMIC_TCLED_DISABLE, tcled_setting->bank);
	}

	printf("Read/Write Tests\n");
	tcled_setting->mode = TCLED_FUN_MODE;
	for (fun_param->bank = 0; fun_param->bank <= 2; fun_param->bank++) {
		for (fun_param->pattern = 0;
		     fun_param->pattern <= 11; fun_param->pattern++) {
			tcled_setting->bank = fun_param->bank;
			if (ioctl(fp, PMIC_TCLED_PATTERN, fun_param) &&
			    (fun_param->pattern != STROBE_SLOW) &&
			    (fun_param->pattern != STROBE_FAST)) {
				err_message();
				return -1;
			}
			ioctl(fp, PMIC_TCLED_ENABLE, tcled_setting);
			sleep(1);
			ioctl(fp, PMIC_TCLED_DISABLE, tcled_setting->bank);
		}
	}

	printf("Run different pattern\n");
	fun_param->bank = 0;
	tcled_setting->bank = 0;
	fun_param->pattern = 0;
	ioctl(fp, PMIC_TCLED_PATTERN, fun_param);
	ioctl(fp, PMIC_TCLED_ENABLE, tcled_setting);
	sleep(1);
	fun_param->bank = 1;
	tcled_setting->bank = 1;
	fun_param->pattern = 3;
	ioctl(fp, PMIC_TCLED_PATTERN, fun_param);
	ioctl(fp, PMIC_TCLED_ENABLE, tcled_setting);
	sleep(1);
	fun_param->bank = 2;
	tcled_setting->bank = 2;
	fun_param->pattern = 4;
	ioctl(fp, PMIC_TCLED_PATTERN, fun_param);
	ioctl(fp, PMIC_TCLED_ENABLE, tcled_setting);
	sleep(5);
	for (tcled_setting->bank = 0;
	     tcled_setting->bank <= 2; tcled_setting->bank++) {
		ioctl(fp, PMIC_TCLED_DISABLE, tcled_setting->bank);
	}

	printf("Run the same pattern on the three banks\n");
	for (fun_param->pattern = 0; fun_param->pattern <= 11;
	     fun_param->pattern++) {
		ioctl(fp, PMIC_TCLED_PATTERN, fun_param);
		for (fun_param->bank = 0; fun_param->bank <= 2;
		     fun_param->bank++) {
			tcled_setting->bank = fun_param->bank;
			ioctl(fp, PMIC_TCLED_ENABLE, tcled_setting);
		}
		sleep(3);
		for (fun_param->bank = 0; fun_param->bank <= 2;
		     fun_param->bank++) {
			tcled_setting->bank = fun_param->bank;
			ioctl(fp, PMIC_TCLED_DISABLE, tcled_setting->bank);
		}
	}

	printf("Test PASSED\n");
	return 0;
}

/*!
 * This is the unit test for the tcled ind pattern.
 * It checks that the read/write operation are coherent.
 *
 * @param        fp             the file pointer
 * @param        tcled_setting  the tcled setting
 * @param        ind_param      the tcled ind parameter
 *
 * @return       This function returns 0 if successful.
 */
int run_ind_light_test(int fp,
		       t_tcled_enable_param * tcled_setting,
		       t_tcled_ind_param * ind_param)
{
	t_tcled_ind_param r_ind_param;

	r_ind_param.channel = ind_param->channel;
	r_ind_param.bank = ind_param->bank;
	ioctl(fp, PMIC_SET_TCLED, ind_param);
	ioctl(fp, PMIC_GET_TCLED, &r_ind_param);
	ioctl(fp, PMIC_TCLED_ENABLE, tcled_setting);
	usleep(50);
	ioctl(fp, PMIC_TCLED_DISABLE, tcled_setting->bank);
	if ((ind_param->bank != r_ind_param.bank) ||
	    (ind_param->channel != r_ind_param.channel) ||
	    (ind_param->level != r_ind_param.level) ||
	    (ind_param->pattern != r_ind_param.pattern) ||
	    (ind_param->rampup != r_ind_param.rampup) ||
	    (ind_param->rampdown != r_ind_param.rampdown)) {
		printf("channel : %d - %d\n", r_ind_param.channel,
		       ind_param->channel);
		printf("level : %d - %d\n", r_ind_param.level,
		       ind_param->level);
		printf("pattern : %d - %d\n", r_ind_param.pattern,
		       ind_param->pattern);
		printf("rampup : %d - %d\n", r_ind_param.rampup,
		       ind_param->rampup);
		printf("rampdown : %d - %d\n", r_ind_param.rampdown,
		       ind_param->rampdown);
		return -1;
	}
	return 0;
}

/*!
 * It reset int_param struct
 *
 * @param        fp             the file pointer
 * @param        tcled_setting  the tcled setting
 * @param        ind_param      the tcled ind parameter
 *
 * @return       This function returns 0 if successful.
 */
void ind_reset(t_tcled_ind_param * ind_param)
{
	ind_param->skip = 0;
	ind_param->half_current = 0;
	ind_param->level = 0;
	ind_param->channel = 0;
	ind_param->pattern = 0;
	ind_param->rampup = 0;
	ind_param->rampdown = 0;
}

int single_ind_light_test(int fp)
{
	int option;
	t_tcled_enable_param tcled_setting;
	t_tcled_ind_param ind_param;
	
	ind_reset(&ind_param);
	
	printf("Tricolor Indicator Test\n");
	printf("Choose a bank:\n");
	printf("1. Bank1\n");
	printf("2. Bank2\n");
	printf("3. Bank3\n");
	scanf("%d", &option);
	tcled_setting.bank = option - 1;
	tcled_setting.mode = TCLED_IND_MODE;
	ind_param.bank = tcled_setting.bank;

	printf("Choose a color pattern:\n");
	printf("1. Red\n");
	printf("2. Green\n");
	printf("3. Blue\n");
	scanf("%d", &option);
	ind_param.channel = option - 1;
	ind_param.level = TCLED_CUR_LEVEL_4;
	ind_param.pattern = TCLED_IND_BLINK_8;
	
	run_ind_light_test(fp, &tcled_setting, &ind_param);
	sleep(1);

	ind_param.level = TCLED_CUR_LEVEL_1;
	ind_param.pattern = TCLED_IND_OFF;
	run_ind_light_test(fp, &tcled_setting, &ind_param);
	
	printf("Test Passed\n");
}



/*!
 * This is the suite test for the tcled ind pattern.
 * It checks that the read/write operation are coherent.
 *
 * @param        fp             the file pointer
 * @param        tcled_setting  the tcled setting
 * @param        ind_param        the tcled ind parameter
 *
 * @return       This function returns 0 if successful.
 */
int ind_light_test(int fp,
		   t_tcled_enable_param * tcled_setting,
		   t_tcled_ind_param * ind_param)
{

	printf("Read/Write Tests\n");
	ind_reset(ind_param);
	tcled_setting->mode = TCLED_IND_MODE;
	for (tcled_setting->bank = 0;
	     tcled_setting->bank <= 2; tcled_setting->bank++) {
		ind_param->bank = tcled_setting->bank;
		for (ind_param->channel = TCLED_IND_RED;
		     ind_param->channel <= TCLED_IND_BLUE;
		     ind_param->channel++) {
			ind_param->level = TCLED_CUR_LEVEL_4;
			ind_param->pattern = TCLED_IND_BLINK_8;
			run_ind_light_test(fp, tcled_setting, ind_param);
			usleep(250);
			ind_param->level = TCLED_CUR_LEVEL_1;
			ind_param->pattern = TCLED_IND_OFF;
			run_ind_light_test(fp, tcled_setting, ind_param);
		}
	}
	ind_reset(ind_param);
	for (tcled_setting->bank = 0;
	     tcled_setting->bank <= 2; tcled_setting->bank++) {
		ind_param->bank = tcled_setting->bank;
		for (ind_param->channel = TCLED_IND_RED;
		     ind_param->channel <= TCLED_IND_BLUE;
		     ind_param->channel++) {
			for (ind_param->level = 0;
			     ind_param->level <= TCLED_CUR_LEVEL_4;
			     ind_param->level++) {
				for (ind_param->pattern = 0;
				     ind_param->pattern <= TCLED_IND_ON;
				     ind_param->pattern++) {
					if (run_ind_light_test(fp, 
						tcled_setting, ind_param) < 0) {
						err_message();
						return -1;
					}
					usleep(250);
				}
			}
			ind_param->level = TCLED_CUR_LEVEL_1;
			ind_param->pattern = TCLED_IND_OFF;
			run_ind_light_test(fp, tcled_setting, ind_param);
		}
	}
	ind_reset(ind_param);

	printf("Test PASSED\n");
	return 0;
}

int main(int argc, char **argv)
{
	int fp, option;
	int l_continue = 1;
	t_bklit_setting_param setting;
	t_tcled_enable_param tcled_setting;
	t_tcled_ind_param ind_param;
	t_fun_param fun_param;

	fp = open("/dev/pmic_light", O_RDWR);

	if (fp < 0) {
		printf("Test module: Open failed with error %d\n", fp);
		perror("Open");
		return -1;
	}
	printf("Master enable for BL and TC LED Bais\n");
	ioctl(fp, PMIC_BKLIT_TCLED_ENABLE);

	while (l_continue) {
		option = read_user_input();

		switch (option) {
		case 0:
			l_continue = 0;
			break;

		case 1:
			enable_backlight(fp, &setting);
			break;

		case 2:
			printf("Backlight should be enabled.\n");

			printf("Backlight channel 1 ramp up\n");
			ioctl(fp, PMIC_RAMPUP_BKLIT, BACKLIGHT_LED1);

			printf("Backlight channel 2 ramp up\n");
			ioctl(fp, PMIC_RAMPUP_BKLIT, BACKLIGHT_LED2);
			
			sleep(1);

			printf("Backlight channel 1 ramp up off\n");
			ioctl(fp, PMIC_OFF_RAMPUP_BKLIT, BACKLIGHT_LED1);

			printf("Backlight channel 2 ramp up off\n");
			ioctl(fp, PMIC_OFF_RAMPUP_BKLIT, BACKLIGHT_LED2);
			
			break;

		case 3:
			printf("Backlight should be enabled.\n");

			printf("Backlight channel 1 ramp down\n");
			ioctl(fp, PMIC_RAMPDOWN_BKLIT, BACKLIGHT_LED1);

			printf("Backlight channel 2 ramp down\n");
			ioctl(fp, PMIC_RAMPDOWN_BKLIT, BACKLIGHT_LED2);
			
			sleep(1);

			printf("Backlight channel 1 ramp down off\n");
			ioctl(fp, PMIC_OFF_RAMPDOWN_BKLIT, BACKLIGHT_LED1);

			printf("Backlight channel 2 ramp down off\n");
			ioctl(fp, PMIC_OFF_RAMPDOWN_BKLIT, BACKLIGHT_LED2);
			
			break;

		case 4:
			disable_backlight(fp, &setting);
			/* Check result */
			if(ask_user("Did you see the BACKLIGHTS OFF?") == TPASS)
				printf("Test Passed\n");
			else
				printf("Test Failed\n");
			break;

		case 5:
			backlight_test(fp, &setting);
			break;

		case 6:
			start_fun_pattern(fp, &tcled_setting, &fun_param);
			break;

		case 7:
			fun_light_test(fp, &tcled_setting, &fun_param);
			break;

		case 8:
			single_ind_light_test(fp);
			break;

		case 9:
			ind_light_test(fp, &tcled_setting, &ind_param);
			break;

		default:
			break;
		}
	}
	printf("Master disable for BL and TC LED Bais\n");
	ioctl(fp, PMIC_BKLIT_TCLED_DISABLE);

	close(fp);
	return 0;
}
