
#define HAVE_LIBPTHREAD 1
#define HAVE_POSIX_THREAD 1
#define _REENTRANT 1
#define HAVE_STRINGS_H 1
#define SIZEOF_SHORT 2
#define SIZEOF_INT 4
#define SIZEOF_LONG 4
#define SIZEOF_LONG_LONG 8
#define SIZEOF_UNSIGNED_SHORT 2
#define SIZEOF_UNSIGNED_INT 4
#define SIZEOF_UNSIGNED_LONG 4
#define SIZEOF_UNSIGNED_LONG_LONG 8
#define int16_t short
#define int32_t int
#define int64_t long long
#define u_int16_t unsigned short
#define u_int32_t unsigned int
#define u_int64_t unsigned long long
#define IP_TOS_TYPE char
#define Socklen_t int
#define size_t unsigned int
#define ssize_t int
#define HAVE_SNPRINTF 1
#define HAVE_INET_PTON 1
#define HAVE_INET_NTOP 1
#define HAVE_GETTIMEOFDAY 1
#define HAVE_PTHREAD_CANCEL 1
#define HAVE_USLEEP 1












