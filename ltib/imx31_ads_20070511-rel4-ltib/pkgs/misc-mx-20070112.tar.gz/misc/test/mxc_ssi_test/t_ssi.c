/*
 * Copyright 2004 Freescale Semiconductor, Inc. All Rights Reserved.
 */

/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */ 

#include <sys/types.h>    /* open()  */
#include <sys/stat.h>     /* open()  */
#include <fcntl.h>        /* open()  */
#include <sys/ioctl.h>    /* ioctl() */
#include <unistd.h>       /* close() */
#include <stdio.h>	/* sscanf() & perror() */
#include <stdlib.h>	/* atoi() */
#include <string.h>	/* string */

#ifndef false
#define false 0
#endif

#ifndef true
#define true 1
#endif

#ifndef bool
#define bool int
#endif

#include <../drivers/mxc/dam/dam.h>
#include "ssi.h"
#include <../drivers/mxc/mc13783_legacy/core/mc13783_external.h>

static wave_configuration wave_config[2];

/*!
 * MC13783 configuration.
 */
typedef struct {
        /*!
         * DEF_AUDIO_RX_0
         */
        unsigned int def_audio_rx_0;
        /*!
         * DEF_AUDIO_RX_1
         */
        unsigned int def_audio_rx_1;
        /*!
         * DEF_AUDIO_TX
         */
        unsigned int def_audio_tx;
        /*!
         * DEF_AUDIO_SSI
         */
        unsigned int def_audio_ssi;
        /*!
         * DEF_AUDIO_CODEC
         */
        unsigned int def_audio_codec;
        /*!
         * DEF_AUDIO_RX_1
         */
        unsigned int def_audio_stdac;
} mc13783_configuration;

static mc13783_configuration mc13783_config[5];

static int mod_SSI1 = false;
static int mod_SSI2 = false;
static int test = 0;
static char file1[20];
static char file2[20];
FILE *sample[2];

void help_info(void);
void read_header_wave(int num);
void configure_mc13783(void);
void configure_dam(void);
int configure_ssi(void);
int mc13783_write(int device, int reg, unsigned int val); 
void play_sample(void);

static register_info reg_info;

int main(int argc, char **argv)
{
        char command [10];

	if (argc <= 2) {
		help_info(); 
		return 1;
	}

	sscanf((char *)argv[1], "%s", (char*)command);

        if (!strcmp((char*)command,"1")) {
                mod_SSI1 = true;
                test = 0;
                sscanf((char *)argv[2], "%s", (char*)file1);
                sample[SSI1] = fopen(file1, "r");
                read_header_wave(SSI1);
                wave_config[SSI1].mode_test = test;

                /* Config SSI1 on CODEC */
	        mc13783_config[0].def_audio_rx_0 =  0x207E03;
                /* Bit Stereo opposite needed for codec on A+*/
	        mc13783_config[0].def_audio_rx_1 = 0x010211;
	        mc13783_config[0].def_audio_tx =    0x4201E1;
	        mc13783_config[0].def_audio_ssi =   0x012060;
                if (wave_config[SSI1].sample_rate == 8000) {
                        /* CODEC 8K */
	                mc13783_config[0].def_audio_codec = 0x188A24;
	        } else {
                        /* CODEC 16K */
	                mc13783_config[0].def_audio_codec = 0x188E24;
	        }
	        mc13783_config[0].def_audio_stdac = 0x008025;
	}
	else if (!strcmp((char*)command,"2"))
        {
                mod_SSI2 = true;
                test = 1;
                sscanf((char *)argv[2], "%s", (char*)file2);
                sample[SSI2] = fopen(file2, "r");
                read_header_wave(SSI2);
                wave_config[SSI2].mode_test = test;

                /* Config SSI2 on STDAC */
	        mc13783_config[1].def_audio_rx_0 =  0x407E03;
	        mc13783_config[1].def_audio_rx_1 =  0x000220;
	        mc13783_config[1].def_audio_tx =    0x4201E1;
	        mc13783_config[1].def_audio_ssi =   0x006060;
	        mc13783_config[1].def_audio_codec = 0x180024;
	        mc13783_config[1].def_audio_stdac = 0x008BA5;
	}
	else if (!strcmp((char*)command,"3"))
        {
                mod_SSI1 = true;
                mod_SSI2 = true;
                test = 2;
                sscanf((char *)argv[2], "%s", (char*)file1);
                sample[SSI1] = fopen(file1, "r");
                read_header_wave(SSI1);
                sscanf((char *)argv[3], "%s", (char*)file2);
                sample[SSI2] = fopen(file2, "r");
                read_header_wave(SSI2);
                wave_config[SSI1].mode_test = test;
                wave_config[SSI2].mode_test = test;

                /* Config SSI1 on codec and SSI2 on STDAC */
	        mc13783_config[2].def_audio_rx_0 =  0x607E03;
                /* Bit Stereo opposite needed for codec on A+*/
	        mc13783_config[2].def_audio_rx_1 =  0x010231;
	        mc13783_config[2].def_audio_tx =    0x4201E1;
	        mc13783_config[2].def_audio_ssi =   0x012060;
                if (wave_config[SSI1].sample_rate == 8000) {
                        /* CODEC 8K */
	                mc13783_config[2].def_audio_codec = 0x188A24;
	        } else {
                        /* CODEC 16K */
	                mc13783_config[2].def_audio_codec = 0x188E24;
	        }
	        mc13783_config[2].def_audio_stdac = 0x008BA5;
	}
	else if (!strcmp((char*)command,"4"))
        {
                mod_SSI1 = true;
                mod_SSI2 = true;
                test = 3;
                sscanf((char *)argv[2], "%s", (char*)file1);
                sample[SSI1] = fopen(file1, "r");
                read_header_wave(SSI1);
                sscanf((char *)argv[3], "%s", (char*)file2);
                sample[SSI2] = fopen(file2, "r");
                read_header_wave(SSI2);
                wave_config[SSI1].mode_test = test;
                wave_config[SSI2].mode_test = test;

                /* Config SSI1 and SSI2  MIX on STDAC */
	        mc13783_config[3].def_audio_rx_0 =  0x407E03;
	        mc13783_config[3].def_audio_rx_1 =  0x000220;
	        mc13783_config[3].def_audio_tx =    0x4201E1;
  	        mc13783_config[3].def_audio_ssi =   0x052060;
	        mc13783_config[3].def_audio_codec = 0x180025;
	        mc13783_config[3].def_audio_stdac = 0x008BA4;
	}

        printf("Configure DAM \n");
        configure_dam();
        printf("Configure SSI module \n");
        configure_ssi();
        printf("Configure MC13783 \n");
        configure_mc13783();
        printf("Play sample \n");
        play_sample();

        if (test == 0) {
                fclose(sample[0]);
	} else if (test == 1) {
                fclose(sample[1]);
	} else {
                fclose(sample[0]);
                fclose(sample[1]);
	}
        return 0;
}

void read_header_wave(int num)
{
        unsigned short header[29];

        wave_config[num].id_SSI = num;
        fread(header, 2, 29, sample[num]);
        wave_config[num].num_channels = header[11];
        wave_config[num].sample_rate = (((long)(header[12])) & 0x0000FFFF) |
                                       ((((long)((header[13]))<<16)) & 0xFFFF0000);
        wave_config[num].bits_per_sample = header[17];
	wave_config[num].sample_size = (((long)(header[27])) & 0x0000FFFF) |
                                       ((((long)((header[28]))<<16)) & 0xFFFF0000);
}

int mc13783_write(int device, int reg, unsigned int val)
{
	int ret;

	reg_info.reg = reg;
	reg_info.reg_value = val;
	ret = ioctl(device, MC13783_WRITE_REG, &reg_info);
	if (ret < 0) {
		printf("MC13783 ioctl error \n");
	}
	return 0;
}


void configure_mc13783()
{
	int fd;
       
	fd = open("/dev/mc13783", O_RDWR);
	printf("MC13783 opened \n");
        mc13783_write(fd, REG_AUDIO_RX_0, mc13783_config[test].def_audio_rx_0); 
        mc13783_write(fd, REG_AUDIO_RX_1, mc13783_config[test].def_audio_rx_1);      
        mc13783_write(fd, REG_AUDIO_TX, mc13783_config[test].def_audio_tx);  
        mc13783_write(fd, REG_AUDIO_SSI_NETWORK, mc13783_config[test].def_audio_ssi);        
        mc13783_write(fd, REG_AUDIO_CODEC, mc13783_config[test].def_audio_codec);
        mc13783_write(fd, REG_AUDIO_STEREO_DAC, mc13783_config[test].def_audio_stdac);       	
	close(fd);
	printf("MC13783 closed \n");
}

void configure_dam(void)
{
	int fd;

	fd = open("/dev/dam", O_RDWR);
	printf("DAM opened \n");
	if (test == 0) {
                ioctl(fd, DAM_CONFIG_SSI1_MC13783, 0);
	} else if (test == 1) {
                ioctl(fd, DAM_CONFIG_SSI2_MC13783, 0);
	} else if (test == 2) {
                ioctl(fd, DAM_CONFIG_SSI1_MC13783, 0);
                ioctl(fd, DAM_CONFIG_SSI2_MC13783, 0);
	} else if (test == 3) {
                ioctl(fd, DAM_CONFIG_SSI_NETWORK_MODE_MC13783, 0);
	}
	close(fd);
	printf("DAM closed \n");
}

int configure_ssi()
{
	int ret, fd;
	
	if (mod_SSI1 == true) {
		fd = open("/dev/ssi1", O_RDWR);
		printf("SSI1 opened \n");
                ret = ioctl(fd, SSI_CONFIG_FOR_MC13783, &wave_config[SSI1]);
                close(fd);
	}
	
	if (mod_SSI2 == true) {
		fd = open("/dev/ssi2", O_RDWR);
		printf("SSI2 opened \n");
                ret = ioctl(fd, SSI_CONFIG_FOR_MC13783, &wave_config[SSI2]);
                close(fd);
	}

	printf("SSI closed \n");
	return 0;
}

void help_info() {
        printf("\n\n**************************************************\n");
        printf("* Test aplication for ssi low level API \n");
        printf("* Options : \n\n");
        printf("* t_ssi 1 <file.wav> \n");
        printf("* Plays a <file.wav> sample on MC13783 CODEC from SSI1 \n\n");
        printf("* \n");
        printf("* t_ssi 2 <file.wav> \n");
        printf("* Plays a <file.wav> sample on MC13783 STDAC from SSI2\n\n");
        printf("* \n");
        printf("* t_ssi 3 <file1.wav> <file2.wav> \n");
        printf("* Plays an analogue MIX sample on MC13783 CODEC and STDEAC from SSI1 and SSI2 \n\n");
        printf("* \n");
        printf("* t_ssi 4 <file1.wav> <file2.wav> \n");
        printf("* Plays a digital MIX sample on MC13783 STDEAC from SSI1 and SSI2 \n\n");
        printf("**************************************************\n\n");
}

void play_sample()
{
	int fd[2];
        char *buff[2];

	if (mod_SSI1 == true) {
		fd[SSI1] = open("/dev/ssi1", O_RDWR);
		printf("SSI1 opened \n");
	}

	if (mod_SSI2 == true) {
		fd[SSI2] = open("/dev/ssi2", O_RDWR);
		printf("SSI2 opened \n");
	}

        if ((test == 0) || (test == 2) || (test == 3)) {
                ioctl(fd[SSI1], SSI_GET_BUFFER_SIZE1, wave_config[SSI1].sample_size);
	        buff[SSI1] = (char *)malloc(wave_config[SSI1].sample_size * sizeof(char));
                fread(buff[SSI1], 1, wave_config[SSI1].sample_size, sample[SSI1]);
	        ioctl(fd[SSI1], SSI_GET_BUFFER1, buff[SSI1]);
	}
        if ((test == 1) || (test == 2) || (test == 3)) {
                ioctl(fd[SSI2], SSI_GET_BUFFER_SIZE2, wave_config[SSI2].sample_size);
	        buff[SSI2] = (char *)malloc(wave_config[SSI2].sample_size * sizeof(char));
                fread(buff[SSI2], 1, wave_config[SSI2].sample_size, sample[SSI2]);
	        ioctl(fd[SSI2], SSI_GET_BUFFER2, buff[SSI2]);
	}

	printf("Start playing sample... \n");

        if (test == 0) {
	        ioctl(fd[SSI1], SSI_PLAY_DATA, SSI1);
                free(buff[SSI1]);
	        close(fd[SSI1]);
	} else if (test == 1) {
	        ioctl(fd[SSI2], SSI_PLAY_DATA, SSI2);
                free(buff[SSI2]);
	        close(fd[SSI2]);
	} else if (test == 2) {
	        ioctl(fd[SSI1], SSI_PLAY_MIX, 2);
                free(buff[SSI1]);
	        close(fd[SSI1]);
                free(buff[SSI2]);
	        close(fd[SSI2]);
	} else if (test == 3) {
	        ioctl(fd[SSI1], SSI_PLAY_MIX, 3);
                free(buff[SSI1]);
	        close(fd[SSI1]);
                free(buff[SSI2]);
	        close(fd[SSI2]);
	}

	printf("SSI closed \n");
}
