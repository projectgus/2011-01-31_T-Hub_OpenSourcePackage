
	Misc Stuff for Linux
	====================

This "misc" folder contains the source code and necessary build files for Linux 
utility programs such as tests, demos, etc. All the non-Linux BSP source should 
go into this directory.


1. Directory structure
======================

Currently the "misc" directory is organized as follows to cover three types of 
programs: bootloader, test and demo.

misc
  |- include
  |- platform
  |- bootloader
  |- lib
  |- module_test
  |_ test
       |_ demo

  
misc -> include
---------------
	This directory's path is included in the build system so that generic 
	header files can be put under this directory and be included by the source 
	code.

misc -> platform
----------------
	This directory contains the build output files. Once "make" finishes, a 
	platform specific directory will be created.

misc -> test
------------
	The unit test code goes in directories below misc/test.


2. Build Steps
==============

To build all the tests and bootloaders, run make as shown:

make PLATFORM=IMX27ADS LINUXPATH=/home/marsha/linux \
KBUILD_OUTPUT=/home/marsha/kbuild/imx27ads \
CROSS_COMPILE=/opt/freescale/usr/local/gcc-4.1.1-glibc-2.4-nptl-1/arm-linux/bin/arm-linux-

Note that you have to specify 4 things: PLATFORM, LINUXPATH, KBUILD_OUTPUT, and CROSS_COMPILE.

The build results will end up in the platform directory.

To build a single test add the test dir name to the above like:

make PLATFORM=IMX27ADS LINUXPATH=/home/marsha/linux \
KBUILD_OUTPUT=/home/marsha/kbuild/imx27ads \
CROSS_COMPILE=/opt/freescale/usr/local/gcc-4.1.1-glibc-2.4-nptl-1/arm-linux/bin/arm-linux- \
mxc_i2c_test


3. Adding new programs
======================

To add new programs such as test and demo, the easiest way is to use other existing
code as an example.  Be careful not to use absolute paths when including files from
the linux tree.
